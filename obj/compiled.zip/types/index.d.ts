declare module "_102025_collabMessagesTests.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_collabMessagesTests" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesTests100000 extends StateLitElement {
        name: string;
        render(): any;
    }
}
declare module "_102025_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102025_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
