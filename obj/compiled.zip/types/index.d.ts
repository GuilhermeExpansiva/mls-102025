declare module "_102025_/l2/collabMessagesAdd.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAdd.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesAdd" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import { CollabMessagesInputTag } from '_102025_/l2/collabMessagesInputTag';
    import '/_102025_/l2/collabMessagesInputTag.js';
    export class CollabMessagesAdd extends StateLitElement {
        private msg;
        private threadType;
        private threadName;
        private visibility;
        private group;
        private languages;
        private isLoading;
        private dmUser;
        private users;
        agentsBots: IAgentsBots[];
        _selectedAgent: string;
        _initialMessage: string;
        _topics: string[];
        _agentConfig: string;
        _promptToAvatar: string;
        labelOk: string;
        labelError: string;
        userId: string | undefined;
        languageInput?: CollabMessagesInputTag;
        onAddSuccess: Function | undefined;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private loadUsersAvaliables;
        private loadAgentsBotsAvaliables;
        private getAgentsFiles;
        private _renderAdd;
        private _handleChange;
        private renderBotsConfig;
        private renderInitialMessageConfig;
        private renderIconConfig;
        private validateForm;
        private addNewThread;
        private addBot;
        private generateAvatar;
    }
    interface IAgentsBots {
        id: string;
        name: string;
        description: string;
        avatar_url: string;
        info?: mls.cbe.IPath;
    }
}
declare module "_102025_/l2/collabMessagesAddParticipant.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAddParticipant.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesAddParticipant" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesAddParticipant extends StateLitElement {
        private msg;
        userId: string | undefined;
        labelOkAddParticipant: string;
        labelErrorAddParticipant: string;
        userIdOrName: string;
        auth: mls.msg.UserAuth;
        isAddParticipant: boolean;
        actualThread: IThreadActual | undefined;
        highlightedIndex: number;
        suggestions: string[];
        allUsers: string[];
        private users;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onInput;
        private onBlur;
        private selectSuggestion;
        private onKeyDown;
        private onFocus;
        private onSubmitAddParticipant;
        private loadUsersAvaliables;
    }
    interface IThreadActual {
        thread: mls.msg.ThreadPerformanceCache;
        users: mls.msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesApps.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesApps.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesApps" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    import '/_102025_/l2/collabMessagesAppsMenu.js';
    export class CollabMessagesApps extends CollabLitElement {
        menuModules: IMenuModule[];
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private handleMenuClick;
        private getModules;
    }
    interface IMenuModule {
        name: string;
        project: number;
        icon: string;
        path: string;
        menu: IModuleMenuItem[];
    }
    interface IModuleMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target: string;
        children: IModuleMenuItem[];
    }
}
declare module "_102025_/l2/collabMessagesAppsMenu.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAppsMenu.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesAppsMenu" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export interface IMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: IMenuItem[];
    }
    export interface IMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: IMenuItem[];
    }
    export class CollabMessagesAppsMenu extends StateLitElement {
        keyFavoritesLocalStorage: string;
        identifier: string;
        menuTitle: string;
        menuModules: IMenu[];
        favorites: string[];
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        private loadFavorites;
        private getItemPath;
        private toggleFavorite;
        private isFavorite;
        private handleMenuClick;
        private renderMenuItem;
        render(): any;
        private findItemByPath;
    }
}
declare module "_102025_/l2/collabMessagesAvatar.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAvatar.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesAvatar" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesAvatar extends StateLitElement {
        avatar: string;
        width: string;
        height: string;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesChangeAvatar.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChangeAvatar.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesChangeAvatar" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabChangeAvatar extends StateLitElement {
        private msg;
        value?: string;
        userId: string;
        threadId: string;
        private avatarPrompt;
        private avatarFile?;
        private isOpen;
        private generating;
        private preview?;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private onFileSelect;
        private triggerFileInput;
        private generateAvatarFromPrompt;
        private emitValueChanged;
        private safeSvg;
    }
}
declare module "_102025_/l2/collabMessagesChat.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChat.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesChat" {
    import '/_102025_/l2/collabMessagesTaskInfo.js';
    import '/_102025_/l2/collabMessagesTask.js';
    import '/_102025_/l2/collabMessagesTopics.js';
    import '/_102025_/l2/collabMessagesPrompt.js';
    import '/_102025_/l2/collabMessagesAvatar.js';
    import '/_102025_/l2/collabMessagesThreadDetails.js';
    import '/_102025_/l2/collabMessagesUserModal.js';
    import '/_102025_/l2/collabMessagesThreadModal.js';
    import '/_102025_/l2/collabMessagesFilter.js';
    import '/_102025_/l2/collabMessagesAdd.js';
    import '/_102025_/l2/collabMessagesChatMessage.js';
    import '/_102025_/l2/collabMessagesRichPreviewText.js';
    import { IMessage, IThreadInfo } from '_102025_/l2/collabMessagesHelper';
    import { CollabMessagesPrompt } from '_102025_/l2/collabMessagesPrompt';
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesChat extends StateLitElement {
        private msg;
        collabMessagesPrompt: CollabMessagesPrompt | undefined;
        private unreadEl;
        private messageContainer;
        private isLoadingThread;
        private filteredThreads;
        private isThreadError;
        private threadErrorMsg;
        private lastTopicFilter;
        private welcomeMessage;
        private usersAvaliables;
        group: 'CONNECT' | 'APPS' | 'DOCS' | 'CRM';
        userId: string | undefined;
        threadToOpen: string | undefined;
        taskToOpen: string | undefined;
        userDeviceId: string | undefined;
        activeScenerie: IScenery;
        actualThread: IThreadInfo | undefined;
        actualTask: mls.msg.TaskData | undefined;
        actualMessage: IMessage | undefined;
        actualMessages: IMessage[];
        actualMessagesParsed: IMessageGrouped;
        isLoadingMessages: boolean;
        searchTerm: string;
        userThreads: IThread;
        allThreads: mls.msg.Thread[];
        lastMessageReaded: string | undefined;
        unreadCountInSelectedThread: number;
        private isSystemChangeScroll;
        private savedScrollTop;
        private hasMoreMessagesLocalDB;
        private hasMoreMessagesBefore;
        private messagesLimit;
        private messagesOffset;
        private isLoadingMoreMessages;
        private isChangeTopics;
        private wasMessagesAtBottom;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderHeader;
        private renderContent;
        private renderChatMessages;
        private renderWelcomeMessage;
        private renderTopics;
        private onTopicClick;
        private removeAllModal;
        private renderPrompt;
        private renderListThreads;
        private getThreadAvatar;
        private getThreadName;
        private isDirectMessage;
        private renderThreadsByStatus2;
        private renderThreadItemLi;
        private formatMessageDate;
        private renderArchivedThreads;
        private renderDeletingThreads;
        private renderDeletedThreads;
        private renderThreadSearch;
        private renderTaskDetails;
        private renderThreadDetails;
        private renderThreadAdd;
        private onSearchInput;
        private updateMessagesAfterScrollMore;
        private getBeforeMessagesInServer;
        private onCopyChat;
        private onChatScroll;
        private groupThreadsByPrefix;
        private getOrdenedThreadsByStatus;
        private getFilteredThreads;
        private getMessagesAfter;
        private getMessagesBefore;
        private parseMessages;
        private groupMessages;
        private parseLocalDate;
        private mergeMessages;
        private onThreadClick;
        private openTask;
        private checkWelcomeMessage;
        private checkNotificationsUnreadMessages;
        private alreadyCheckForRegisterToken;
        private checkForRegisterNotification;
        private loadAllMessages;
        private updateMessagesOnDb;
        private clearUnreadMessageFromThread;
        private updateLastMessage;
        private onTitleClick;
        private onThreadDetailsClick;
        private onThreadAddClick;
        private handleSend;
        private handlePromptResize;
        private addMessage;
        private addMessageIA;
        private updateMessageAI;
        private createTempMessage;
        private updateMessage2;
        private loadAgent;
        private onTaskClick;
        private onReplyPreviewClick;
        private onReplyMessageClick;
        private getTaskUpdate;
        private getThreadInfo;
        private saveScrollPosition;
        private restoreScrollPosition;
        private onTaskChange;
        private onTaskDetailsClose;
        private onThreadChange;
        private onMessageSend;
        private onVisibilityChange;
        private onDocumentClick;
        private verifyChatScroll;
        private waitingForRenderCodesWebComponents;
    }
    type IMessageGrouped = {
        [key: string]: IMessage[];
    };
    type IThread = {
        [key: string]: IThreadInfo[];
    };
    type IScenery = 'list' | 'details' | 'loading' | 'task' | 'threadDetails' | 'threadAdd';
}
declare module "_102025_/l2/collabMessagesChatMessage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChatMessage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesChatMessage" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import { IChatPreferences, IMessage, IThreadInfo } from '_102025_/l2/collabMessagesHelper';
    export class CollabMessagesChatMessage102025 extends StateLitElement {
        message?: IMessage;
        messageId?: string;
        allThreads: mls.msg.Thread[];
        actualThread: IThreadInfo | undefined;
        usersAvaliables: mls.msg.User[];
        userId: string | undefined;
        openedReactionMessageId?: string;
        reactionPickerTarget?: HTMLElement;
        openedMenuFor?: string;
        messageMenuTarget?: HTMLElement;
        userPreferenceChat?: IChatPreferences;
        private messageMenuPlacement;
        onTaskClick?: Function;
        private msg;
        private readonly reactionEmojis;
        updated(): void;
        render(): any;
        private renderMessage;
        private renderMessageByLanguage;
        private renderReplyPreview;
        private onReplyPreviewClick;
        private renderMessageResultByLanguage;
        private renderMessageFooterResult;
        private renderCollabMessagesRichPreview;
        private onMentionHover;
        private onChannelHover;
        private removeAllUserModal;
        private removeAllChannelModal;
        private getTitleMessageTranslated;
        private renderReactions;
        private renderReactionButtonAdd;
        private onReactionClick;
        private renderReactionPicker;
        private onPickerEmojiSelect;
        private openReactionPicker;
        private closeReactionPicker;
        private toggleReaction;
        private animateReactionPicker;
        private positionReactionPicker;
        private renderSubMenuButton;
        private openMessageMenu;
        private closeMessageMenu;
        private renderMessageMenu;
        private onReplyClick;
        private closeAllPopups;
        private updateMessageMenuPlacement;
    }
}
declare module "_102025_/l2/collabMessagesEmojis.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesEmojis.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesEmojis" {
    export interface IEmoji {
        unicode: string;
        shortname: string;
        aliases: string[];
    }
    export const emojiList: {
        text: string;
        value: string;
        description: string;
        alias: string[];
    }[];
}
declare module "_102025_/l2/collabMessagesFilter.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesFilter.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesFilter" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesFilter extends StateLitElement {
        private expanded;
        private query;
        placeholder: string;
        private toggleExpand;
        private handleKey;
        private handleInput;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesFindtask.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesFindtask.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesFindtask" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesTaskDetails.js';
    export class CollabMessagesFindTask extends StateLitElement {
        private msg;
        private serviceBase;
        threadId?: string;
        taskId?: string;
        actualTask: mls.msg.TaskData | undefined;
        isLoading: boolean;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderSearch;
        private handleThreadChange;
        private handleTaskChange;
        private findThread;
    }
}
declare module "_102025_/l2/collabMessagesHelper.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesHelper.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesHelper" {
    export const AGENTDEFAULT = "agentPlanner1";
    export const defaultThreadImage = "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";
    export function registerToken(): Promise<string>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: mls.bots.ToolsBeforeSendMessage): Promise<any>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: mls.msg.Thread, prompt: string, context: mls.msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<mls.msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: mls.msg.ThreadVisibility, avatar_url?: string): Promise<mls.msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: mls.msg.ThreadGroup): Promise<mls.msg.Thread>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface ICollabMessageEvent {
        type: 'thread-open';
        threadId?: string;
        taskId?: string;
    }
    export interface IMessage extends mls.msg.MessagePerformanceCache {
        context?: mls.msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
        reactions?: MessageReactions;
        reply?: IMessageReply;
    }
    export interface IThreadInfo {
        thread: mls.msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: mls.msg.User[];
        hasMore?: boolean | undefined;
        messages?: mls.msg.Message[] | undefined;
    }
    export type MessageReactions = Record<string, string[]>;
    export interface IMessageReply {
        messageId: string;
        senderId: string;
        preview: string;
    }
}
declare module "_102025_/l2/collabMessagesIcons.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIcons.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesIcons" {
    export const collab_message: any;
    export const collab_reply: any;
    export const collab_copy: any;
    export const collab_edit: any;
    export const collab_delete: any;
    export const collab_smile: any;
    export const collab_chevron_down: any;
    export const collab_chevron_right: any;
    export const collab_clock_static: any;
    export const collab_users: any;
    export const collab_user: any;
    export const collab_magnifying_glass: any;
    export const collab_arrow_up_long: any;
    export const collab_minus: any;
    export const collab_ban: any;
    export const collab_dot: any;
    export const collab_bell: any;
    export const collab_money: any;
    export const collab_pause: any;
    export const collab_clock: any;
    export const collab_check: any;
    export const collab_bug_x12: any;
    export const collab_play: any;
    export const collab_bug: any;
    export const collab_chevron_left: any;
    export const collab_gear: any;
    export const collab_translate: any;
    export const collab_circle_exclamation: any;
    export const collab_plus: any;
    export const collab_folder_tree: any;
    export const collab_triangle_exclamation: any;
    export const collab_bell_slash: any;
    export const collab_xmark: any;
    export const collab_spinner_clock: any;
}
declare module "_102025_/l2/collabMessagesIndexedDB.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIndexedDB.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: mls.msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: mls.msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: mls.msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<mls.msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<mls.msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<mls.msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: mls.msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<mls.msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<mls.msg.ThreadPerformanceCache[]>;
    export function addThread(thread: mls.msg.Thread): Promise<mls.msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<mls.msg.ThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: mls.msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<mls.msg.ThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: mls.msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<mls.msg.ThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<mls.msg.ThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<mls.msg.ThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<mls.msg.User[]>;
    export function addUser(user: mls.msg.User): Promise<void>;
    export function updateUsers(usersFromServer: mls.msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<mls.msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102025_/l2/collabMessagesInputTag.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesInputTag.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesInputTag" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesInputTag extends StateLitElement {
        tags: string[];
        input: HTMLInputElement | undefined;
        pattern: string | null;
        placeholder: string | null;
        allowDelete: boolean;
        hasError: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputLeave;
        private onInputKeyDown;
        private isValidTag;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesMoments.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesMoments.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesMoments" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesMoments102025 extends StateLitElement {
        name: string;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesPrompt.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesPrompt.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesPrompt" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesAvatar.js';
    export class CollabMessagesPrompt extends StateLitElement {
        private msg;
        textArea: HTMLTextAreaElement | undefined;
        mentionSuggestionsElement?: HTMLElement;
        wrapper?: HTMLElement;
        text: string;
        actualMention?: IMentions;
        mentionActive: boolean;
        mentionQuery: string;
        mentionSuggestions: IMentions[];
        mentionIndex: number;
        allUsers: mls.msg.User[];
        allAgents: IMentionAgent[];
        alreadyLoadingAgents: boolean;
        lastScopeLoaded: string | undefined;
        replyingTo?: {
            messageId: string;
            senderId: string;
            preview: string;
        };
        onSend: Function | undefined;
        threadId?: string;
        placeholder?: string;
        scope?: string;
        acceptAutoCompleteUser?: boolean;
        acceptAutoCompleteAgents?: boolean;
        connectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        setReply(message: {
            messageId: string;
            senderId: string;
            preview: string;
        }): void;
        clearReply(): void;
        private getUsers;
        private getAgents;
        private getCaretCoordinates;
        private calculatePosition;
        private adjustTextAreaHeight;
        private getAgentsFiles;
        render(): any;
        private renderReply;
        handleFocus(): Promise<void>;
        handleInput(e: MouseEvent): Promise<void>;
        private getUserSuggestions;
        private getAgentSuggestions;
        private getEmojiSuggestions;
        private handleKeyDown;
        private scrollToActiveMention;
        private selectMention;
        private extractAgentName;
        handleSend(): Promise<void>;
    }
    interface IMentionAgent {
        name: string;
        description: string;
        alias: string;
        avatar_url?: string;
    }
    interface IMentions {
        text: string;
        value: string;
        description: string;
        avatar_url?: string | undefined;
        type: 'user' | 'agent' | 'emoji';
    }
}
declare module "_102025_/l2/collabMessagesRichPreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesRichPreview.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesRichPreview" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesTextCode.js';
    export class WidgetText2CollabMessagesMD extends StateLitElement {
        private _abortController;
        /**
        * Text in standard Slack-style markdown to be rendered as HTML.
        * @example
        * "Olá **mundo**! @lucas #geral"
        */
        text: string;
        get content(): string | undefined;
        set content(val: string | undefined);
        editable?: boolean;
        allHelpers: string[];
        allCommands: string[];
        allThreads: mls.msg.Thread[];
        allUsers: mls.msg.User[];
        /**
         * Helper function to extract and protect code blocks (```...```).
         * Now uses <collab-messages-rich-preview-102025> for rendering code blocks.
         */
        private extractCodeBlocks;
        /**
        * Helper function to extract and protect inline code (`...`).
        * Now uses <collab-messages-rich-preview-102025> for rendering inline code.
        */
        private extractInlineCodes;
        private parseMentionLinks;
        private parseChannelRefs;
        private parseAgentMentions;
        private parseCommands;
        private parseObjectRefs;
        private parseHelpRefs;
        private parseRawLinks2;
        private parseRawLinks;
        private parseMarkdownLinks;
        private escapeHtml;
        /**
        * Parse Slack-style markdown to safe HTML.
        * Order of replacements is important to avoid nested/overlapping tags.
        *
        * Blockquote improvement: blockquote starts with '>' and ends with two newlines or end of text.
        * Now also supports ordered lists (1. Item, 2. Item, ...)
        *
        * Now supports strikethrough using ~~text~~.
        */
        private parseSlackMarkdown;
        render(): any;
        private attachDynamicEvents;
        updated(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102025_/l2/collabMessagesRichPreviewText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesRichPreviewText.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesRichPreviewText" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesTextCode.js';
    export type SlackToken = {
        type: 'text';
        value: string;
    } | {
        type: 'inline-code';
        value: string;
    } | {
        type: 'code-block';
        language: string;
        value: string;
    } | {
        type: 'bold';
        value: string;
    } | {
        type: 'italic';
        value: string;
    } | {
        type: 'strike';
        value: string;
    } | {
        type: 'mention';
        value: string;
        userId: string;
    } | {
        type: 'channel';
        value: string;
    } | {
        type: 'agent';
        value: string;
    } | {
        type: 'command';
        value: string;
    } | {
        type: 'help';
        value: string;
    } | {
        type: 'link';
        text: string;
        url: string;
    } | {
        type: 'raw-link';
        url: string;
    } | {
        type: 'blockquote';
        children: SlackToken[];
    } | {
        type: 'list';
        ordered: boolean;
        items: SlackToken[][];
    };
    export class CollabMessagesRichPreviewText102025 extends StateLitElement {
        private msg;
        allHelpers: string[];
        allCommands: string[];
        allThreads: mls.msg.Thread[];
        allUsers: mls.msg.User[];
        text: string;
        render(): any;
        private renderSlackTokens;
        private renderToken;
        private renderText;
        private renderBold;
        private renderItalic;
        private renderStrike;
        private renderInlineCode;
        private renderCodeBlock;
        private renderAgent;
        private renderMention;
        private renderChannel;
        private renderCommand;
        private renderHelp;
        private renderLink;
        private renderRawLink;
        private renderBlockquote;
        private renderList;
        private copyToClipboard;
        private parseSlackMarkdown;
        private parseInlineSlackMarkdown;
    }
}
declare module "_102025_/l2/collabMessagesSettings.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettings.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesSettings" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesSettings100554 extends StateLitElement {
        private msg;
        private serviceBase;
        private list;
        userPerfil: mls.msg.User | undefined;
        private chatPreferences;
        notificationPreferences?: NotificationPermission | null;
        audioEnabled: boolean;
        labelOk: string;
        labelError: string;
        labelOkPref: string;
        labelErrorPref: string;
        labelOkNotification: string;
        labelErrorNotification: string;
        isSavingUser: boolean;
        isSavingChat: boolean;
        isSavingNotification: boolean;
        userAvatarEl: HTMLImageElement | undefined;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        updated(): void;
        render(): any;
        private renderUser;
        private renderChatPreferences;
        private renderPreferencesNotifications;
        private getNotificationStatus;
        private renderReadMore;
        private handleAudioToggle;
        private onEnabledNotifications;
        private refreshAvatar;
        private getUserPerfil;
        private handleSave;
        private handleSaveChatPref;
        private handleTranslationModeChange;
        private handleLanguageInput;
        private handleNameInput;
    }
}
declare module "_102025_/l2/collabMessagesSyncNotifications.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSyncNotifications.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesSyncNotifications" {
    export const threadSyncMap: Map<string, boolean>;
    export function removeThreadFromSync(threadId: string): void;
    export function checkIfNotificationUnread(): Promise<boolean>;
    export function listenToThreadEvents(): Promise<void>;
    export function getThreadUpdateInBackground(threadId: string): Promise<void>;
}
declare module "_102025_/l2/collabMessagesTask.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTask.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTask" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesTask extends StateLitElement {
        private msg;
        taskid: string;
        threadId: string;
        userId: string;
        messageid: string;
        lastChanged: string;
        status: string;
        task: mls.msg.TaskData | undefined;
        context: mls.msg.ExecutionContext | undefined;
        private secondsPassed;
        private lastStep;
        continueEnabled: boolean;
        private timerId;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderIconTask(): any;
        private onContinueClick;
        private resetTimer;
        private formatTime;
        private getTaskLocal;
        private onCardClick;
    }
}
declare module "_102025_/l2/collabMessagesTaskDetails.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskDetails.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskDetails" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesTaskDetails extends StateLitElement {
        task: mls.msg.TaskData | undefined;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderTaskModeJson;
        private renderTaskModeDetails;
        private renderDirectResult;
        private renderDirectClarification;
        private renderlLongMemory;
        private renderTaskInfo;
        private renderTaskInteractions;
        private renderPayload;
        private renderPayloadAgent;
        private renderInteration;
        private renderAgent;
        private renderTool;
        private renderClarificationDetails;
        private renderFlexible;
        private renderClarification;
        private renderResult;
        private setClarification;
        private executeHTMLClarificationScript;
        private syntaxHighlight;
        private onTaskChange;
    }
}
declare module "_102025_/l2/collabMessagesTaskInfo.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskInfo.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskInfo" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesTaskDetails.js';
    import '/_102025_/l2/collabMessagesTaskPreview.js';
    import '/_102025_/l2/collabMessagesTaskLogPreview.js';
    export class CollabMessagesTaskInfo extends StateLitElement {
        private elParent;
        private forceViewRaw;
        private hasTodo;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        restartPooling: boolean;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        private activeTab;
        isClarificationPending: boolean;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderTab(): any;
        renderTabContent(): any;
        renderRaw(): any;
        renderStep(): any;
        renderTodo(): any;
        renderDirectClarification(): any;
        renderClarification(payload: mls.msg.AIClarificationStep): any;
        private clickForceViewRaw;
        private setClarification;
        private executeHTMLClarificationScript;
        private setTab;
        private onTaskChange;
    }
}
declare module "_102025_/l2/collabMessagesTaskLogPreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskLogPreview.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskLogPreview" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesTaskLogPreview extends StateLitElement {
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        template?: TemplateResult;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        disconnectedCallback(): void;
        render(): any;
        private onTaskChange;
        private createFeedBack;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreview.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreview" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    import '/_102025_/l2/collabMessagesTaskPreviewAgent.js';
    import '/_102025_/l2/collabMessagesTaskPreviewClarification.js';
    import '/_102025_/l2/collabMessagesTaskPreviewFlexible.js';
    import '/_102025_/l2/collabMessagesTaskPreviewTools.js';
    import '/_102025_/l2/collabMessagesTaskPreviewResult.js';
    export class CollabMessageTaskPreview extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        modeTest: boolean;
        private stepMap;
        private navigationStack;
        private currentStepId;
        private allSteps;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderStep(): any;
        renderNavigation(stepId: number): any;
        renderStepDetails(step: mls.msg.AIPayload): any;
        renderBreadcrumb(): any;
        renderAgent(step: mls.msg.AIAgentStep): any;
        renderClarification(step: mls.msg.AIClarificationStep): any;
        renderFlexible(step: mls.msg.AIFlexibleResultStep): any;
        renderTools(step: mls.msg.AIToolStep): any;
        renderResult(step: mls.msg.AIResultStep): any;
        private init;
        private onTaskChange;
        private buildStepMap;
        private navigateToStep;
        private goBack;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CollabMessageTaskPreviewAgent extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIAgentStep | null;
        agentDescription: string;
        private prompts;
        private mode;
        private lastKey;
        firstUpdated(): void;
        update(changedProperties: any): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderInputs(): any;
        renderPrompt(prompt: mls.msg.IAMessageInputType, idx: number): any;
        renderResults(): any;
        private init;
        private getDescription;
        private getPrompts;
        private selectTabInput;
        private selectTabInfo;
        private selectTabResult;
        private replayForSupport;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CollabMessageTaskPreviewClarification extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIClarificationStep | null;
        private mode;
        private tag;
        clarificationid: HTMLDivElement | undefined;
        private elClarification;
        firstUpdated(): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderClarification(): any;
        renderResults(): any;
        private selectTabClarification;
        private selectTabInfo;
        private getFile;
        private getAgentBeforeStep;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CollabMessageTaskPreviewFlexible extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        private mode;
        editor: IHTMLEditorElement | undefined;
        private _ed1;
        get confE(): string;
        firstUpdated(): Promise<void>;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderFlexible(): any;
        renderResults(): any;
        private createEditor;
        private selectTabFlexible;
        private selectTabInfo;
        private selectTabResult;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CollabMessageTaskPreviewResult extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIResultStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderResults(): any;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CollabMessageTaskPreviewTools extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIToolStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderTools(): any;
        renderResults(): any;
        private selectTabTools;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTasks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTasks.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTasks" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesTasks extends StateLitElement {
        private view;
        private selectedTask;
        private _backToList;
        render(): any;
        private _renderTaskDetails;
        _renderTaskList(): any;
        private _openTaskDetails;
    }
}
declare module "_102025_/l2/collabMessagesTextCode.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTextCode.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTextCode" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesTextCode extends StateLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        private _resolveRendered;
        private markRendered;
        whenRendered: Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesThreadDetails.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesThreadDetails.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesThreadDetails" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesInputTag.js';
    import '/_102025_/l2/collabMessagesAddParticipant.js';
    import '/_102025_/l2/collabMessagesChangeAvatar.js';
    export class CollabMessagesThreadDetails extends StateLitElement {
        private msg;
        userId: string | undefined;
        threadDetails?: IThreadDetails;
        avatarEl?: HTMLElement;
        labelOk: string;
        labelError: string;
        labelErrorRemoveUser: string;
        labelErrorRemoveBoot: string;
        private isLoading;
        private editedThreadDetails?;
        private isDirectMessage?;
        private isChannel?;
        private isFileChannel?;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: Map<string, any>): Promise<void>;
        render(): any;
        private renderUsers;
        private renderBots;
        private removeUser;
        private removeBot;
        private disableBot;
        private getChangedFields;
        private onAddParticipant;
        private saveChanges;
        private removeUserFromThread;
        private getThreadInfo;
    }
    interface IThreadDetails {
        thread: mls.msg.ThreadPerformanceCache;
        users: mls.msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesThreadModal.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesThreadModal.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesThreadModal" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesAvatar.js';
    export class CollabMessagesThreadModal extends StateLitElement {
        private msg;
        open: boolean;
        thread?: mls.msg.ThreadPerformanceCache;
        private isLoading;
        private errorMessage;
        private handleGlobalMouseMove;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickThreadAction;
    }
}
declare module "_102025_/l2/collabMessagesTopics.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTopics.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTopics" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesTopics extends StateLitElement {
        messages: IMessage[];
        topics: string[];
        expanded: boolean;
        selectedTopic: string | null;
        threadTopics: string[];
        render(): any;
        private emitTopic;
        private extractTopics;
        private groupTopics;
        private getHeadersTopicsFromMessages;
        private getTopicsFromMessagesOrdered;
    }
    interface IMessage extends mls.msg.MessagePerformanceCache {
        context?: mls.msg.ExecutionContext;
    }
}
declare module "_102025_/l2/collabMessagesUserModal.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesUserModal.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesUserModal" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class CollabMessagesUserModal extends StateLitElement {
        private msg;
        open: boolean;
        user?: mls.msg.User;
        actualUserId?: string;
        private isLoading;
        private errorMessage;
        private close;
        private handleGlobalMouseMove;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickUserAction;
    }
}
declare module "_102025_/l2/designSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/designSystem" {
    import { IDesignSystemTokens } from '/_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102025_/l2/project.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102025_/l2/serviceCollabMessages.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/serviceCollabMessages" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from '_100554_/l2/serviceBase';
    import '/_102025_/l2/collabMessagesAdd.js';
    import '/_102025_/l2/collabMessagesChat.js';
    import '/_102025_/l2/collabMessagesTasks.js';
    import '/_102025_/l2/collabMessagesApps.js';
    import '/_102025_/l2/collabMessagesMoments.js';
    import '/_102025_/l2/collabMessagesSettings.js';
    import '/_102025_/l2/collabMessagesFindtask.js';
    export class ServiceCollabMessages extends ServiceBase {
        private msg;
        dataLocal: IDataLocal;
        activeTab: ITabType;
        activeScenerie: IScenery;
        isLoadingThread: boolean;
        userPerfil: mls.msg.User | undefined;
        userThreads: IThreadData;
        showNotificationAlert: boolean;
        threadToOpen: string;
        taskToOpen: string;
        lastLevel: number;
        groupSelected: ITabType;
        details: IService;
        onClickTabs(index: number): void;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        connectedCallback(): Promise<void>;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private changeDisplayMenu;
        private isFirstEnter;
        private configureByLevel;
        private checkNotificationPermission;
        private startPendentsPoolingsIfNeeded;
        private showAboutThis;
        private onThreadChange;
        private setEvents;
        private removeEvents;
        renderTabs(): any;
        renderAlert(): any;
        private onAlertClose;
        renderCRM(): any;
        renderTasks(): any;
        renderMoments(): any;
        renderApps(): any;
        renderConnect(): any;
        private getUser;
        private updateThreads;
        private searchForDeletedThreadsPending;
        private updateUsersThread;
        private getThreadFromLocalDB;
        private getThreadInfo;
        private execCoachMarks;
        private resetOnBoarding;
        private openSettings;
        private openFindTask;
        private onCollabEventsCollabMessages;
        private onThreadCreate;
        private checkNotificationPending;
    }
    interface IDataLocal {
        lastTab: ITabType;
    }
    type IThreadData = {
        [key: string]: IThreadInfo;
    };
    interface IThreadInfo {
        thread: mls.msg.Thread;
        users: mls.msg.User[];
    }
    type ITabType = 'CRM' | 'TASK' | 'MOMENTS' | 'CONNECT' | 'APPS' | 'Add' | 'Loading';
    type IScenery = 'tabs' | 'settings' | 'findTask';
}
declare module "_102025_/l2/agents/agentGenerateAvatarSvg.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/agents/agentGenerateAvatarSvg.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/agents/agentGenerateAvatarSvg" {
    import { IAgent } from '/_100554_/l2/aiAgentBase';
    export function createAgent(): IAgent;
    export function getPayload(context: mls.msg.ExecutionContext): string;
}
