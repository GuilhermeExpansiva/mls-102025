/// <mls shortName="collabMessagesTextCode" project="102025" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
let CollabMessagesTextCode = class CollabMessagesTextCode extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-text-code-102025 pre{position:relative;white-space:pre-wrap;margin:0}collab-messages-text-code-102025 pre select{position:absolute;top:62px;left:5px;border:none;outline:none}collab-messages-text-code-102025 pre code.hljs{display:block;overflow-x:auto;padding:1em}collab-messages-text-code-102025 code.hljs{padding:3px 5px}collab-messages-text-code-102025 .hljs{background:#fff;border:1px solid var(--grey-color);color:#000;outline:none}collab-messages-text-code-102025 .hljs-keyword,collab-messages-text-code-102025 .hljs-literal,collab-messages-text-code-102025 .hljs-symbol,collab-messages-text-code-102025 .hljs-name{color:#569CD6}collab-messages-text-code-102025 .hljs-link{color:#569CD6;text-decoration:underline}collab-messages-text-code-102025 .hljs-built_in,collab-messages-text-code-102025 .hljs-type{color:#4EC9B0}collab-messages-text-code-102025 .hljs-number,collab-messages-text-code-102025 .hljs-class{color:#B8D7A3}collab-messages-text-code-102025 .hljs-string,collab-messages-text-code-102025 .hljs-meta .hljs-string{color:#D69D85}collab-messages-text-code-102025 .hljs-regexp,collab-messages-text-code-102025 .hljs-template-tag{color:#9A5334}collab-messages-text-code-102025 .hljs-subst,collab-messages-text-code-102025 .hljs-function,collab-messages-text-code-102025 .hljs-title,collab-messages-text-code-102025 .hljs-params,collab-messages-text-code-102025 .hljs-formula{color:#DCDCDC}collab-messages-text-code-102025 .hljs-comment,collab-messages-text-code-102025 .hljs-quote{color:#57A64A;font-style:italic}collab-messages-text-code-102025 .hljs-doctag{color:#608B4E}collab-messages-text-code-102025 .hljs-meta,collab-messages-text-code-102025 .hljs-meta .hljs-keyword,collab-messages-text-code-102025 .hljs-tag{color:#9B9B9B}collab-messages-text-code-102025 .hljs-variable,collab-messages-text-code-102025 .hljs-template-variable{color:#BD63C5}collab-messages-text-code-102025 .hljs-attr,collab-messages-text-code-102025 .hljs-attribute{color:#9CDCFE}collab-messages-text-code-102025 .hljs-section{color:gold}collab-messages-text-code-102025 .hljs-emphasis{font-style:italic}collab-messages-text-code-102025 .hljs-strong{font-weight:bold}collab-messages-text-code-102025 .hljs-bullet,collab-messages-text-code-102025 .hljs-selector-tag,collab-messages-text-code-102025 .hljs-selector-id,collab-messages-text-code-102025 .hljs-selector-class,collab-messages-text-code-102025 .hljs-selector-attr,collab-messages-text-code-102025 .hljs-selector-pseudo{color:#D7BA7D}collab-messages-text-code-102025 .hljs-addition{background-color:#144212;display:inline-block;width:100%}collab-messages-text-code-102025 .hljs-deletion{background-color:#600;display:inline-block;width:100%}collab-messages-text-code-102025.hljs{/*!
        Theme: Default
        Description: Original highlight.js style
        Author: (c) Ivan Sagalaev <maniac@softwaremaniacs.org>
        Maintainer: @highlightjs/core-team
        Website: https://highlightjs.org/
        License: see project LICENSE
        Touched: 2021
    */}collab-messages-text-code-102025.hljs pre code.hljs{display:block;overflow-x:auto;padding:1em}collab-messages-text-code-102025.hljs code.hljs{padding:3px 5px}collab-messages-text-code-102025.hljs .hljs{background:#f3f3f3;color:#444}collab-messages-text-code-102025.hljs .hljs-comment{color:#697070}collab-messages-text-code-102025.hljs .hljs-punctuation,collab-messages-text-code-102025.hljs .hljs-tag{color:#444a}collab-messages-text-code-102025.hljs .hljs-tag .hljs-attr,collab-messages-text-code-102025.hljs .hljs-tag .hljs-name{color:#444}collab-messages-text-code-102025.hljs .hljs-attribute,collab-messages-text-code-102025.hljs .hljs-doctag,collab-messages-text-code-102025.hljs .hljs-keyword,collab-messages-text-code-102025.hljs .hljs-meta .hljs-keyword,collab-messages-text-code-102025.hljs .hljs-name,collab-messages-text-code-102025.hljs .hljs-selector-tag{font-weight:700}collab-messages-text-code-102025.hljs .hljs-deletion,collab-messages-text-code-102025.hljs .hljs-number,collab-messages-text-code-102025.hljs .hljs-quote,collab-messages-text-code-102025.hljs .hljs-selector-class,collab-messages-text-code-102025.hljs .hljs-selector-id,collab-messages-text-code-102025.hljs .hljs-string,collab-messages-text-code-102025.hljs .hljs-template-tag,collab-messages-text-code-102025.hljs .hljs-type{color:#800}collab-messages-text-code-102025.hljs .hljs-section,collab-messages-text-code-102025.hljs .hljs-title{color:#800;font-weight:700}collab-messages-text-code-102025.hljs .hljs-link,collab-messages-text-code-102025.hljs .hljs-operator,collab-messages-text-code-102025.hljs .hljs-regexp,collab-messages-text-code-102025.hljs .hljs-selector-attr,collab-messages-text-code-102025.hljs .hljs-selector-pseudo,collab-messages-text-code-102025.hljs .hljs-symbol,collab-messages-text-code-102025.hljs .hljs-template-variable,collab-messages-text-code-102025.hljs .hljs-variable{color:#ab5656}collab-messages-text-code-102025.hljs .hljs-literal{color:#695}collab-messages-text-code-102025.hljs .hljs-addition,collab-messages-text-code-102025.hljs .hljs-built_in,collab-messages-text-code-102025.hljs .hljs-bullet,collab-messages-text-code-102025.hljs .hljs-code{color:#397300}collab-messages-text-code-102025.hljs .hljs-meta{color:#1f7199}collab-messages-text-code-102025.hljs .hljs-meta .hljs-string{color:#38a}collab-messages-text-code-102025.hljs .hljs-emphasis{font-style:italic}collab-messages-text-code-102025.hljs .hljs-strong{font-weight:700}collab-messages-text-code-102025.github{/*!
    Theme: GitHub
    Description: Light theme as seen on github.com
    Author: github.com
    Maintainer: @Hirse
    Updated: 2021-05-15

    Outdated base version: https://github.com/primer/github-syntax-light
    Current colors taken from GitHub's CSS
    */}collab-messages-text-code-102025.github pre code.hljs{display:block;overflow-x:auto;padding:1em}collab-messages-text-code-102025.github code.hljs{padding:3px 5px}collab-messages-text-code-102025.github .hljs{color:#24292e;background:#fff}collab-messages-text-code-102025.github .hljs-doctag,collab-messages-text-code-102025.github .hljs-keyword,collab-messages-text-code-102025.github .hljs-meta .hljs-keyword,collab-messages-text-code-102025.github .hljs-template-tag,collab-messages-text-code-102025.github .hljs-template-variable,collab-messages-text-code-102025.github .hljs-type,collab-messages-text-code-102025.github .hljs-variable.language_{color:#d73a49}collab-messages-text-code-102025.github .hljs-title,collab-messages-text-code-102025.github .hljs-title.class_,collab-messages-text-code-102025.github .hljs-title.class_.inherited__,collab-messages-text-code-102025.github .hljs-title.function_{color:#6f42c1}collab-messages-text-code-102025.github .hljs-attr,collab-messages-text-code-102025.github .hljs-attribute,collab-messages-text-code-102025.github .hljs-literal,collab-messages-text-code-102025.github .hljs-meta,collab-messages-text-code-102025.github .hljs-number,collab-messages-text-code-102025.github .hljs-operator,collab-messages-text-code-102025.github .hljs-selector-attr,collab-messages-text-code-102025.github .hljs-selector-class,collab-messages-text-code-102025.github .hljs-selector-id,collab-messages-text-code-102025.github .hljs-variable{color:#005cc5}collab-messages-text-code-102025.github .hljs-meta .hljs-string,collab-messages-text-code-102025.github .hljs-regexp,collab-messages-text-code-102025.github .hljs-string{color:#032f62}collab-messages-text-code-102025.github .hljs-built_in,collab-messages-text-code-102025.github .hljs-symbol{color:#e36209}collab-messages-text-code-102025.github .hljs-code,collab-messages-text-code-102025.github .hljs-comment,collab-messages-text-code-102025.github .hljs-formula{color:#6a737d}collab-messages-text-code-102025.github .hljs-name,collab-messages-text-code-102025.github .hljs-quote,collab-messages-text-code-102025.github .hljs-selector-pseudo,collab-messages-text-code-102025.github .hljs-selector-tag{color:#22863a}collab-messages-text-code-102025.github .hljs-subst{color:#24292e}collab-messages-text-code-102025.github .hljs-section{color:#005cc5;font-weight:700}collab-messages-text-code-102025.github .hljs-bullet{color:#735c0f}collab-messages-text-code-102025.github .hljs-emphasis{color:#24292e;font-style:italic}collab-messages-text-code-102025.github .hljs-strong{color:#24292e;font-weight:700}collab-messages-text-code-102025.github .hljs-addition{color:#22863a;background-color:#f0fff4}collab-messages-text-code-102025.github .hljs-deletion{color:#b31d28;background-color:#ffeef0}`);
        this.language = 'typescript';
        this.languages = [];
        this.text = '';
    }
    updated(changedProperties) {
        if (changedProperties.has('language')) {
            if (!window.hljsLoaded) {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js';
                script.onload = () => {
                    window.hljsLoaded = true;
                    this.setCode();
                };
                document.head.appendChild(script);
            }
            else {
                this.setCode();
            }
        }
        if (changedProperties.has('text')) {
            if (!this.codeBlock)
                return;
            this.waitForLoadIfNeeded(() => {
                this.setCode();
            });
        }
        if (changedProperties.has('languages')) {
            if (this.select)
                this.select.value = this.language;
        }
    }
    waitForLoadIfNeeded(callback, timeout = 10000, interval = 100) {
        let elapsedTime = 0;
        const checkVariable = () => {
            if (window.hljsLoaded) {
                callback();
            }
            else if (elapsedTime < timeout) {
                elapsedTime += interval;
                setTimeout(checkVariable, interval);
            }
            else {
                console.error(`Error on load highlight.js. please try again`);
            }
        };
        checkVariable();
    }
    unescapeHtml(str) {
        const map = {
            '&lt;': '<',
            '&gt;': '>',
            '&quot;': '"',
            '&#039;': "'",
            '&amp;': '&',
        };
        let result = str;
        let changed = true;
        while (changed) {
            changed = false;
            result = result.replace(/&(lt|gt|quot|#039|amp);/g, (match) => {
                changed = true;
                return map[match] ?? match;
            });
        }
        return result;
    }
    setCode() {
        if (!this.codeBlock)
            return;
        this.codeBlock.innerHTML = '';
        this.codeBlock.removeAttribute('data-highlighted');
        this.codeBlock.classList.add('language-' + this.language);
        const that = this;
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            window.hljs.configure({ ignoreUnescapedHTML: true });
            if (!that.languages || that.languages.length === 0)
                that.languages = window.hljs.listLanguages();
            const res = window.hljs.highlight(this.unescapeHtml(this.text), { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
        });
    }
    firstUpdated() {
        this.setCode();
    }
    render() {
        return html `
       <pre>
            <code class="code" spellcheck="false"></code>
       </pre>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabMessagesTextCode.prototype, "config", void 0);
__decorate([
    property({ type: String, reflect: true, attribute: true })
], CollabMessagesTextCode.prototype, "language", void 0);
__decorate([
    property({ type: Array })
], CollabMessagesTextCode.prototype, "languages", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabMessagesTextCode.prototype, "text", void 0);
__decorate([
    query('.code')
], CollabMessagesTextCode.prototype, "codeBlock", void 0);
__decorate([
    query('select')
], CollabMessagesTextCode.prototype, "select", void 0);
CollabMessagesTextCode = __decorate([
    customElement('collab-messages-text-code-102025')
], CollabMessagesTextCode);
export { CollabMessagesTextCode };
