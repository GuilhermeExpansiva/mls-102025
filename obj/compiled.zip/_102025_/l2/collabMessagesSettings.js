/// <mls fileReference="_102025_/l2/collabMessagesSettings.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { updateUsers, listThreads } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { msgGetUserUpdate, msgUpdateUserDetails } from '/_102025_/l2/shared/api.js';
import { loadChatPreferences, saveChatPreferences, saveNotificationPreferencesAudio, loadNotificationPreferencesAudio, loadNotificationPreferences, registerToken, saveNotificationPreferences, saveOpenClawIntegrations, loadOpenClawIntegrations, generateUUIDv7, generateAgentAvatar, } from '/_102025_/l2/collabMessagesHelper.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_user, collab_minus, collab_ban, collab_dot, collab_message, collab_bell, collab_plug, collab_plus, collab_trash, collab_robot, collab_refresh, collab_copy, collab_chevron_left, collab_edit, collab_xmark, collab_floppy_disk, collab_check } from '/_102025_/l2/collabMessagesIcons.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    save: 'Salvar',
    status: 'Status',
    userid: 'Id do usuário',
    username: 'Nome do usuário',
    errorUserName: 'Nome do usuário não pode ser vazio',
    successSavingUser: 'Perfil do usuário atualizado com sucesso',
    successSavingChatPref: 'Preferências do chat atualizado com sucesso',
    chatPref: 'Preferências do chat',
    translate: 'Tradução',
    preferLanguage: 'Idioma preferido',
    userTitle: 'Usuário',
    prefNotification: 'Preferências de notificação',
    infoNotification: 'Avisamos quando houver mudanças e novas mensagens, sem pop-ups, só sincronismo, mais velocidade para você',
    moreNotification: 'Saiba mais',
    notificationStatusEnabled: 'Notificações ativadas',
    notificationStatusFailed: 'Não foi possivel ativar as notificações, verificar permissões no browser',
    btnEnableNotifications: 'Ativar notificações',
    soundEnable: 'Ativar som nas notificações',
    // Avatar
    changeAvatar: 'Alterar',
    editAvatar: 'Editar Avatar',
    avatarUrl: 'URL do Avatar',
    avatarUrlPlaceholder: 'https://exemplo.com/imagem.png',
    invalidAvatarUrl: 'URL inválida ou imagem não encontrada',
    // OpenClaw Integration
    integrationsTitle: 'Integrações - OpenClaw',
    addIntegration: 'Adicionar',
    removeIntegration: 'Remover Integração',
    editIntegration: 'Editar',
    integrationDetails: 'Detalhes da Integração',
    integrationName: 'Nome da Integração',
    serverUrl: 'URL do Servidor',
    bearerToken: 'Token de Autenticação',
    generateToken: 'Gerar Token',
    copyToken: 'Copiar Token',
    tokenCopied: 'Token copiado!',
    addAgent: 'Adicionar Agente',
    removeAgent: 'Remover',
    agentName: 'Nome do Agente',
    agentAvatar: 'Avatar URL (opcional)',
    senderId: 'Sender ID',
    agents: 'Agentes',
    noAgents: 'Nenhum agente configurado',
    noIntegrations: 'Nenhuma integração configurada',
    cancel: 'Cancelar',
    confirmRemoveIntegration: 'Remover esta integração?',
    confirmRemoveAgent: 'Remover este agente?',
    errorAgentName: 'Nome do agente é obrigatório',
    errorIntegrationName: 'Nome da integração é obrigatório',
    successSavingIntegration: 'Integração salva com sucesso',
    successRemoveIntegration: 'Integração removida com sucesso',
    configureAgent: 'Configurar Agente',
    generateAvatar: 'Gerar Avatar',
    back: 'Voltar',
    integrationRemoveInfo: 'Ao remover esta integração, os agentes vinculados a ela serão desconectados.',
    // Novas mensagens para confirmação de remoção
    deleteConfirmTitle: 'Confirmar remoção',
    deleteConfirmInstruction: 'Digite o nome da integração para confirmar:',
    deleteConfirmPlaceholder: 'Nome da integração',
    deleteConfirmButton: 'Confirmar remoção',
    deleteConfirmError: 'O nome digitado não corresponde ao nome da integração'
};
const message_en = {
    loading: 'Loading...',
    save: 'Save',
    status: 'Status',
    userid: 'User Id',
    username: 'UserName',
    errorUserName: 'User name cannot be empty',
    successSavingUser: 'User perfil updated successfully',
    successSavingChatPref: 'Chat preferences updated successfully',
    chatPref: 'Chat Preferences',
    translate: 'Translate',
    preferLanguage: 'Preferred language',
    userTitle: 'User',
    prefNotification: 'Notification Preferences',
    infoNotification: 'We\'ll notify you when there are changes and new messages — no pop-ups, just seamless syncing for faster performance.',
    moreNotification: 'Learn more',
    notificationStatusEnabled: 'Notifications enabled',
    btnEnableNotifications: 'Enable notifications',
    notificationStatusFailed: 'Unable to enable notifications, check browser permissions',
    soundEnable: 'Enable sound for notifications',
    // Avatar
    changeAvatar: 'Change',
    editAvatar: 'Edit Avatar',
    avatarUrl: 'Avatar URL',
    avatarUrlPlaceholder: 'https://example.com/image.png',
    invalidAvatarUrl: 'Invalid URL or image not found',
    // OpenClaw Integration
    integrationsTitle: 'Integrations - OpenClaw',
    addIntegration: 'Add',
    removeIntegration: 'Remove Integration',
    editIntegration: 'Edit',
    integrationDetails: 'Integration Details',
    integrationName: 'Integration Name',
    serverUrl: 'Server URL',
    bearerToken: 'Bearer Token',
    generateToken: 'Generate Token',
    copyToken: 'Copy Token',
    tokenCopied: 'Token copied!',
    addAgent: 'Add Agent',
    removeAgent: 'Remove',
    agentName: 'Agent Name',
    agentAvatar: 'Avatar URL (optional)',
    senderId: 'Sender ID',
    agents: 'Agents',
    noAgents: 'No agents configured',
    noIntegrations: 'No integrations configured',
    cancel: 'Cancel',
    confirmRemoveIntegration: 'Remove this integration?',
    confirmRemoveAgent: 'Remove this agent?',
    errorAgentName: 'Agent name is required',
    errorIntegrationName: 'Integration name is required',
    successSavingIntegration: 'Integration saved successfully',
    successRemoveIntegration: 'Integration removed successfully',
    configureAgent: 'Configure Agent',
    generateAvatar: 'Generate Avatar',
    back: 'Back',
    integrationRemoveInfo: 'Removing this integration will disconnect the agents linked to it.',
    // New messages for delete confirmation
    deleteConfirmTitle: 'Confirm removal',
    deleteConfirmInstruction: 'Type the integration name to confirm:',
    deleteConfirmPlaceholder: 'Integration name',
    deleteConfirmButton: 'Confirm removal',
    deleteConfirmError: 'The typed name does not match the integration name'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let CollabMessagesSettings = class CollabMessagesSettings extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-102025{display:block;overflow:auto;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding:1rem;height:calc(100% - 41px)}collab-messages-settings-102025 .section{padding:1rem .75rem;border-radius:10px;box-shadow:#d2d2d2 0 1px 4px;margin-bottom:3rem}collab-messages-settings-102025 .section h4{display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem;margin-block-start:0;padding-bottom:.4rem;border-bottom:1px solid #d2d2d2}collab-messages-settings-102025 .section h4 svg{width:20px;height:20px}collab-messages-settings-102025 .section .info-message{width:100%;font-size:12px;color:var(--text-primary-color-lighter);border-radius:6px}collab-messages-settings-102025 .section .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-settings-102025 .section .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-settings-102025 .section .saving-error{color:var(--error-color);font-size:var(--font-size-12)}collab-messages-settings-102025 .section .form-field{margin-bottom:1rem}collab-messages-settings-102025 .section .form-field label{display:block;font-size:var(--font-size-12);margin-bottom:.3rem}collab-messages-settings-102025 .section .form-field .avatar-input-group{display:flex;gap:.5rem;align-items:center}collab-messages-settings-102025 .section .form-field .avatar-input-group input{flex:1}collab-messages-settings-102025 .section .form-actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:.75rem;margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--grey-color)}collab-messages-settings-102025 .section input,collab-messages-settings-102025 .section select{display:flex;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;max-height:30px;height:30px}collab-messages-settings-102025 .section button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:inline-flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer;white-space:nowrap;flex-shrink:0}collab-messages-settings-102025 .section button svg{flex-shrink:0}collab-messages-settings-102025 .section button:hover{background-color:var(--info-color-hover)}collab-messages-settings-102025 .section button svg{fill:currentColor}collab-messages-settings-102025 .section button.btn-icon{width:32px;height:32px;padding:.25rem;border-radius:6px;background-color:var(--bg-secondary-color);color:var(--text-primary-color)}collab-messages-settings-102025 .section button.btn-icon:hover{background-color:var(--bg-secondary-color-hover)}collab-messages-settings-102025 .section button.btn-icon svg{width:16px;height:16px}collab-messages-settings-102025 .section button.btn-icon.btn-danger{background-color:transparent;color:var(--error-color)}collab-messages-settings-102025 .section button.btn-icon.btn-danger:hover{background-color:rgba(255,77,79,0.1)}collab-messages-settings-102025 .section button.btn-icon.btn-danger svg{fill:var(--error-color)}collab-messages-settings-102025 .section button.btn-icon.copied{background-color:var(--success-color);color:white}collab-messages-settings-102025 .section button.btn-icon.copied svg{fill:white}collab-messages-settings-102025 .section button.btn-small{height:32px;font-size:var(--font-size-12);padding:.25rem .5rem;display:inline-flex;align-items:center;gap:.3rem}collab-messages-settings-102025 .section button.btn-small svg{width:14px;height:14px}collab-messages-settings-102025 .section button.btn-secondary{background-color:var(--bg-secondary-color);color:var(--text-primary-color)}collab-messages-settings-102025 .section button.btn-secondary:hover{background-color:var(--bg-secondary-color-hover)}collab-messages-settings-102025 .section button.btn-primary{background-color:var(--info-color);color:white}collab-messages-settings-102025 .section button.btn-primary:hover{background-color:var(--info-color-hover)}collab-messages-settings-102025 .section button.btn-danger-outline{background-color:transparent !important;color:var(--error-color) !important;border:1px solid var(--error-color) !important}collab-messages-settings-102025 .section button.btn-danger-outline:hover{background-color:rgba(255,77,79,0.1) !important}collab-messages-settings-102025 .section button.btn-danger-outline svg{width:16px;height:16px;fill:var(--error-color)}collab-messages-settings-102025 .section button.btn-back{width:32px;height:32px;padding:.25rem;border-radius:6px;background-color:transparent;color:var(--text-primary-color);box-shadow:none;margin-right:.5rem}collab-messages-settings-102025 .section button.btn-back:hover{background-color:var(--bg-secondary-color)}collab-messages-settings-102025 .section button.btn-back svg{width:20px;height:20px}collab-messages-settings-102025 .user .user-content{display:flex;gap:1.5rem;align-items:flex-start}@media (max-width:768px){collab-messages-settings-102025 .user .user-content{flex-direction:column;align-items:center}}collab-messages-settings-102025 .user .avatar-section{display:flex;flex-direction:column;align-items:center;gap:.75rem;flex-shrink:0}collab-messages-settings-102025 .user .avatar img{width:80px;height:80px;border-radius:50%;object-fit:cover;border:2px solid var(--grey-color)}collab-messages-settings-102025 .user .avatar .avatar-placeholder{width:80px;height:80px;border-radius:50%;background-color:var(--grey-color);display:flex;align-items:center;justify-content:center;border:2px solid var(--grey-color-dark)}collab-messages-settings-102025 .user .avatar .avatar-placeholder svg{width:36px;height:36px;color:var(--text-primary-color-lighter)}collab-messages-settings-102025 .user .user-info{flex:1;min-width:0;width:100%}@media (max-width:768px){collab-messages-settings-102025 .user .user-info{width:100%}}collab-messages-settings-102025 .user .user-info-item{margin-bottom:1rem}collab-messages-settings-102025 .user .user-info-item label{display:block;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);margin-bottom:.25rem}collab-messages-settings-102025 .user .user-info-item input{width:100%;padding:.5rem;height:auto;max-height:none;box-sizing:border-box}collab-messages-settings-102025 .user .user-info-item span{display:flex;align-items:center;gap:.5rem;font-size:var(--font-size-16)}collab-messages-settings-102025 .user .user-info-item .user-id{font-family:monospace;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);word-break:break-all}collab-messages-settings-102025 .user .user-info-item.status .blocked svg{color:var(--error-color);fill:var(--error-color)}collab-messages-settings-102025 .user .user-info-item.status .active svg{color:var(--success-color);fill:var(--success-color)}collab-messages-settings-102025 .user .user-info-row{display:flex;gap:2rem;flex-wrap:wrap}collab-messages-settings-102025 .user .user-info-row .user-info-item{flex:1;min-width:120px}collab-messages-settings-102025 .edit-avatar .avatar-edit-content{display:flex;align-items:flex-start;gap:1.5rem}@media (max-width:544px){collab-messages-settings-102025 .edit-avatar .avatar-edit-content{flex-direction:column;align-items:center}}collab-messages-settings-102025 .edit-avatar .avatar-preview-small{flex-shrink:0}collab-messages-settings-102025 .edit-avatar .avatar-preview-small img{width:80px;height:80px;border-radius:50%;object-fit:cover;border:2px solid var(--grey-color)}collab-messages-settings-102025 .edit-avatar .avatar-preview-small .avatar-placeholder{width:80px;height:80px;border-radius:50%;background-color:var(--grey-color);display:flex;align-items:center;justify-content:center;border:2px solid var(--grey-color-dark)}collab-messages-settings-102025 .edit-avatar .avatar-preview-small .avatar-placeholder svg{width:36px;height:36px;color:var(--text-primary-color-lighter)}collab-messages-settings-102025 .edit-avatar .avatar-preview-small .avatar-loading{width:80px;height:80px;border-radius:50%;background-color:var(--grey-color-light);display:flex;align-items:center;justify-content:center;border:2px solid var(--grey-color)}collab-messages-settings-102025 .edit-avatar .avatar-url-field{flex:1;min-width:0}@media (max-width:544px){collab-messages-settings-102025 .edit-avatar .avatar-url-field{width:100%}}collab-messages-settings-102025 .edit-avatar .avatar-url-field label{display:block;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);margin-bottom:.25rem}collab-messages-settings-102025 .edit-avatar .avatar-url-field input{width:100%;padding:.5rem;height:auto;max-height:none;box-sizing:border-box}collab-messages-settings-102025 .edit-avatar .avatar-url-field .saving-error{display:block;margin-top:.25rem}collab-messages-settings-102025 .notification-preferences details{margin-top:1rem}collab-messages-settings-102025 .notification-preferences details>summary{cursor:pointer}collab-messages-settings-102025 .notification-preferences details>div{padding-left:1rem}collab-messages-settings-102025 .notification-preferences .notification-audio-config{margin-top:1rem;display:flex;align-items:center;gap:.5rem}collab-messages-settings-102025 .notification-preferences .notification-audio-config label{font-size:.95rem;cursor:pointer;display:flex;align-items:center;gap:.3rem}collab-messages-settings-102025 .notification-preferences .notification-audio-config input[type="checkbox"]{width:16px;height:16px;cursor:pointer}collab-messages-settings-102025 .chat-preferences .chat-config-item{display:flex;flex-direction:column;gap:.3rem;margin-bottom:1rem}collab-messages-settings-102025 .chat-preferences .chat-config-item.action{display:flex;justify-content:end;align-items:end}collab-messages-settings-102025 .integrations .no-items{color:var(--text-primary-color-lighter);font-style:italic;margin:.5rem 0}collab-messages-settings-102025 .integrations .integrations-list{list-style:none;padding:0;margin:0 0 1rem 0}collab-messages-settings-102025 .integrations .integration-item{display:flex;justify-content:space-between;align-items:center;padding:.75rem;background-color:var(--bg-secondary-color-lighter);border:1px solid var(--grey-color);border-radius:6px;margin-bottom:.5rem}collab-messages-settings-102025 .integrations .integration-item:last-child{margin-bottom:0}collab-messages-settings-102025 .integrations .integration-item .integration-info{display:flex;flex-direction:column;gap:.2rem}collab-messages-settings-102025 .integrations .integration-item .integration-info .integration-name{font-weight:var(--font-weight-bold)}collab-messages-settings-102025 .integrations .integration-item .integration-info .integration-meta{font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}collab-messages-settings-102025 .integrations .integration-actions{display:flex;justify-content:flex-start;margin-top:1rem}collab-messages-settings-102025 .integrations .btn-add{display:inline-flex;align-items:center;gap:.4rem}collab-messages-settings-102025 .integrations .btn-add svg{width:16px;height:16px}collab-messages-settings-102025 .integration-details svg{fill:currentColor}collab-messages-settings-102025 .integration-details .form-field{margin-bottom:1rem}collab-messages-settings-102025 .integration-details .form-field input[type="url"],collab-messages-settings-102025 .integration-details .form-field input[type="text"]{width:100%;padding:.5rem;height:auto;box-sizing:border-box}collab-messages-settings-102025 .integration-details .form-field .token-field{display:flex;gap:.5rem;align-items:center}collab-messages-settings-102025 .integration-details .form-field .token-field input{flex:1;font-family:monospace;font-size:var(--font-size-12)}collab-messages-settings-102025 .integration-details .agents-section{margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--grey-color)}collab-messages-settings-102025 .integration-details .agents-section .agents-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem}collab-messages-settings-102025 .integration-details .agents-section .agents-list{display:flex;flex-direction:column;gap:.5rem}collab-messages-settings-102025 .integration-details .form-actions{display:flex;justify-content:flex-start;margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--grey-color)}collab-messages-settings-102025 .integration-details .delete-confirmation{width:100%;animation:slideDown .2s ease}@keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}collab-messages-settings-102025 .integration-details .delete-confirmation label{display:block;font-size:var(--font-size-12);color:var(--text-primary-color);margin-top:1rem;margin-bottom:.25rem}collab-messages-settings-102025 .integration-details .delete-confirmation .confirm-name{display:block;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);font-family:monospace;margin-bottom:.5rem}collab-messages-settings-102025 .integration-details .delete-confirmation input{width:100%;padding:.5rem;height:auto !important;max-height:none !important;box-sizing:border-box}collab-messages-settings-102025 .integration-details .delete-confirmation .delete-actions{display:flex;justify-content:flex-end;gap:.5rem;margin-top:.75rem}collab-messages-settings-102025 .integration-details .delete-confirmation .delete-actions button{height:32px;font-size:var(--font-size-12);padding:0 .75rem;box-shadow:none}collab-messages-settings-102025 .integration-details .delete-confirmation .delete-actions .btn-cancel{background:transparent;color:var(--text-primary-color);border:1px solid var(--grey-color-dark)}collab-messages-settings-102025 .integration-details .delete-confirmation .delete-actions .btn-cancel:hover{background:var(--bg-secondary-color)}collab-messages-settings-102025 .integration-details .delete-confirmation .delete-actions .btn-confirm{background:var(--error-color);color:white}collab-messages-settings-102025 .integration-details .delete-confirmation .delete-actions .btn-confirm:hover:not(:disabled){background:var(--error-color-hover)}collab-messages-settings-102025 .integration-details .delete-confirmation .delete-actions .btn-confirm:disabled{background:var(--grey-color-dark);color:var(--text-primary-color-lighter);cursor:not-allowed}collab-messages-settings-102025 .agent-card{display:flex;align-items:center;gap:.75rem;background-color:var(--bg-primary-color);border:1px solid var(--grey-color-light);border-radius:6px;padding:.5rem .75rem;min-width:0}collab-messages-settings-102025 .agent-card .agent-avatar{flex-shrink:0}collab-messages-settings-102025 .agent-card .agent-avatar img{max-height:40px}collab-messages-settings-102025 .agent-card .agent-info{flex:1;min-width:0;display:flex;flex-direction:column}collab-messages-settings-102025 .agent-card .agent-info .agent-name{font-weight:var(--font-weight-bold);font-size:var(--font-size-16);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-settings-102025 .agent-card .agent-info .agent-sender-id{font-family:monospace;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-settings-102025 .agent-card .btn-icon{flex-shrink:0}collab-messages-settings-102025 .add-agent-form .integration-context{color:var(--text-secondary-color);font-size:var(--font-size-12);margin-bottom:1rem}collab-messages-settings-102025 .add-agent-form .agent-preview{display:flex;align-items:center;gap:1rem;padding:1rem;background-color:var(--bg-secondary-color-lighter);border-radius:8px;margin-bottom:1.5rem}collab-messages-settings-102025 .add-agent-form .agent-preview .preview-avatar{width:60px;height:60px;border-radius:50%;object-fit:cover}collab-messages-settings-102025 .add-agent-form .agent-preview .preview-avatar-placeholder{width:60px;height:60px;border-radius:50%;background-color:var(--grey-color);display:flex;align-items:center;justify-content:center}collab-messages-settings-102025 .add-agent-form .agent-preview .preview-avatar-placeholder svg{width:30px;height:30px;color:var(--text-primary-color-lighter)}collab-messages-settings-102025 .add-agent-form .agent-preview .preview-info{display:flex;flex-direction:column}collab-messages-settings-102025 .add-agent-form .agent-preview .preview-info .preview-name{font-weight:var(--font-weight-bold);font-size:var(--font-size-20)}collab-messages-settings-102025 .add-agent-form .agent-preview .preview-info .preview-sender-id{font-family:monospace;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}`);
        this.msg = messages['en'];
        this.list = [];
        this.chatPreferences = {
            translationMode: 'icon',
            language: '',
            threadMaintenance: ''
        };
        this.audioEnabled = false;
        // Avatar edit states
        this.tempAvatarUrl = '';
        this.avatarUrlValid = true;
        this.avatarLoading = false;
        // OpenClaw Integration states
        this.integrations = [];
        this.viewMode = 'main';
        this.currentIntegrationId = '';
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.tokenCopiedId = '';
        // Delete confirmation states
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        this.deleteConfirmationError = '';
        this.labelOk = '';
        this.labelError = '';
        this.labelOkPref = '';
        this.labelErrorPref = '';
        this.labelOkNotification = '';
        this.labelErrorNotification = '';
        this.labelOkIntegration = '';
        this.labelErrorIntegration = '';
        this.isSavingUser = false;
        this.isSavingChat = false;
        this.isSavingNotification = false;
        this.isSavingIntegration = false;
    }
    async firstUpdated(changedProperties) {
        super.updated(changedProperties);
        this.list = await listThreads();
        this.userPerfil = await this.getUserPerfil();
        this.chatPreferences = loadChatPreferences();
        const audioPref = loadNotificationPreferencesAudio();
        this.audioEnabled = audioPref;
        this.integrations = loadOpenClawIntegrations();
    }
    updated() {
        const select = this.renderRoot.querySelector('select#selectThread');
        if (select) {
            select.value = this.chatPreferences?.threadMaintenance ?? '';
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.viewMode === 'editAvatar') {
            return this.renderEditAvatarView();
        }
        if (this.viewMode === 'integrationDetails') {
            return this.renderIntegrationDetailsView();
        }
        if (this.viewMode === 'addAgent') {
            return this.renderAddAgentView();
        }
        return html `
            ${this.renderUser()}
            ${this.renderChatPreferences()}
            ${this.renderPreferencesNotifications()}
            ${this.renderOpenClawIntegrations()}
        `;
    }
    renderUser() {
        const avatarUrl = this.userPerfil?.avatar_url;
        const iconByStatus = {
            'active': collab_dot,
            'deleted': collab_minus,
            'blocked': collab_ban,
            '': html ``,
        };
        const icon = iconByStatus[this.userPerfil?.status || ''];
        return html `
        <div>
            <div class="section user">
                <h4>${collab_user} ${this.msg.userTitle}</h4>

                <div class="user-content">
                    <div class="avatar-section">
                        <div class="avatar">
                            ${avatarUrl
            ? html `<img src="${avatarUrl}" alt="Avatar" />`
            : html `<div class="avatar-placeholder">${collab_user}</div>`}
                        </div>
                        <button class="btn-small btn-secondary" @click=${this.handleOpenEditAvatar}>
                            ${collab_edit} ${this.msg.changeAvatar}
                        </button>
                    </div>

                    <div class="user-info">
                        <div class="user-info-item">
                            <label>${this.msg.username}</label>
                            <input
                                .value=${this.userPerfil?.name ?? ''} 
                                type="text" 
                                @input=${this.handleNameInput}
                            />
                        </div>
                        <div class="user-info-row">
                            <div class="user-info-item">
                                <label>${this.msg.userid}</label>
                                <span class="user-id">${this.userPerfil?.userId ?? ''}</span>
                            </div>
                            <div class="user-info-item status">
                                <label>${this.msg.status}</label>
                                <span class=${this.userPerfil?.status}>${this.userPerfil?.status ?? 'N/A'} ${icon}</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <button @click=${this.handleSave} ?disabled=${this.isSavingUser}>
                        ${this.isSavingUser ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.save}`}
                    </button>
                </div>
                ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}</small>` : ''}
                ${this.labelError ? html `<small class="saving-error">${this.labelError}</small>` : ''}      
            </div>
        </div>
        `;
    }
    renderEditAvatarView() {
        const previewUrl = this.tempAvatarUrl || this.userPerfil?.avatar_url || '';
        return html `
        <div>
            <div class="section edit-avatar">
                <h4>
                    <button class="btn-back" @click=${this.handleCancelEditAvatar}>
                        ${collab_chevron_left}
                    </button>
                    ${collab_user} ${this.msg.editAvatar}
                </h4>

                <div class="avatar-edit-content">
                    <div class="avatar-preview-small">
                        ${this.avatarLoading
            ? html `<div class="avatar-loading"><span class="loader"></span></div>`
            : previewUrl && this.avatarUrlValid
                ? html `<img src="${previewUrl}" alt="Preview" @error=${this.handleAvatarError} />`
                : html `<div class="avatar-placeholder">${collab_user}</div>`}
                    </div>
                    <div class="avatar-url-field">
                        <label>${this.msg.avatarUrl}</label>
                        <input 
                            type="url" 
                            .value=${this.tempAvatarUrl}
                            @input=${this.handleAvatarUrlInput}
                            placeholder="${this.msg.avatarUrlPlaceholder}"
                        />
                        ${!this.avatarUrlValid && this.tempAvatarUrl
            ? html `<small class="saving-error">${this.msg.invalidAvatarUrl}</small>`
            : ''}
                    </div>
                </div>

                <div class="form-actions">
                    <button class="btn-secondary" @click=${this.handleCancelEditAvatar}>
                        ${collab_xmark} ${this.msg.cancel}
                    </button>
                    <button @click=${this.handleSaveAvatar} ?disabled=${!this.avatarUrlValid || this.avatarLoading}>
                        ${collab_check} ${this.msg.changeAvatar}
                    </button>
                </div>
            </div>
        </div>
        `;
    }
    renderChatPreferences() {
        return html `<div>
        <div class="section chat-preferences">
            <h4>${collab_message} ${this.msg.chatPref}</h4>
            <div class="chat-config-item form-field">
                <label for="translationMode">${this.msg.translate}:</label>
                <select id="translationMode" @change=${this.handleTranslationModeChange} .value=${this.chatPreferences?.translationMode ?? 'icon'}>
                    <option value="none">none</option>
                    <option value="icon">icon</option>
                    <option value="text">text</option>
                    <option value="iconText">icon + text</option>
                    <option value="trace">trace</option>
                </select>
            </div>
            <div class="chat-config-item form-field">
                <label>${this.msg.preferLanguage}:</label>
                <input @input=${this.handleLanguageInput} .value=${this.chatPreferences?.language ?? ''} type="text" />
            </div>
            <div class="chat-config-item action">
                <button @click=${this.handleSaveChatPref} ?disabled=${this.isSavingChat}>
                    ${this.isSavingChat ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.save}`}
                </button>
            </div>
            ${this.labelOkPref ? html `<small class="saving-ok">${this.labelOkPref}<small>` : ''}
            ${this.labelErrorPref ? html `<small class="saving-error">${this.labelErrorPref}<small>` : ''}    
        </div>
    </div>`;
    }
    renderPreferencesNotifications() {
        this.notificationPreferences = this.getNotificationStatus();
        return html `
        <div>
            <div class="section notification-preferences">
                <h4>${collab_bell} ${this.msg.prefNotification}</h4>

                ${this.notificationPreferences === 'granted' ?
            html `
                        <div>${this.msg.notificationStatusEnabled}</div>
                        ${this.renderReadMore()}
                    ` :
            html `
                        <button @click=${this.onEnabledNotifications} ?disabled=${this.isSavingNotification}>
                            ${this.isSavingNotification ? html `<span class="loader"></span>` : this.msg.btnEnableNotifications}
                        </button>
                        <br>
                        ${this.labelOkNotification ? html `<small class="saving-ok">${this.labelOkNotification}<small>` : ''}
                        ${this.labelErrorNotification ? html `<small class="saving-error">${this.labelErrorNotification}<small>` : ''}   
                        ${this.renderReadMore()}
                    `}
            <div class="notification-audio-config">
                <label>
                    <input type="checkbox" .checked=${this.audioEnabled} @change=${this.handleAudioToggle} />
                    ${this.msg.soundEnable}
                </label>
            </div>
        </div>
        `;
    }
    renderOpenClawIntegrations() {
        return html `
        <div>
            <div class="section integrations">
                <h4>${collab_plug} ${this.msg.integrationsTitle}</h4>

                ${this.integrations.length === 0
            ? html `<p class="no-items">${this.msg.noIntegrations}</p>`
            : html `
                        <ul class="integrations-list">
                            ${this.integrations.map(integration => html `
                                <li class="integration-item">
                                    <div class="integration-info">
                                        <span class="integration-name">${integration.name || `Integration #${integration.id.slice(0, 8)}`}</span>
                                        <span class="integration-meta">${integration.agents.length} ${this.msg.agents.toLowerCase()}</span>
                                    </div>
                                    <button class="btn-small btn-secondary" @click=${() => this.handleOpenIntegrationDetails(integration.id)}>
                                        ${collab_edit} ${this.msg.editIntegration}
                                    </button>
                                </li>
                            `)}
                        </ul>
                    `}
                <div class="integration-actions">
                    <button class="btn-add" @click=${this.handleAddIntegration}>
                        ${collab_plus} ${this.msg.addIntegration}
                    </button>
                </div>
            </div>
        </div>`;
    }
    renderIntegrationDetailsView() {
        const integration = this.integrations.find(i => i.id === this.currentIntegrationId);
        if (!integration)
            return html ``;
        const isTokenCopied = this.tokenCopiedId === integration.id;
        return html `
        <div>
            <div class="section integrations integration-details">
                    <h4>
                <button class="btn-back" @click=${this.handleBackToMain}>
                    ${collab_chevron_left}
                </button>
                ${collab_plug} ${this.msg.integrationDetails}
            </h4>
                <div class="form-field">
                    <label>${this.msg.integrationName}</label>
                    <input 
                        type="text" 
                        .value=${integration.name} 
                        @input=${(e) => this.handleIntegrationNameChange(integration.id, e)} 
                        placeholder="Ex: Production Server"
                    />
                </div>

                <div class="form-field">
                    <label>${this.msg.serverUrl}</label>
                    <input 
                        type="url" 
                        .value=${integration.url} 
                        @input=${(e) => this.handleIntegrationUrlChange(integration.id, e)} 
                        placeholder="https://openclaw.example.com"
                    />
                </div>
                
                <div class="form-field">
                    <label>${this.msg.bearerToken}</label>
                    <div class="token-field">
                        <input type="text" .value=${integration.bearerToken} readonly />
                        <button class="btn-icon" @click=${() => this.handleGenerateToken(integration.id)} title="${this.msg.generateToken}">
                            ${collab_refresh}
                        </button>
                        <button class="btn-icon ${isTokenCopied ? 'copied' : ''}" @click=${() => this.handleCopyToken(integration)} title="${this.msg.copyToken}">
                            ${collab_copy}
                        </button>
                    </div>
                    ${isTokenCopied ? html `<small class="saving-ok">${this.msg.tokenCopied}</small>` : ''}
                </div>

                <div class="agents-section">
                    <div class="agents-header">
                        <label>${this.msg.agents}</label>
                        <button class="btn-small" @click=${() => this.handleOpenAddAgent(integration.id)}>
                            ${collab_plus} ${this.msg.addAgent}
                        </button>
                    </div>
                    ${integration.agents.length === 0
            ? html `<p class="no-items">${this.msg.noAgents}</p>`
            : html `
                            <div class="agents-list">
                                ${integration.agents.map(agent => this.renderAgent(integration.id, agent))}
                            </div>
                        `}
                </div>

                <div class="form-actions">
                    ${!integration.isLocal ? html `
                        <div class="info-message">
                            ${this.msg.integrationRemoveInfo}
                        </div>

                        <button 
                            class="btn-danger-outline" 
                            @click=${() => this.handleToggleDeleteConfirmation()}
                        >
                            ${collab_trash} ${this.msg.removeIntegration}
                        </button>
                        
                        ${this.renderDeleteConfirmation(integration)}
                    ` : nothing}
                </div>
                ${!this.showDeleteConfirmation ? html `
                <div class="form-actions">
                    <button class="btn-secondary" style="margin-left:auto" @click=${() => this.handleCancelIntegration(integration.id)}>
                        ${collab_xmark} ${this.msg.cancel}
                    </button>
                    <button  @click=${() => this.handleSaveIntegration(integration.id)}>
                        ${this.isSavingIntegration ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.save}`}
                    </button>
                </div>` : nothing}

                ${this.labelOkIntegration ? html `<small class="saving-ok">${this.labelOkIntegration}</small>` : ''}
                ${this.labelErrorIntegration ? html `<small class="saving-error">${this.labelErrorIntegration}</small>` : ''}
            </div>
        </div>`;
    }
    renderDeleteConfirmation(integration) {
        if (!this.showDeleteConfirmation)
            return nothing;
        const integrationName = integration.name || `Integration #${integration.id.slice(0, 8)}`;
        const isMatch = this.deleteConfirmationInput.trim() === integrationName;
        return html `
            <div class="delete-confirmation">
                <label>${this.msg.deleteConfirmInstruction}</label>
                <span class="confirm-name">${integrationName}</span>
                <input 
                    type="text" 
                    .value=${this.deleteConfirmationInput}
                    @input=${this.handleDeleteConfirmationInput}
                />
                <div class="delete-actions">
                    <button 
                        class="btn-cancel" 
                        @click=${this.handleCancelDelete}
                    >${this.msg.cancel}</button>
                    <button 
                        class="btn-confirm" 
                        @click=${() => this.handleConfirmDelete(integration.id, integrationName)}
                        ?disabled=${!isMatch || this.isSavingIntegration}
                    >${this.isSavingIntegration ? html `<span class="loader"></span>` : this.msg.deleteConfirmButton}</button>
                </div>
            </div>
        `;
    }
    renderAgent(integrationId, agent) {
        return html `
        <div class="agent-card">
            <div class="agent-avatar">
                <img src="${agent.avatarUrl}" alt="${agent.name}" />
            </div>
            <div class="agent-info">
                <span class="agent-name">${agent.name}</span>
                <span class="agent-sender-id">${agent.senderId}</span>
            </div>
            <button class="btn-icon btn-danger" @click=${() => this.handleRemoveAgent(integrationId, agent.id)} title="${this.msg.removeAgent}">
                ${collab_trash}
            </button>
        </div>`;
    }
    renderAddAgentView() {
        const integration = this.integrations.find(i => i.id === this.currentIntegrationId);
        if (!integration)
            return html ``;
        const previewAvatar = this.newAgentAvatarUrl || (this.newAgentName ? generateAgentAvatar(this.newAgentName) : '');
        const previewSenderId = this.newAgentName
            ? `integration:openclaw:${this.newAgentName.toLowerCase().replace(/\s+/g, '')}`
            : 'integration:openclaw:...';
        return html `
        <div>
            
            <div class="section add-agent-form">
            <h4>
                <button class="btn-back" @click=${this.handleBackToIntegrationDetails}>
                    ${collab_chevron_left}
                </button>
                ${collab_robot} ${this.msg.configureAgent}
            </h4>
                <p class="integration-context">${integration.name || `Integration #${integration.id.slice(0, 8)}`}</p>
                
                <div class="agent-preview">
                    ${previewAvatar
            ? html `<img src="${previewAvatar}" alt="Preview" class="preview-avatar" />`
            : html `<div class="preview-avatar-placeholder">${collab_robot}</div>`}
                    <div class="preview-info">
                        <span class="preview-name">${this.newAgentName || '...'}</span>
                        <span class="preview-sender-id">${previewSenderId}</span>
                    </div>
                </div>

                <div class="form-field">
                    <label>${this.msg.agentName} *</label>
                    <input type="text" .value=${this.newAgentName} @input=${this.handleNewAgentNameInput} placeholder="Ex: Assistant Bot" />
                </div>

                <div class="form-field">
                    <label>${this.msg.agentAvatar}</label>
                    <div class="avatar-input-group">
                        <input type="url" .value=${this.newAgentAvatarUrl} @input=${this.handleNewAgentAvatarInput} placeholder="https://..." />
                        <button class="btn-small" @click=${this.handleGenerateAgentAvatar}>
                            ${collab_refresh} ${this.msg.generateAvatar}
                        </button>
                    </div>
                </div>

            
                <div class="form-actions">
                    <button class="btn-secondary" @click=${this.handleBackToIntegrationDetails}>
                        ${this.msg.cancel}
                    </button>
                    <button class="btn-primary" @click=${this.handleSaveAgent}>
                        ${collab_floppy_disk} ${this.msg.save}
                    </button>
                </div>

                ${this.labelErrorIntegration ? html `<small class="saving-error">${this.labelErrorIntegration}</small>` : ''}
                
                
            </div>
        </div>`;
    }
    getNotificationStatus() {
        const notificationPreferences = loadNotificationPreferences();
        if ('Notification' in window) {
            const permission = Notification.permission;
            if (permission === this.notificationPreferences)
                return notificationPreferences;
            if (permission === 'granted' && notificationPreferences === 'denied') {
                saveNotificationPreferences('default');
                return 'default';
            }
            if (permission === 'denied' && notificationPreferences === 'granted') {
                saveNotificationPreferences('denied');
                return 'default';
            }
        }
        return notificationPreferences;
    }
    renderReadMore() {
        return html `
            <details>
                <summary>${this.msg.moreNotification}</summary>
                <div><span>${this.msg.infoNotification}</span></div>   
            </details>
        `;
    }
    // Avatar edit handlers
    handleOpenEditAvatar() {
        this.tempAvatarUrl = this.userPerfil?.avatar_url || '';
        this.avatarUrlValid = true;
        this.avatarLoading = false;
        this.viewMode = 'editAvatar';
    }
    handleCancelEditAvatar() {
        this.tempAvatarUrl = '';
        this.avatarUrlValid = true;
        this.avatarLoading = false;
        this.viewMode = 'main';
    }
    handleAvatarUrlInput(e) {
        const input = e.target;
        this.tempAvatarUrl = input.value;
        if (!this.tempAvatarUrl) {
            this.avatarUrlValid = true;
            return;
        }
        // Validate URL format
        try {
            new URL(this.tempAvatarUrl);
        }
        catch {
            this.avatarUrlValid = false;
            return;
        }
        // Test if image loads
        this.avatarLoading = true;
        const img = new Image();
        img.onload = () => {
            this.avatarLoading = false;
            this.avatarUrlValid = true;
        };
        img.onerror = () => {
            this.avatarLoading = false;
            this.avatarUrlValid = false;
        };
        img.src = this.tempAvatarUrl;
    }
    handleAvatarError() {
        this.avatarUrlValid = false;
    }
    handleSaveAvatar() {
        if (!this.avatarUrlValid || this.avatarLoading)
            return;
        if (this.userPerfil) {
            this.userPerfil = { ...this.userPerfil, avatar_url: this.tempAvatarUrl };
        }
        this.viewMode = 'main';
    }
    // Delete confirmation handlers
    handleToggleDeleteConfirmation() {
        this.showDeleteConfirmation = !this.showDeleteConfirmation;
        this.deleteConfirmationInput = '';
        this.deleteConfirmationError = '';
    }
    handleDeleteConfirmationInput(e) {
        const input = e.target;
        this.deleteConfirmationInput = input.value;
        this.deleteConfirmationError = '';
    }
    handleCancelDelete() {
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        this.deleteConfirmationError = '';
    }
    async handleConfirmDelete(integrationId, integrationName) {
        if (this.deleteConfirmationInput.trim() !== integrationName) {
            return;
        }
        this.isSavingIntegration = true;
        const tempIntegrations = this.integrations.filter(i => i.id !== integrationId);
        try {
            await saveOpenClawIntegrations(tempIntegrations);
            this.labelOkIntegration = this.msg.successRemoveIntegration;
            this.integrations = tempIntegrations;
            this.showDeleteConfirmation = false;
            this.deleteConfirmationInput = '';
            this.handleBackToMain();
        }
        catch (err) {
            this.labelErrorIntegration = err.message;
        }
        finally {
            this.isSavingIntegration = false;
        }
    }
    // OpenClaw Integration handlers
    handleAddIntegration() {
        const newIntegration = {
            id: generateUUIDv7(),
            name: '',
            url: '',
            bearerToken: generateUUIDv7(),
            agents: [],
            createdAt: new Date().toISOString(),
            isLocal: true
        };
        this.integrations = [...this.integrations, newIntegration];
        this.currentIntegrationId = newIntegration.id;
        this.viewMode = 'integrationDetails';
    }
    handleOpenIntegrationDetails(integrationId) {
        this.currentIntegrationId = integrationId;
        this.labelOkIntegration = '';
        this.labelErrorIntegration = '';
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        this.viewMode = 'integrationDetails';
    }
    async handleRemoveIntegration(integrationId) {
        if (!confirm(this.msg.confirmRemoveIntegration))
            return;
        this.isSavingIntegration = true;
        const tempIntegrations = this.integrations.filter(i => i.id !== integrationId);
        try {
            await saveOpenClawIntegrations(tempIntegrations);
            this.labelOkIntegration = this.msg.successRemoveIntegration;
            this.integrations = tempIntegrations;
            this.handleBackToMain();
        }
        catch (err) {
            this.labelErrorIntegration = err.message;
        }
        finally {
            this.isSavingIntegration = false;
        }
    }
    handleCancelIntegration(integrationId) {
        this.integrations = this.integrations.filter(i => i.id !== integrationId && !i.isLocal);
        this.handleBackToMain();
    }
    async handleSaveIntegration(integrationId) {
        this.isSavingIntegration = true;
        this.integrations = this.integrations.map(i => {
            if (i.id === integrationId) {
                const { isLocal, ...rest } = i;
                return rest;
            }
            return i;
        });
        try {
            await saveOpenClawIntegrations(this.integrations);
            this.labelOkIntegration = this.msg.successSavingIntegration;
        }
        catch (err) {
            this.labelErrorIntegration = err.message;
        }
        finally {
            this.isSavingIntegration = false;
        }
    }
    handleIntegrationNameChange(integrationId, e) {
        const input = e.target;
        this.integrations = this.integrations.map(i => i.id === integrationId ? { ...i, name: input.value } : i);
    }
    handleIntegrationUrlChange(integrationId, e) {
        const input = e.target;
        this.integrations = this.integrations.map(i => i.id === integrationId ? { ...i, url: input.value } : i);
    }
    handleGenerateToken(integrationId) {
        this.integrations = this.integrations.map(i => i.id === integrationId ? { ...i, bearerToken: generateUUIDv7() } : i);
    }
    async handleCopyToken(integration) {
        await navigator.clipboard.writeText(integration.bearerToken);
        this.tokenCopiedId = integration.id;
        setTimeout(() => { this.tokenCopiedId = ''; }, 2000);
    }
    handleOpenAddAgent(integrationId) {
        this.currentIntegrationId = integrationId;
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.labelErrorIntegration = '';
        this.viewMode = 'addAgent';
    }
    handleBackToMain() {
        this.viewMode = 'main';
        this.currentIntegrationId = '';
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.labelErrorIntegration = '';
        this.labelOkIntegration = '';
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
    }
    handleBackToIntegrationDetails() {
        this.viewMode = 'integrationDetails';
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.labelErrorIntegration = '';
    }
    handleNewAgentNameInput(e) {
        const input = e.target;
        this.newAgentName = input.value;
    }
    handleNewAgentAvatarInput(e) {
        const input = e.target;
        this.newAgentAvatarUrl = input.value;
    }
    handleGenerateAgentAvatar() {
        if (this.newAgentName) {
            this.newAgentAvatarUrl = generateAgentAvatar(this.newAgentName);
        }
    }
    handleSaveAgent() {
        if (!this.newAgentName.trim()) {
            this.labelErrorIntegration = this.msg.errorAgentName;
            return;
        }
        const agentId = generateUUIDv7();
        const sanitizedName = this.newAgentName.toLowerCase().replace(/\s+/g, '');
        const newAgent = {
            id: agentId,
            name: this.newAgentName.trim(),
            avatarUrl: this.newAgentAvatarUrl || generateAgentAvatar(this.newAgentName),
            senderId: `integration:openclaw:${sanitizedName}`,
            createdAt: new Date().toISOString()
        };
        this.integrations = this.integrations.map(i => i.id === this.currentIntegrationId
            ? { ...i, agents: [...i.agents, newAgent] }
            : i);
        this.handleBackToIntegrationDetails();
        setTimeout(() => { this.labelOkIntegration = ''; }, 3000);
    }
    handleRemoveAgent(integrationId, agentId) {
        if (!confirm(this.msg.confirmRemoveAgent))
            return;
        this.integrations = this.integrations.map(i => i.id === integrationId
            ? { ...i, agents: i.agents.filter(a => a.id !== agentId) }
            : i);
    }
    // Original handlers
    handleAudioToggle(e) {
        const target = e.target;
        this.audioEnabled = target.checked;
        saveNotificationPreferencesAudio(this.audioEnabled);
    }
    async onEnabledNotifications() {
        this.labelErrorNotification = '';
        this.labelOkNotification = '';
        this.isSavingNotification = true;
        try {
            saveNotificationPreferences('default');
            const token = await registerToken();
            this.notificationPreferences = loadNotificationPreferences();
            this.isSavingNotification = false;
            if (token === null)
                this.labelOkNotification = this.msg.notificationStatusFailed;
            else
                this.labelOkNotification = this.msg.notificationStatusEnabled;
        }
        catch (err) {
            this.isSavingNotification = false;
            console.error('Error on enable notificatin:', err.message);
            this.labelErrorNotification = err.message;
        }
    }
    async getUserPerfil() {
        try {
            const result = await msgGetUserUpdate({ userId: "" });
            if (!result.success || !result.response?.user) {
                throw new Error(result.error || 'Failed to fetch user profile');
            }
            return result.response.user;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while fetching user profile');
        }
    }
    async handleSave() {
        this.labelError = '';
        this.labelOk = '';
        if (!this.userPerfil || !this.userPerfil.name) {
            this.labelError = this.msg.errorUserName;
            return;
        }
        this.isSavingUser = true;
        try {
            const result = await msgUpdateUserDetails({
                userId: this.userPerfil.userId,
                avatar_url: this.userPerfil.avatar_url,
                name: this.userPerfil.name,
                status: this.userPerfil.status,
                deviceId: this.userPerfil.notifications?.[0]?.deviceId || '',
                notificationToken: this.userPerfil.notifications?.[0]?.notificationToken || '',
            });
            if (!result.success || !result.response?.user) {
                this.labelError =
                    result.error || 'Failed to update user profile.';
                return;
            }
            this.labelOk = this.msg.successSavingUser || 'User profile updated successfully.';
            await updateUsers([result.response.user]);
        }
        catch (error) {
            console.error('Error updating user profile:', error);
            this.labelError =
                error?.message || 'An unexpected error occurred while saving the user profile.';
        }
        finally {
            this.isSavingUser = false;
        }
    }
    async handleSaveChatPref() {
        this.labelErrorPref = '';
        this.labelOkPref = '';
        this.isSavingChat = true;
        try {
            saveChatPreferences(this.chatPreferences);
            this.labelOkPref = `${this.msg.successSavingChatPref}`;
            this.isSavingChat = false;
        }
        catch (error) {
            console.error('Error on update chat preferences:', error);
            this.labelErrorPref = error.message;
            this.isSavingChat = false;
        }
    }
    handleTranslationModeChange(e) {
        const select = e.target;
        this.chatPreferences = { ...this.chatPreferences, translationMode: select.value };
    }
    handleLanguageInput(e) {
        const target = e.target;
        this.chatPreferences = { ...this.chatPreferences, language: target.value };
    }
    handleNameInput(e) {
        if (!this.userPerfil)
            return;
        const target = e.target;
        this.userPerfil.name = target.value;
    }
};
__decorate([
    state()
], CollabMessagesSettings.prototype, "userPerfil", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "chatPreferences", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "notificationPreferences", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "audioEnabled", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "tempAvatarUrl", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "avatarUrlValid", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "avatarLoading", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "integrations", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "viewMode", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "currentIntegrationId", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "newAgentName", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "newAgentAvatarUrl", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "tokenCopiedId", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "showDeleteConfirmation", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "deleteConfirmationInput", void 0);
__decorate([
    state()
], CollabMessagesSettings.prototype, "deleteConfirmationError", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "labelOk", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "labelError", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "labelOkPref", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "labelErrorPref", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "labelOkNotification", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "labelErrorNotification", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "labelOkIntegration", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "labelErrorIntegration", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "isSavingUser", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "isSavingChat", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "isSavingNotification", void 0);
__decorate([
    property()
], CollabMessagesSettings.prototype, "isSavingIntegration", void 0);
__decorate([
    query('.avatar img')
], CollabMessagesSettings.prototype, "userAvatarEl", void 0);
CollabMessagesSettings = __decorate([
    customElement('collab-messages-settings-102025')
], CollabMessagesSettings);
export { CollabMessagesSettings };
