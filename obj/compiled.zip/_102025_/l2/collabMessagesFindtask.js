/// <mls fileReference="_102025_/l2/collabMessagesFindtask.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getUserId } from "/_102025_/l2/collabMessagesHelper.js";
import '/_102025_/l2/collabMessagesTaskDetails.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    find: 'Buscar',
};
const message_en = {
    loading: 'Loading...',
    find: 'Search',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesFindTask = class CollabMessagesFindTask extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.isLoading = false;
    }
    async firstUpdated(changedProperties) {
        super.updated(changedProperties);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderSearch()}
        `;
    }
    renderSearch() {
        return html `
            <div class="section">
                <div>
                    <label class="title">MessageId</label>
                    <input
                        type="text"
                        @input=${(e) => this.handleThreadChange(e)}
                    /input>
                </div>
                <div>
                    <label class="title">TaskId</label>
                    <input
                        type="text"
                        @input=${(e) => this.handleTaskChange(e)}
                    /input>
                </div>
                <div>
                <button
                    @click=${this.findThread}
                    ?disabled=${this.isLoading}
                >
                    ${this.isLoading ? html `<span class="loader"></span>` : this.msg.find}
                </button>
            </div>
            </div>
            

            <collab-messages-task-details-102025 .task=${this.actualTask} taskId=${this.actualTask?.PK}></collab-messages-task-details-102025>
        
        `;
    }
    handleThreadChange(e) {
        const target = e.target;
        this.threadId = target.value.trim();
    }
    handleTaskChange(e) {
        const target = e.target;
        this.taskId = target.value.trim();
    }
    async findThread() {
        this.isLoading = true;
        try {
            const user = getUserId();
            if (!this.taskId || !this.threadId || !user)
                return;
            const rc = await mls.api.msgGetTaskUpdate({
                messageId: this.threadId,
                taskId: this.taskId,
                userId: user
            });
            this.actualTask = rc.task;
        }
        catch (err) {
            this.actualTask = undefined;
            this.serviceBase?.setError(err.message);
        }
        finally {
            this.isLoading = false;
        }
    }
};
__decorate([
    state()
], CollabMessagesFindTask.prototype, "threadId", void 0);
__decorate([
    state()
], CollabMessagesFindTask.prototype, "taskId", void 0);
__decorate([
    property()
], CollabMessagesFindTask.prototype, "actualTask", void 0);
__decorate([
    property()
], CollabMessagesFindTask.prototype, "isLoading", void 0);
CollabMessagesFindTask = __decorate([
    customElement('collab-messages-findtask-102025')
], CollabMessagesFindTask);
export { CollabMessagesFindTask };
