/// <mls fileReference="_102025_/l2/collabMessagesEvents.ts" enhancement="_blank"/>
export function notifyMessageSendChange(context) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('message-send', {
        detail: { context },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyTaskChange(context, oldContextCreateAt) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-change', {
        detail: { context, oldContextCreateAt },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyTaskCompleted(context, result) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-completed', {
        detail: { context, result },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadChange(thread) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-change', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyMessageChange(message) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('message-change', {
        detail: message,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadNotification(show) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-notification', {
        detail: show,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadCreate(thread) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-create', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function dispatchDetailsTaskClose(taskId) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-details-close', {
        detail: taskId,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function dispatchDetailsTaskClick(messageId, taskId, task, message) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-details-click', {
        detail: { messageId, taskId, task, message },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function dispatchThreadOpen(threadId, taskId) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-open', {
        detail: { taskId, threadId },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
