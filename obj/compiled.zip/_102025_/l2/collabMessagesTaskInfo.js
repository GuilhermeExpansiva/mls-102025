/// <mls fileReference="_102025_/l2/collabMessagesTaskInfo.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getClarification, getClarificationElement } from '/_100554_/l2/aiAgentOrchestration.js';
import { getNextPendentStep, getNextClarificationStep, getInteractionStepId, getStepById } from '/_100554_/l2/aiAgentHelper.js';
import '/_102025_/l2/collabMessagesTaskDetails.js';
import '/_102025_/l2/collabMessagesTaskPreview.js';
import '/_102025_/l2/collabMessagesTaskLogPreview.js';
let CollabMessagesTaskInfo = class CollabMessagesTaskInfo extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-info-102025{display:block;overflow:auto;font-family:var(--font-family-primary);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);height:100%;padding:0 .5rem;position:relative}collab-messages-task-info-102025 .viewraw{border:none;margin-top:2px;background:var(--bg-primary-color);color:var(--text-primary-color);cursor:pointer;position:absolute;right:5px;top:5px}collab-messages-task-info-102025 .tabs{display:flex;border-bottom:1px solid var(--grey-color);margin-bottom:1rem}collab-messages-task-info-102025 .tab{padding:.5rem 1rem;cursor:pointer;border-bottom:2px solid transparent;transition:border-color .3s,color .3s;font-size:.9rem;color:var(--text-primary-color-disabled)}collab-messages-task-info-102025 .tab:hover{color:var(--text-primary-color-darker)}collab-messages-task-info-102025 .tab.active{border-bottom:2px solid var(--link-color);font-weight:600;color:var(--text-primary-color-lighter-focus)}collab-messages-task-info-102025 .content{height:calc(100% - 1rem);padding:.5rem 0}`);
        this.forceViewRaw = false;
        this.isClarificationPending = false;
        this.hasTodo = true;
        this.task = undefined;
        this.message = undefined;
        this.stepid = '';
        this.seen = new Set();
        this.activeTab = 'todo';
    }
    connectedCallback() {
        super.connectedCallback();
        this.elParent = this.closest('collab-messages-chat-102025');
        if (this.elParent)
            this.elParent.style.width = '100%';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.elParent)
            this.elParent.style.width = '';
        window.removeEventListener('task-change', this.onTaskChange.bind(this));
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        window.addEventListener('task-change', this.onTaskChange.bind(this));
        if (this.interactionClarification) {
            this.setClarification();
        }
    }
    render() {
        if (!this.task)
            return html `No task.`;
        this.isClarificationPending = false;
        if (this.task) {
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification')
                this.isClarificationPending = true;
        }
        if (this.isClarificationPending && !this.forceViewRaw)
            return this.renderDirectClarification();
        return this.renderTab();
    }
    renderTab() {
        let aux = '';
        if (this.hasTodo) {
            aux = html `
            <div class="tab ${this.activeTab === 'todo' ? 'active' : ''}" @click=${() => this.setTab('todo')} >Todo</div>`;
        }
        return html `
            ${this.isClarificationPending ? html `<button class="viewraw" @click=${() => this.clickForceViewRaw(false)}>Clarification</button>` : ''}
            <div style="height: calc(100% - 3rem);">
                <div class="tabs">
                    ${aux}
                    <div
                        class="tab ${this.activeTab === 'step' ? 'active' : ''}"
                        @click=${() => this.setTab('step')}
                    >Step</div>
                    <div
                        class="tab ${this.activeTab === 'raw' ? 'active' : ''}"
                        @click=${() => this.setTab('raw')}
                    >Raw</div>
                    <div
                        class="tab ${this.activeTab === 'workflow' ? 'active' : ''}"
                        @click=${() => this.setTab('workflow')}
                    >Workflow</div>

                </div>
                <div class="content">
                    ${this.renderTabContent()}
                </div>
            </div>
        `;
    }
    renderTabContent() {
        switch (this.activeTab) {
            case 'workflow': return html `workflow`;
            case 'step': return this.renderStep();
            case 'raw': return this.renderRaw();
            case 'todo': return this.renderTodo();
            default: return html `workflow`;
        }
    }
    renderRaw() {
        return html `<collab-messages-task-details-102025 .task=${this.task} taskId=${this.task?.PK}></collab-messages-task-details-102025>`;
    }
    renderStep() {
        return html `<collab-messages-task-preview-102025 .message=${this.message} .task=${this.task}></collab-messages-task-preview-102025>`;
    }
    renderTodo() {
        return html `<collab-messages-task-log-preview-102025 .message=${this.message} .task=${this.task}></collab-messages-task-log-preview-102025>`;
    }
    renderDirectClarification() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextClarificationStep(this.task);
        if (!payload)
            return html ``;
        return html `
        <button class="viewraw" @click=${() => this.clickForceViewRaw(true)}>View raw</button>
        <div class="direct-clarification">${this.renderClarification(payload)}
        </div>`;
    }
    renderClarification(payload) {
        if (!this.task)
            return html `Invalid task`;
        const parentInteraction = getInteractionStepId(this.task, payload.stepId);
        if (!parentInteraction)
            return html `No found parentInteraction ${payload.stepId} on task: ${this.task.PK} `;
        const interaction = getStepById(this.task, parentInteraction);
        this.interactionClarification = interaction;
        if (!interaction)
            return html `Invalid interaction id:${parentInteraction} on task: ${this.task.PK} `;
        if (!interaction.agentName)
            return html `Invalid agent name for step id:${interaction.stepId} on task: ${this.task.PK} `;
        return html `<div class="content"> Processing...</div>`;
    }
    //---------IMPLEMENTATION -----------
    clickForceViewRaw(force) {
        this.forceViewRaw = force;
        this.requestUpdate();
        if (!force)
            setTimeout(() => this.setClarification(), 300);
    }
    async setClarification() {
        if (!this.directClarificationContent || !this.task || !this.message)
            return;
        let clarification = null;
        if (this.task.iaCompressed?.queueFrontEnd) {
            clarification = await getClarificationElement({ message: this.message, task: this.task, isTest: false });
        }
        else
            clarification = await getClarification(this.task.PK);
        if (!clarification)
            return;
        this.directClarificationContent.innerHTML = '';
        this.directClarificationContent.appendChild(clarification);
        this.executeHTMLClarificationScript();
    }
    executeHTMLClarificationScript() {
        this.directClarification?.querySelectorAll('script').forEach(oldScript => {
            const newScript = document.createElement('script');
            newScript.type = oldScript.type || 'text/javascript';
            if (!newScript.type) {
                newScript.type = 'text/javascript';
            }
            if (oldScript.hasAttribute('type') && oldScript.getAttribute('type') === 'module') {
                newScript.type = 'module';
            }
            if (oldScript.src) {
                newScript.src = oldScript.src;
            }
            else {
                newScript.textContent = oldScript.textContent;
            }
            oldScript.replaceWith(newScript);
        });
    }
    setTab(tab) {
        this.activeTab = tab;
    }
    onTaskChange(e) {
        if (!this.task)
            return;
        const customEvent = e;
        const task = customEvent.detail.context.task;
        if (task.PK !== this.task.PK)
            return;
        this.task = task;
    }
};
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "task", void 0);
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "message", void 0);
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "stepid", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesTaskInfo.prototype, "seen", void 0);
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "interactionClarification", void 0);
__decorate([
    query('.direct-clarification')
], CollabMessagesTaskInfo.prototype, "directClarification", void 0);
__decorate([
    query('.direct-clarification .content')
], CollabMessagesTaskInfo.prototype, "directClarificationContent", void 0);
__decorate([
    state()
], CollabMessagesTaskInfo.prototype, "activeTab", void 0);
CollabMessagesTaskInfo = __decorate([
    customElement('collab-messages-task-info-102025')
], CollabMessagesTaskInfo);
export { CollabMessagesTaskInfo };
