/// <mls fileReference="_102025_/l2/collabMessagesChangeAvatar.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from "lit";
import { customElement, property, state } from "lit/decorators.js";
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getTemporaryContext } from '/_100554_/l2/aiAgentHelper.js';
import { loadAgent, executeBeforePrompt } from '/_100554_/l2/aiAgentOrchestration.js';
import { defaultThreadImage } from '/_102025_/l2/collabMessagesHelper.js';
/// **collab_i18n_start** 
const message_pt = {
    changeAvatar: "Alterar avatar",
    changeButton: "Trocar imagem",
    generateButton: "Gerar com IA",
    panelTitle: "Gerar Avatar com IA",
    generateLabel: "Descreva o avatar",
    generatePlaceholder: "Digite aqui sua descrição...",
    actionGenerate: "Gerar",
    saveButton: "Salvar",
    cancelButton: "Cancelar",
    generating: "Gerando..."
};
const message_en = {
    changeAvatar: "Change avatar",
    changeButton: "Change image",
    generateButton: "Generate with AI",
    panelTitle: "Generate Avatar with AI",
    generateLabel: "Describe the avatar",
    generatePlaceholder: "Type your description here...",
    actionGenerate: "Generate",
    saveButton: "Save",
    cancelButton: "Cancel",
    generating: "Generating..."
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const agentName = '_102025_agentGenerateAvatarSvg';
let CollabChangeAvatar = class CollabChangeAvatar extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.userId = "20250417120841.1000";
        this.threadId = "20250825143728.1000";
        this.avatarPrompt = "";
        this.isOpen = false;
        this.generating = false;
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.preview = this.value || defaultThreadImage;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
    <div class="avatar-section">
      <div class="preview">
        ${this.preview
            ? this.preview.startsWith("<svg")
                ? html `${this.safeSvg(this.preview)}`
                : html `<img src="${this.preview}" alt="Avatar" />`
            : this.value
                ? this.value.startsWith("<svg")
                    ? html `${this.safeSvg(this.value)}`
                    : html `<img src="${this.value}" alt="Avatar" />`
                : html `<div class="placeholder">?</div>`}
      </div>

      <div class="actions-avatar">
        <a style="display:none"  href="#" class="btn" @click=${this.triggerFileInput}>${this.msg.changeButton}</a>
        <input 
          type="file" 
          accept="image/*" 
          class="hidden-file-input"
          @change=${this.onFileSelect}
        />

        <a href="#" class="btn" @click=${(e) => { e.preventDefault(); this.isOpen = true; }}>
          ${this.msg.generateButton}
        </a>
      </div>
    </div>

    ${this.isOpen ? html `
      <div class="panel">
        <h4>${this.msg.panelTitle}</h4>

        <label>${this.msg.generateLabel}</label>
        <textarea
          placeholder=${this.msg.generatePlaceholder}
          .value=${this.avatarPrompt}
          @input=${(e) => this.avatarPrompt = e.target.value}
        ></textarea>

        <div class="actions-ia">
          <button ?disabled=${this.generating} @click=${this.generateAvatarFromPrompt}>
            ${this.generating ? html `<span class="loader"></span>` : this.msg.actionGenerate}
          </button>
          <button @click=${() => this.isOpen = false}>${this.msg.cancelButton}</button>
        </div>
      </div>
    ` : ""}
  `;
    }
    onFileSelect(e) {
        const input = e.target;
        if (input.files && input.files[0]) {
            this.avatarFile = input.files[0];
            this.preview = URL.createObjectURL(this.avatarFile);
        }
    }
    triggerFileInput(e) {
        e.preventDefault();
        const input = this.querySelector(".hidden-file-input");
        input?.click();
    }
    async generateAvatarFromPrompt() {
        if (!this.avatarPrompt)
            return;
        this.generating = true;
        try {
            const agent = await loadAgent(agentName);
            if (!agent)
                throw new Error('Invalid agent');
            const context = getTemporaryContext(this.threadId, this.userId, this.avatarPrompt);
            await executeBeforePrompt(agent, context);
            if (context.task &&
                context.task.iaCompressed &&
                context.task.iaCompressed.nextSteps &&
                context.task.iaCompressed.nextSteps[0] &&
                context.task.iaCompressed.nextSteps[0].interaction &&
                context.task.iaCompressed.nextSteps[0].interaction.payload &&
                context.task.iaCompressed.nextSteps[0].interaction.payload[0]) {
                const svg = (context.task.iaCompressed?.nextSteps[0]?.interaction?.payload[0]).result;
                if (svg && typeof svg === 'string') {
                    this.preview = svg;
                    this.emitValueChanged(this.preview);
                }
            }
        }
        catch (err) {
            console.error("Erro ao gerar avatar via IA", err);
        }
        finally {
            this.generating = false;
        }
    }
    emitValueChanged(value) {
        this.dispatchEvent(new CustomEvent('value-changed', {
            detail: value,
            bubbles: true,
            composed: true
        }));
    }
    safeSvg(svg) {
        return html `${unsafeHTML(svg)}`;
    }
};
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "value", void 0);
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "userId", void 0);
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "threadId", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "avatarPrompt", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "avatarFile", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "isOpen", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "generating", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "preview", void 0);
CollabChangeAvatar = __decorate([
    customElement("collab-messages-change-avatar-102025")
], CollabChangeAvatar);
export { CollabChangeAvatar };
