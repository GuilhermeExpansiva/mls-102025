/// <mls fileReference="_102025_/l2/collabMessagesSettingsIntegrations.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
