/// <mls fileReference="_102025_/l2/collabMessagesTask.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getNextPendentStep, getTotalCost } from '/_100554_/l2/aiAgentHelper.js';
import { executeNextStep } from "/_100554_/l2/aiAgentOrchestration.js";
import { getTask, getMessage } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { collab_money, collab_pause, collab_bell, collab_chevron_right, collab_clock, collab_check, collab_bug, collab_play } from '/_102025_/l2/collabMessagesIcons.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
};
const message_en = {
    loading: 'Loading...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesTask = class CollabMessagesTask extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-102025{box-shadow:rgba(50,50,93,0.25) 0 2px 5px -1px,rgba(0,0,0,0.3) 0 1px 3px -1px;overflow:hidden;cursor:pointer;background-color:#fff;color:#000000;height:40px;display:flex;align-items:center;border-radius:10px}collab-messages-task-102025 .card.no-details{display:block}collab-messages-task-102025 .card{display:block;padding:var(--space-16);width:100%;position:relative}collab-messages-task-102025 .card .task-icon .icon-wrapper{position:relative;display:inline-block;font-size:20px}collab-messages-task-102025 .card .task-icon .notification-badge{position:absolute;top:-1px;right:-3px;background:red;color:white;border-radius:50%;padding:.1em .1em;font-size:.49em;font-weight:bold;line-height:1;min-width:1em;text-align:center}collab-messages-task-102025 .card .task-icon.failed{fill:var(--error-color);color:var(--error-color)}collab-messages-task-102025 .card .task-icon.done{fill:var(--success-color);color:var(--success-color)}collab-messages-task-102025 .card .task-icon.waitingforuser{fill:var(--warning-color);color:var(--warning-color)}collab-messages-task-102025 .card .card-header{display:flex;justify-content:space-between;gap:.4rem;align-items:center}collab-messages-task-102025 .card .card-header .card-user{color:#be069c}collab-messages-task-102025 .card .card-header .card-title{font-size:var(--font-size-12);font-weight:bold;max-width:115px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-task-102025 .card .card-header .card-time{font-size:.75rem;color:gray;text-align:right;transition:color .3s ease}collab-messages-task-102025 .card .card-header .card-time.over-minute{color:red;animation:pulse 1s infinite alternate}@keyframes pulse{0%{transform:scale(1)}100%{transform:scale(1.2)}}collab-messages-task-102025 .card .card-header .card-price{display:flex;align-items:center;gap:.2rem;font-size:var(--font-size-12)}collab-messages-task-102025 .card .card-header .card-price svg{width:12px;height:12px}collab-messages-task-102025 .card .card-header .card-actions{display:flex;gap:.4rem;align-items:center}collab-messages-task-102025 .card .card-header .card-actions i{cursor:pointer}collab-messages-task-102025 .card .card-header .card-actions i:hover{transform:scale(1.1)}collab-messages-task-102025 .card .card-header .card-actions svg{width:12px;height:12px}collab-messages-task-102025 .card .card-header .card-status{text-transform:uppercase;font-size:var(--font-size-12);border:1px solid;padding:0 .3rem;border-radius:4px;white-space:nowrap}collab-messages-task-102025 .card .card-header .card-status.todo{color:var(--grey-color-darker)}collab-messages-task-102025 .card .card-header .card-status.done{color:var(--success-color)}collab-messages-task-102025 .card .card-header .card-status.in-progress{color:var(--active-color)}collab-messages-task-102025 .card .card-header .card-status.waitingforuser{color:var(--warning-color)}collab-messages-task-102025 .card .card-header .card-status.paused{color:var(--info-color-disabled)}collab-messages-task-102025 .card .card-body{margin-top:var(--space-16)}collab-messages-task-102025 .card .card-body .card-message{font-size:var(--font-size-16)}`);
        this.msg = messages['en'];
        this.taskid = '';
        this.threadId = '';
        this.userId = '';
        this.messageid = '';
        this.lastChanged = '';
        this.status = '';
        this.secondsPassed = 0;
        this.continueEnabled = false;
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.timerId) {
            clearInterval(this.timerId);
            this.timerId = undefined;
        }
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('lastChanged')) {
            if (this.context && this.context.task) {
                this.task = this.context.task;
                const nextStep = getNextPendentStep(this.task);
                if (!nextStep || nextStep.type === 'clarification') {
                    this.resetTimer();
                    this.lastStep = undefined;
                }
                else {
                    if (this.lastStep !== nextStep.stepId) {
                        this.resetTimer();
                        this.lastStep = nextStep.stepId;
                    }
                }
            }
        }
        if (changedProperties.has('taskid') && changedProperties.get('taskid') !== '') {
            this.getTaskLocal(this.taskid);
        }
    }
    render() {
        const isOverMinute = this.secondsPassed >= 60;
        const timeClass = isOverMinute ? 'card-time over-minute' : 'card-time';
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.task) {
            return html `<div @click=${this.onCardClick} class="card no-details"> 
            <div class="card-header">
                <span class="card-title">Task</span>
                ${collab_chevron_right}
            </div>
         </div>`;
        }
        const price = this.task ? getTotalCost(this.task) || '0.00' : '';
        const title = this.task?.title || '';
        const timeDisplay = this.formatTime(this.secondsPassed);
        return html `<div @click=${this.onCardClick} class="card"> 
        <div class="card-header">
            ${this.renderIconTask()}
            <span class="card-title"> ${title}</span>
            <span class="card-price"> ${price ? collab_money : ''}${price}</span>
            ${this.lastStep ? html `<span class="${timeClass}">${timeDisplay}</span>` : ''}
        </div>
     </div>`;
    }
    renderIconTask() {
        if (this.continueEnabled) {
            return html `<span @click=${this.onContinueClick} class="task-icon">${collab_play}</span>`;
        }
        const taskObj = {
            '': html ``,
            'pending': collab_clock,
            'paused': collab_pause,
            'todo': collab_clock,
            'in progress': collab_clock,
            'done': collab_check,
            'failed': collab_bug,
            'waitingforuser': html `
                    <span class="icon-wrapper">
                        ${collab_bell}
                        <span class="notification-badge">1</span>
                    </span>`,
        };
        let status = this.status;
        if (this.task) {
            status = this.task.status;
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification')
                status = 'waitingforuser';
        }
        if (!status)
            return html `<span class="task-icon in progress ">${collab_clock}</span>`;
        return html `<span class="task-icon ${status.split(' ').join('-')} ">${taskObj[status]}</span>`;
    }
    onContinueClick(e) {
        e.stopPropagation();
        if (this.context) {
            executeNextStep(this.context);
            this.continueEnabled = false;
            this.resetTimer();
        }
    }
    resetTimer() {
        if (this.continueEnabled)
            return;
        this.secondsPassed = 0;
        if (this.timerId) {
            clearInterval(this.timerId);
        }
        this.timerId = window.setInterval(() => {
            this.secondsPassed++;
            this.requestUpdate();
        }, 1000);
    }
    formatTime(seconds) {
        const min = Math.floor(seconds / 60).toString().padStart(2, '0');
        const sec = (seconds % 60).toString().padStart(2, '0');
        return `${min}:${sec}`;
    }
    async getTaskLocal(taskId) {
        const task = await getTask(taskId);
        if (task) {
            this.task = task;
            if (task.status === 'in progress' && task.owner === this.userId && !this.context) {
                const messageId = `${this.threadId}/${this.messageid}`;
                const response = await mls.api.msgGetTaskUpdate({
                    messageId,
                    taskId,
                    userId: this.userId
                });
                const message = await getMessage(messageId);
                if (!message)
                    return;
                if (!response || response.statusCode !== 200)
                    return;
                this.context = {
                    task: response.task,
                    message,
                    isTest: false
                };
                this.lastChanged = new Date().getTime().toString();
                const nextPendent = getNextPendentStep(response.task);
                if (nextPendent && nextPendent.type !== 'clarification') {
                    this.continueEnabled = true;
                }
            }
        }
    }
    onCardClick() {
        const event = new CustomEvent('taskclick', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }
};
__decorate([
    property()
], CollabMessagesTask.prototype, "taskid", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "threadId", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "messageid", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "lastChanged", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "status", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "task", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "context", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "secondsPassed", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "lastStep", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "continueEnabled", void 0);
CollabMessagesTask = __decorate([
    customElement('collab-messages-task-102025')
], CollabMessagesTask);
export { CollabMessagesTask };
