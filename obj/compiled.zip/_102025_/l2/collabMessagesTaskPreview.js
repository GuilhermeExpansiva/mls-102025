/// <mls fileReference="_102025_/l2/collabMessagesTaskPreview.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { getAllSteps } from '/_102029_/l2/aiAgentHelper.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import '/_102025_/l2/collabMessagesTaskPreviewAgent.js';
import '/_102025_/l2/collabMessagesTaskPreviewClarification.js';
import '/_102025_/l2/collabMessagesTaskPreviewFlexible.js';
import '/_102025_/l2/collabMessagesTaskPreviewTools.js';
import '/_102025_/l2/collabMessagesTaskPreviewResult.js';
let CollabMessageTaskPreview = class CollabMessageTaskPreview extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-preview-102025{display:block;border:1px solid var(--grey-color);padding:1rem;border-radius:8px;background:var(--bg-secondary-color-lighter);font-family:var(--font-family-primary);height:calc(100% - 50px);position:relative}collab-messages-task-preview-102025 .tabAction{display:flex;align-items:center;justify-content:center;padding:.3rem;gap:3rem}collab-messages-task-preview-102025 .tabAction span{font-weight:500;font-size:1.1rem;color:var(--text-primary-color)}collab-messages-task-preview-102025 .tabAction button{padding:.2rem 1.2rem;border:none;border-radius:2px;background-color:var(--text-primary-color-darker);color:var(--bg-primary-color);font-size:.95rem;cursor:pointer}collab-messages-task-preview-102025 .tabAction button:hover:not(:disabled){opacity:.7}collab-messages-task-preview-102025 .tabAction button:disabled{background-color:var(--bg-secondary-color);cursor:not-allowed}collab-messages-task-preview-102025 .breadcrumb{display:flex;justify-content:flex-start;align-items:center;overflow:hidden;flex-shrink:0;height:20px;scrollbar-width:none;-ms-overflow-style:none}collab-messages-task-preview-102025 .breadcrumb::-webkit-scrollbar{display:none}collab-messages-task-preview-102025 .breadcrumb span{display:inline-block;color:var(--link-color);padding:0 .75rem;position:relative;flex-shrink:0;cursor:pointer;transition:color .2s;font-size:10px}collab-messages-task-preview-102025 .breadcrumb span:hover{color:var(--link-color-hover)}collab-messages-task-preview-102025 .breadcrumb span::after{content:'>';position:absolute;right:-0.5rem;color:var(--grey-color-dark);pointer-events:none}collab-messages-task-preview-102025 .breadcrumb span:last-of-type{font-weight:bold;color:var(--text-primary-color)}collab-messages-task-preview-102025 .breadcrumb span:last-of-type::after{content:none}collab-messages-task-preview-102025 .container{background:var(--bg-primary-color);border-radius:5px;border:1px solid var(--grey-color);height:calc(100% - 70px);overflow-y:auto}`);
        this.message = null;
        this.task = null;
        this.modeTest = false;
        this.stepMap = new Map();
        this.navigationStack = [];
        this.currentStepId = null;
        this.allSteps = [];
    }
    disconnectedCallback() {
        window.removeEventListener('task-change', this.onTaskChange.bind(this));
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.modeTest)
            return;
        this.init();
        window.addEventListener('task-change', this.onTaskChange.bind(this));
    }
    render() {
        if (!this.task) {
            return html `<p>Task not provided.</p>`;
        }
        return html `${this.renderStep()}`;
    }
    renderStep() {
        if (!this.task) {
            return html `<p>Task not provided.</p>`;
        }
        if (!this.currentStepId) {
            return html `<p>No steps selected.</p>`;
        }
        const step = this.stepMap.get(this.currentStepId);
        if (!step) {
            return html `<p>Step not found: ${this.currentStepId}</p>`;
        }
        return html `
            ${this.renderNavigation(step.stepId)}
            <div class="container">
            ${this.renderStepDetails(step)}
            </div>
            ${this.renderBreadcrumb()}
        `;
    }
    renderNavigation(stepId) {
        const goToPrevious = () => {
            this.goBack();
        };
        const goToNext = () => {
            this.navigateToStep(stepId + 1);
        };
        const step = this.stepMap.get(stepId);
        const all = this.allSteps.length.toString().padStart(2, '0');
        let name = `00/${all}`;
        if (step)
            name = `${stepId.toString().padStart(2, '0')}/${all}`;
        return html `
            <div class="tabAction">
                <button @click=${goToPrevious} ><svg style="width:13px; fill:#fff; transform: rotateY(180deg);" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L338.8 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l306.7 0L233.4 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z"/></svg></button>
                <span>${name}</span>
                <button @click=${goToNext} ><svg style="width:13px; fill:#fff" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L338.8 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l306.7 0L233.4 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z"/></svg></button>
            </div>
        `;
    }
    renderStepDetails(step) {
        switch (step.type) {
            case 'agent': return this.renderAgent(step);
            case 'clarification': return this.renderClarification(step);
            case 'flexible': return this.renderFlexible(step);
            case 'tool': return this.renderTools(step);
            case 'result': return this.renderResult(step);
            default: return html `Not found type: renderStepDetails`;
        }
    }
    renderBreadcrumb() {
        return html `
            <nav class="breadcrumb">
                ${this.navigationStack.map((stepId, idx) => {
            const step = this.stepMap.get(stepId);
            if (!step) {
                return html `<p>Step not found: ${this.currentStepId}</p>`;
            }
            return html ` <span
                            @click=${() => {
                this.navigationStack = this.navigationStack.slice(0, idx + 1);
                this.currentStepId = stepId;
            }} >${step.agentName ? step.agentName : step.type}</span>
                            `;
        })}
            </nav>
        `;
    }
    renderAgent(step) {
        return html ` <collab-messages-task-preview-agent-102025 .step=${step} .message=${this.message} .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-agent-102025> `;
    }
    renderClarification(step) {
        return html ` <collab-messages-task-preview-clarification-102025 .step=${step} .message=${this.message}  .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-clarification-102025> `;
    }
    renderFlexible(step) {
        return html ` <collab-messages-task-preview-flexible-102025 .step=${step} .message=${this.message}  .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-flexible-102025> `;
    }
    renderTools(step) {
        return html ` <collab-messages-task-preview-tools-102025 .step=${step} .message=${this.message}  .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-tools-102025> `;
    }
    renderResult(step) {
        return html ` <collab-messages-task-preview-result-102025 .step=${step} .message=${this.message}  .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-result-102025> `;
    }
    //------IMPLEMENTATION--------
    init() {
        if (!this.task || !this.task.iaCompressed)
            return;
        this.stepMap.clear();
        this.buildStepMap(this.task.iaCompressed.nextSteps);
        this.currentStepId = 1;
        this.navigationStack = [1];
        this.allSteps = getAllSteps(this.task.iaCompressed.nextSteps);
    }
    onTaskChange(e) {
        if (!this.task)
            return;
        const customEvent = e;
        const task = customEvent.detail.context.task;
        if (task.PK !== this.task.PK)
            return;
        this.task = task;
        if (!this.task || !this.task.iaCompressed)
            return;
        this.stepMap.clear();
        this.buildStepMap(this.task.iaCompressed.nextSteps);
        this.allSteps = getAllSteps(this.task.iaCompressed.nextSteps);
    }
    buildStepMap(steps) {
        for (const step of steps) {
            this.stepMap.set(step.stepId, step);
            if (step.interaction?.payload) {
                this.buildStepMap(step.interaction.payload);
            }
            if (step.nextSteps) {
                this.buildStepMap(step.nextSteps);
            }
        }
    }
    navigateToStep(stepId) {
        if (!this.stepMap.has(stepId)) {
            return;
        }
        this.currentStepId = stepId;
        this.navigationStack = [...this.navigationStack, stepId];
    }
    goBack() {
        if (this.navigationStack.length > 1) {
            this.navigationStack.pop();
            this.currentStepId = this.navigationStack[this.navigationStack.length - 1];
        }
    }
};
__decorate([
    property({ type: Object })
], CollabMessageTaskPreview.prototype, "message", void 0);
__decorate([
    property({ type: Object })
], CollabMessageTaskPreview.prototype, "task", void 0);
__decorate([
    property()
], CollabMessageTaskPreview.prototype, "modeTest", void 0);
__decorate([
    state()
], CollabMessageTaskPreview.prototype, "stepMap", void 0);
__decorate([
    state()
], CollabMessageTaskPreview.prototype, "navigationStack", void 0);
__decorate([
    state()
], CollabMessageTaskPreview.prototype, "currentStepId", void 0);
__decorate([
    state()
], CollabMessageTaskPreview.prototype, "allSteps", void 0);
CollabMessageTaskPreview = __decorate([
    customElement('collab-messages-task-preview-102025')
], CollabMessageTaskPreview);
export { CollabMessageTaskPreview };
