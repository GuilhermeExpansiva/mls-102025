/// <mls fileReference="_102025_/l2/collabMessagesTopics.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { collab_chevron_down, collab_chevron_right } from '/_102025_/l2/collabMessagesIcons.js';
let CollabMessagesTopics = class CollabMessagesTopics extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-topics-102025{display:block}collab-messages-topics-102025 .topics-header{display:flex;justify-content:space-between;align-items:center;padding:4px 8px;border-bottom:1px solid var(--grey-color-dark);background:var(--grey-color-light)}collab-messages-topics-102025 .topics{display:flex;gap:8px;flex-wrap:wrap}collab-messages-topics-102025 .topics-details{cursor:pointer}collab-messages-topics-102025 button{background:none;border:1px solid var(--grey-color-dark);border-radius:4px;padding:2px 6px;cursor:pointer;font-size:.9rem}collab-messages-topics-102025 button.active{background:var(--active-color);color:white;border-color:var(--active-color)}collab-messages-topics-102025 .groups{display:flex;flex-direction:column;gap:12px;padding:0 .3rem .3rem .3rem;background:var(--grey-color-light)}collab-messages-topics-102025 .group{display:flex;flex-direction:column;gap:6px}collab-messages-topics-102025 .group-title{font-weight:bold;font-size:.95rem}collab-messages-topics-102025 .group-topics{display:flex;gap:6px;flex-wrap:wrap}`);
        this.messages = [];
        this.topics = [];
        this.expanded = false;
        this.selectedTopic = null;
        this.threadTopics = [];
    }
    render() {
        this.topics = this.getTopicsFromMessagesOrdered();
        const headerTopics = this.getHeadersTopicsFromMessages();
        const grouped = this.groupTopics(this.topics);
        if (!this.topics || this.topics.length === 0)
            return html ``;
        return html `

      <div class="topics-header">
        <div class="topics">
          <button
            class=${this.selectedTopic === 'all' ? 'active' : ''}
            @click=${() => this.emitTopic('all')}
          >all</button>

          ${!this.expanded
            ? headerTopics.map(topic => html `
                <button
                  class=${this.selectedTopic === topic ? 'active' : ''}
                  @click=${() => this.emitTopic(topic)}
                >${topic}</button>
              `)
            : null}
        </div>
        <i class="topics-details" @click=${() => this.expanded = !this.expanded}>
          ${this.expanded ? collab_chevron_down : collab_chevron_right}
        </i>
      </div>

      ${this.expanded ? html `
        <div class="groups">
          ${Object.entries(grouped).map(([group, items]) => html `
            <div class="group">
              <div class="group-title">${group}</div>
              <div class="group-topics">
                ${items.map(item => html `
                  <button
                    class=${this.selectedTopic === item ? 'active' : ''}
                    @click=${() => this.emitTopic(item)}
                  >${item}</button>
                `)}
              </div>
            </div>
          `)}
        </div>
      ` : null}
    `;
    }
    emitTopic(topic) {
        this.selectedTopic = topic;
        this.dispatchEvent(new CustomEvent("topic-selected", {
            detail: { topic },
            bubbles: true,
            composed: true
        }));
    }
    extractTopics(message) {
        const regex = /\+[a-zA-Z0-9_]+/g;
        const matches = message.match(regex);
        return matches ? matches : [];
    }
    groupTopics(topics) {
        const groups = {};
        topics.forEach(topic => {
            const clean = topic.slice(1);
            const [prefix] = clean.split('_', 2);
            if (!groups[prefix])
                groups[prefix] = [];
            groups[prefix].push(topic);
        });
        return groups;
    }
    getHeadersTopicsFromMessages() {
        const ordered = [];
        this.messages.forEach((message) => {
            if (message.content) {
                const topics = this.extractTopics(message.content);
                topics.forEach(topic => {
                    ordered.push(topic);
                });
            }
        });
        let headerTopics = Array.from(new Set([...ordered])).slice(0, 3);
        if (headerTopics.length < 3) {
            const extras = this.threadTopics.filter((topic) => !headerTopics.includes(topic));
            headerTopics = [...headerTopics, ...extras].slice(0, 3);
        }
        if (this.selectedTopic && !headerTopics.includes(this.selectedTopic) && this.selectedTopic !== 'all') {
            headerTopics = [...headerTopics, this.selectedTopic];
        }
        return headerTopics;
    }
    getTopicsFromMessagesOrdered() {
        const seen = new Set();
        const ordered = [];
        this.messages.forEach((message) => {
            if (message.content) {
                const topics = this.extractTopics(message.content);
                topics.forEach(topic => {
                    if (!seen.has(topic) && topic !== '') {
                        seen.add(topic);
                        ordered.push(topic);
                    }
                });
            }
        });
        if (this.threadTopics) {
            this.threadTopics.forEach((thTop) => {
                if (!ordered.find((item) => item == thTop) && thTop !== '') {
                    ordered.push(thTop);
                }
            });
        }
        return ordered;
    }
};
__decorate([
    state()
], CollabMessagesTopics.prototype, "messages", void 0);
__decorate([
    state()
], CollabMessagesTopics.prototype, "topics", void 0);
__decorate([
    state()
], CollabMessagesTopics.prototype, "expanded", void 0);
__decorate([
    property()
], CollabMessagesTopics.prototype, "selectedTopic", void 0);
__decorate([
    property()
], CollabMessagesTopics.prototype, "threadTopics", void 0);
CollabMessagesTopics = __decorate([
    customElement('collab-messages-topics-102025')
], CollabMessagesTopics);
export { CollabMessagesTopics };
