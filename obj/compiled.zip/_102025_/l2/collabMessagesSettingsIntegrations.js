/// <mls fileReference="_102025_/l2/collabMessagesSettingsIntegrations.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
let CollabMessagesSettingsIntegrations102025 = class CollabMessagesSettingsIntegrations102025 extends StateLitElement {
    render() {
        return html ``;
    }
};
CollabMessagesSettingsIntegrations102025 = __decorate([
    customElement('collab-messages-settings-integrations-102025')
], CollabMessagesSettingsIntegrations102025);
export { CollabMessagesSettingsIntegrations102025 };
