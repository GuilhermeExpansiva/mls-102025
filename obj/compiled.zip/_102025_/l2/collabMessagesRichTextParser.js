/// <mls fileReference="_102025_/l2/collabMessagesRichTextParser.ts" enhancement="_102027_/l2/enhancementLit" />
// ─────────────────────────────────────────────────────────────
// Funções auxiliares
// ─────────────────────────────────────────────────────────────
const isBoundary = (char) => !char || /\s/.test(char);
const matchRawLink = (s) => s.match(/^(https?:\/\/[^\s]+|www\.[^\s]+)/);
// ─────────────────────────────────────────────────────────────
// Parser principal - processa texto completo (com blocos)
// ─────────────────────────────────────────────────────────────
export function parseRichText(input) {
    const tokens = [];
    const lines = input.split(/\r?\n/);
    let i = 0;
    while (i < lines.length) {
        const line = lines[i];
        /* ───── CODE BLOCK ───── */
        if (line.startsWith('```')) {
            let block = line + '\n';
            i++;
            while (i < lines.length && !lines[i].startsWith('```')) {
                block += lines[i] + '\n';
                i++;
            }
            if (i < lines.length) {
                block += lines[i];
                i++;
            }
            tokens.push(...parseInlineRichText(block));
            continue;
        }
        /* ───── BLOCKQUOTE ───── */
        if (line.startsWith('>')) {
            const quoteLines = [];
            while (i < lines.length && lines[i].startsWith('>')) {
                quoteLines.push(lines[i].replace(/^>\s?/, ''));
                i++;
            }
            tokens.push({
                type: 'blockquote',
                children: parseRichText(quoteLines.join('\n')),
            });
            continue;
        }
        /* ───── UNORDERED LIST ───── */
        if (/^- /.test(line)) {
            const items = [];
            while (i < lines.length && /^- /.test(lines[i])) {
                items.push(parseInlineRichText(lines[i].replace(/^- /, '')));
                i++;
            }
            tokens.push({
                type: 'list',
                ordered: false,
                items,
            });
            continue;
        }
        /* ───── ORDERED LIST ───── */
        if (/^\d+\. /.test(line)) {
            const items = [];
            while (i < lines.length && /^\d+\. /.test(lines[i])) {
                items.push(parseInlineRichText(lines[i].replace(/^\d+\. /, '')));
                i++;
            }
            tokens.push({
                type: 'list',
                ordered: true,
                items,
            });
            continue;
        }
        /* ───── NORMAL LINE ───── */
        if (line !== '') {
            tokens.push(...parseInlineRichText(line));
        }
        tokens.push({ type: 'text', value: '\n' });
        i++;
    }
    return tokens;
}
// ─────────────────────────────────────────────────────────────
// Parser inline - processa formatação dentro de uma linha
// Parâmetro skipCodeBlock: quando true, não processa ``` (útil para prompt)
// ─────────────────────────────────────────────────────────────
export function parseInlineRichText(input, skipCodeBlock = false) {
    const tokens = [];
    let state = 'NORMAL';
    let buffer = '';
    let codeLang = '';
    let codeBlockStart = '';
    let i = 0;
    const flushText = () => {
        if (buffer) {
            tokens.push({ type: 'text', value: buffer });
            buffer = '';
        }
    };
    while (i < input.length) {
        /* ───────────── CODE BLOCK (```) ───────────── */
        // Se skipCodeBlock, trata ``` como texto normal (pula os 3 de uma vez)
        if (state === 'NORMAL' && input.startsWith('```', i)) {
            if (skipCodeBlock) {
                buffer += '```';
                i += 3;
                continue;
            }
            // Processa code block normalmente
            flushText();
            codeBlockStart = '```';
            i += 3;
            while (i < input.length && input[i] !== '\n') {
                codeLang += input[i++];
            }
            codeBlockStart += codeLang;
            if (input[i] === '\n') {
                codeBlockStart += '\n';
                i++;
            }
            state = 'CODE_BLOCK';
            buffer = '';
            continue;
        }
        /* ───────────── CODE BLOCK END ───────────── */
        if (state === 'CODE_BLOCK' && input.startsWith('```', i)) {
            tokens.push({
                type: 'code-block',
                language: codeLang.trim() || 'plain',
                value: buffer,
                markerStart: codeBlockStart,
                markerEnd: '```',
            });
            buffer = '';
            codeLang = '';
            codeBlockStart = '';
            state = 'NORMAL';
            i += 3;
            continue;
        }
        /* ───────────── INLINE CODE ───────────── */
        if (state === 'NORMAL' && input[i] === '`') {
            flushText();
            state = 'INLINE_CODE';
            buffer = '';
            i++;
            continue;
        }
        if (state === 'INLINE_CODE' && input[i] === '`') {
            tokens.push({
                type: 'inline-code',
                value: buffer,
                markerStart: '`',
                markerEnd: '`',
            });
            buffer = '';
            state = 'NORMAL';
            i++;
            continue;
        }
        /* ───────────── FORMATTING (NORMAL ONLY) ───────────── */
        if (state === 'NORMAL') {
            // bold **
            if (input.startsWith('**', i) && isBoundary(input[i - 1])) {
                const end = input.indexOf('**', i + 2);
                // Verifica se o fechamento está em uma boundary
                if (end !== -1 && isBoundary(input[end + 2])) {
                    flushText();
                    tokens.push({
                        type: 'bold',
                        value: input.slice(i + 2, end),
                        markerStart: '**',
                        markerEnd: '**',
                    });
                    i = end + 2;
                    continue;
                }
            }
            // strike ~~
            if (input.startsWith('~~', i) && isBoundary(input[i - 1])) {
                const end = input.indexOf('~~', i + 2);
                // Verifica se o fechamento está em uma boundary
                if (end !== -1 && isBoundary(input[end + 2])) {
                    flushText();
                    tokens.push({
                        type: 'strike',
                        value: input.slice(i + 2, end),
                        markerStart: '~~',
                        markerEnd: '~~',
                    });
                    i = end + 2;
                    continue;
                }
            }
            // italic _
            if (input[i] === '_' && isBoundary(input[i - 1])) {
                const end = input.indexOf('_', i + 1);
                // Verifica se o fechamento está em uma boundary (espaço, pontuação ou fim)
                if (end !== -1 && isBoundary(input[end + 1])) {
                    flushText();
                    tokens.push({
                        type: 'italic',
                        value: input.slice(i + 1, end),
                        markerStart: '_',
                        markerEnd: '_',
                    });
                    i = end + 1;
                    continue;
                }
            }
            // agent @@agent
            if (input[i] === '@' &&
                input[i + 1] === '@' &&
                isBoundary(input[i - 1])) {
                const match = input.slice(i + 2).match(/^[a-zA-Z0-9_-]+/);
                if (match) {
                    flushText();
                    tokens.push({
                        type: 'agent',
                        value: match[0],
                    });
                    i += match[0].length + 2;
                    continue;
                }
            }
            // mention markdown [@Name](userId)
            if (input[i] === '[' && input[i + 1] === '@') {
                const closeText = input.indexOf(']', i + 2);
                const openParen = input[closeText + 1] === '(' ? closeText + 1 : -1;
                const closeParen = openParen !== -1
                    ? input.indexOf(')', openParen + 1)
                    : -1;
                if (closeText !== -1 && openParen !== -1 && closeParen !== -1) {
                    flushText();
                    const name = input.slice(i + 2, closeText);
                    const userId = input.slice(openParen + 1, closeParen);
                    tokens.push({
                        type: 'mention',
                        value: name,
                        userId,
                    });
                    i = closeParen + 1;
                    continue;
                }
            }
            // channel #
            if (input[i] === '#' && isBoundary(input[i - 1])) {
                const match = input.slice(i + 1).match(/^[a-zA-Z0-9_-]+/);
                if (match) {
                    flushText();
                    tokens.push({
                        type: 'channel',
                        value: match[0],
                    });
                    i += match[0].length + 1;
                    continue;
                }
            }
            // command /
            if (input[i] === '/' && isBoundary(input[i - 1])) {
                const match = input.slice(i + 1).match(/^[a-zA-Z0-9_-]+/);
                if (match) {
                    flushText();
                    tokens.push({
                        type: 'command',
                        value: match[0],
                    });
                    i += match[0].length + 1;
                    continue;
                }
            }
            // help ?
            if (input[i] === '?' && isBoundary(input[i - 1])) {
                const match = input.slice(i + 1).match(/^[a-zA-Z0-9_-]+/);
                if (match) {
                    flushText();
                    tokens.push({ type: 'help', value: match[0] });
                    i += match[0].length + 1;
                    continue;
                }
            }
            // markdown link [text](url)
            if (input[i] === '[') {
                const closeText = input.indexOf(']', i + 1);
                const openParen = input[closeText + 1] === '(' ? closeText + 1 : -1;
                const closeParen = openParen !== -1 ? input.indexOf(')', openParen + 1) : -1;
                if (closeText !== -1 && openParen !== -1 && closeParen !== -1) {
                    flushText();
                    const text = input.slice(i + 1, closeText);
                    const url = input.slice(openParen + 1, closeParen);
                    tokens.push({ type: 'link', text, url });
                    i = closeParen + 1;
                    continue;
                }
            }
            // raw link
            if (isBoundary(input[i - 1])) {
                const match = matchRawLink(input.slice(i));
                if (match) {
                    flushText();
                    const url = match[0];
                    tokens.push({ type: 'raw-link', url });
                    i += url.length;
                    continue;
                }
            }
        }
        /* ───────────── DEFAULT CHAR ───────────── */
        buffer += input[i];
        i++;
    }
    /* ───────────── FLUSH ───────────── */
    if (buffer) {
        if (state === 'INLINE_CODE') {
            // Inline code não fechado - retorna como texto normal incluindo o backtick inicial
            tokens.push({ type: 'text', value: '`' + buffer });
        }
        else if (state === 'CODE_BLOCK') {
            // Code block não fechado - retorna como texto normal
            tokens.push({ type: 'text', value: codeBlockStart + buffer });
        }
        else {
            tokens.push({ type: 'text', value: buffer });
        }
    }
    return tokens;
}
