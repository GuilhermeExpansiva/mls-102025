/// <mls fileReference="_102025_/l2/collabMessagesTabMenu.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
const DEFAULT_ACTIVE_COLOR = '#1C91CD';
let CollabMessagesTabMenu = class CollabMessagesTabMenu extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-tab-menu-102025{display:block;width:375px}collab-messages-tab-menu-102025 .tab-menu{display:flex;align-items:center;height:40px;background:var(--bg-primary-color-darker);border-bottom:1px solid var(--grey-color)}collab-messages-tab-menu-102025 .menu-item{display:flex;align-items:center;justify-content:center;gap:var(--space-8);min-width:40px;height:40px;padding:0 var(--space-8);border:none;background:transparent;cursor:pointer;color:var(--text-primary-color-lighter);transition:color var(--transition-slow)}collab-messages-tab-menu-102025 .menu-item svg{width:14px;height:14px;fill:currentColor}collab-messages-tab-menu-102025 .menu-item:hover{color:var(--text-primary-color)}collab-messages-tab-menu-102025 .menu-item.active{padding:0 var(--space-16)}collab-messages-tab-menu-102025 .menu-item .item-label{font-family:var(--font-family-primary);font-size:var(--font-size-12);font-weight:var(--font-weight-bold);white-space:nowrap}collab-messages-tab-menu-102025 .separator{width:1px;height:20px;background:var(--grey-color);flex-shrink:0}collab-messages-tab-menu-102025 .spacer{flex:1}`);
        this.items = [];
        this.activeId = '';
    }
    get _tabs() {
        return this.items.filter(item => item.type === 'tab');
    }
    get _buttons() {
        return this.items.filter(item => item.type === 'button');
    }
    _handleItemClick(item) {
        this.activeId = item.id;
        const eventName = item.type === 'tab' ? 'tab-change' : 'button-click';
        this.dispatchEvent(new CustomEvent(eventName, {
            detail: { id: item.id, item },
            bubbles: true,
            composed: true
        }));
    }
    _renderItem(item, showSeparator = false) {
        const isActive = item.id === this.activeId;
        const activeColor = item.activeColor || DEFAULT_ACTIVE_COLOR;
        const activeStyle = isActive ? `color: ${activeColor};` : '';
        return html `
            <button 
                class="menu-item ${isActive ? 'active' : ''}"
                style="${activeStyle}"
                @click=${() => this._handleItemClick(item)}
            >
                ${item.icon}
                ${isActive ? html `<span class="item-label">${item.label}</span>` : ''}
            </button>
            ${showSeparator ? html `<div class="separator"></div>` : ''}
        `;
    }
    render() {
        const tabs = this._tabs;
        const buttons = this._buttons;
        return html `
            <div class="tab-menu">
                ${tabs.map((tab, index) => this._renderItem(tab, index < tabs.length - 1))}
                
                ${buttons.length > 0 ? html `
                    <div class="spacer"></div>
                    ${buttons.map(btn => this._renderItem(btn, false))}
                ` : ''}
            </div>
        `;
    }
};
__decorate([
    property({ type: Array })
], CollabMessagesTabMenu.prototype, "items", void 0);
__decorate([
    property({ type: String })
], CollabMessagesTabMenu.prototype, "activeId", void 0);
CollabMessagesTabMenu = __decorate([
    customElement('collab-messages-tab-menu-102025')
], CollabMessagesTabMenu);
export { CollabMessagesTabMenu };
