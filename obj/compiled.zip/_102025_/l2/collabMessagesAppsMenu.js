/// <mls fileReference="_102025_/l2/collabMessagesAppsMenu.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
let CollabMessagesAppsMenu = class CollabMessagesAppsMenu extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-apps-menu-102025{display:block;font-family:var(--font-family-primary);color:var(--text-primary-color);padding:var(--space-16)}collab-messages-apps-menu-102025 .menu-module{margin:var(--space-16) 0;border:1px solid var(--grey-color);border-radius:8px;background:var(--bg-secondary-color-lighter);transition:background var(--transition-normal)}collab-messages-apps-menu-102025 .menu-module summary{cursor:pointer;display:flex;align-items:center;padding:var(--space-8) var(--space-8);font-weight:var(--font-weight-bold);color:var(--text-primary-color);position:relative;list-style:none;user-select:none}collab-messages-apps-menu-102025 .menu-module summary .icon{width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;margin-right:var(--space-8)}collab-messages-apps-menu-102025 .menu-module summary .name{flex:1}collab-messages-apps-menu-102025 .menu-module summary::after{content:'▶';font-size:.8rem;color:var(--text-primary-color-lighter);margin-left:auto;transition:transform var(--transition-slow) ease,color var(--transition-slow)}collab-messages-apps-menu-102025 .menu-module[open]>summary::after{transform:rotate(0deg);color:var(--text-primary-color);content:'▼'}collab-messages-apps-menu-102025 .menu-list{list-style:none;margin:0;padding:0;padding-bottom:.3rem}collab-messages-apps-menu-102025 .favorites{list-style:none;padding:0;margin:1rem 0;padding-inline-start:1rem}collab-messages-apps-menu-102025 .favorites .favorite-item{cursor:pointer;margin-bottom:.7rem}collab-messages-apps-menu-102025 h3{border-bottom:1px solid #cecece;padding:.5rem}collab-messages-apps-menu-102025 .menu-item{padding-left:var(--space-16)}collab-messages-apps-menu-102025 .menu-item .menu-item-header{display:flex;gap:.4rem;align-items:center;justify-content:start;padding:var(--space-8);cursor:pointer;color:var(--text-primary-color);border-radius:4px;transition:background var(--transition-slow)}collab-messages-apps-menu-102025 .menu-item .menu-item-header:hover{background:var(--bg-primary-color-hover)}collab-messages-apps-menu-102025 .menu-item .menu-item-header .favorite{margin-left:auto;color:var(--grey-color-darker);cursor:pointer;font-size:1rem;transition:color var(--transition-fast)}collab-messages-apps-menu-102025 .menu-item .menu-item-header .favorite.active{color:var(--active-color)}collab-messages-apps-menu-102025 .menu-item .menu-item-header .favorite:hover{color:var(--active-color-hover)}collab-messages-apps-menu-102025 .menu-item .submenu{list-style:none;padding-inline-start:0;margin-left:1rem;margin-top:4px;border-left:2px solid var(--grey-color-darker)}`);
        this.keyFavoritesLocalStorage = 'menuFavorites';
        this.identifier = '';
        this.menuTitle = '';
        this.menuModules = [];
        this.favorites = [];
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.loadFavorites();
    }
    loadFavorites() {
        const saved = localStorage.getItem(this.keyFavoritesLocalStorage);
        if (!saved) {
            this.favorites = [];
            return;
        }
        try {
            const parsed = JSON.parse(saved);
            if (parsed && typeof parsed === 'object') {
                const currentProject = this.identifier.toString() ?? 'default';
                this.favorites = parsed[currentProject] ?? [];
            }
        }
        catch (err) {
            console.warn('Erro ao ler favoritos:', err);
            this.favorites = [];
        }
    }
    getItemPath(moduleItem, item) {
        const findPath = (menu, target, path) => {
            for (const m of menu) {
                const currentPath = [...path, m.title];
                if (m === target)
                    return currentPath;
                if (m.children) {
                    const found = findPath(m.children, target, currentPath);
                    if (found)
                        return found;
                }
            }
            return null;
        };
        const path = findPath(moduleItem.menu, item, [moduleItem.name]);
        return path ? path.join('/') : moduleItem.name;
    }
    toggleFavorite(moduleItem, item) {
        const key = this.getItemPath(moduleItem, item);
        const currentProject = this.identifier.toString() ?? 'default';
        let stored = {};
        try {
            const raw = localStorage.getItem(this.keyFavoritesLocalStorage);
            stored = raw ? JSON.parse(raw) : {};
        }
        catch {
            stored = {};
        }
        if (!Array.isArray(stored[currentProject])) {
            stored[currentProject] = [];
        }
        const favorites = stored[currentProject];
        const index = favorites.indexOf(key);
        if (index >= 0) {
            favorites.splice(index, 1);
        }
        else {
            favorites.push(key);
        }
        stored[currentProject] = favorites;
        localStorage.setItem(this.keyFavoritesLocalStorage, JSON.stringify(stored));
        this.favorites = favorites;
        this.requestUpdate();
    }
    isFavorite(moduleItem, item) {
        const key = this.getItemPath(moduleItem, item);
        return this.favorites.includes(key);
    }
    handleMenuClick(moduleItem, item) {
        this.dispatchEvent(new CustomEvent('menu-selected', { detail: { ...item, project: moduleItem.project, module: moduleItem.name, path: moduleItem.path } }));
    }
    renderMenuItem(moduleItem, item) {
        const hasChildren = item.children && item.children.length > 0;
        return html `
			<li class="menu-item">
				<div class="menu-item-header" @click=${() => this.handleMenuClick(moduleItem, item)}>
					<span class="icon" .innerHTML=${item.icon}></span>
					<span class="title">${item.title}</span>
					<span
						class="favorite ${this.isFavorite(moduleItem, item) ? 'active' : ''}"
						title="Favoritar"
						@click=${(e) => {
            e.stopPropagation();
            this.toggleFavorite(moduleItem, item);
        }}
					>★</span>
				</div>

				${hasChildren
            ? html `
						<ul class="submenu">
							${item.children.map(child => this.renderMenuItem(moduleItem, child))}
						</ul>
					`
            : null}
			</li>
		`;
    }
    render() {
        return html `
			<div class="menu-container">
				<h3>Favoritos</h3>
                ${this.favorites.length === 0
            ? html `<p class="empty">Nenhum favorito.</p>`
            : html `
                        <ul class="favorites">
                            ${this.favorites.map(favKey => {
                const item = this.findItemByPath(favKey);
                if (!item || !item.menuItem || !item.moduleItem)
                    return null;
                const pathDisplay = favKey.replace(/\//g, ' / ');
                return html `
                        <li 
                            class="favorite-item"
                            title=${pathDisplay}
                            @click=${() => this.handleMenuClick(item.moduleItem, item.menuItem)}
                        >
                            <span class="icon" .innerHTML=${item.menuItem.icon}></span>
                            <span class="title">${pathDisplay}</span>
                        </li>
                    `;
            })}
                        </ul>
                    `}


				<h3>${this.menuTitle}</h3>
				${this.menuModules.map(module => html `
						<details class="menu-module">
							<summary>
								<span class="icon" .innerHTML=${module.icon}></span>
								<span class="name">${module.name}</span>
							</summary>
							<ul class="menu-list">
								${module.menu.map(item => this.renderMenuItem(module, item))}
							</ul>
						</details>
					`)}
			</div>
		`;
    }
    findItemByPath(path) {
        const parts = path.split('/');
        const moduleName = parts.shift();
        const module = this.menuModules.find(m => m.name === moduleName);
        if (!module)
            return {
                menuItem: null,
                moduleItem: undefined
            };
        let currentItems = module.menu;
        let found = null;
        for (const part of parts) {
            found = currentItems.find(i => i.title === part) || null;
            if (!found) {
                return {
                    menuItem: null,
                    moduleItem: undefined
                };
            }
            currentItems = found.children || [];
        }
        return {
            menuItem: found,
            moduleItem: module
        };
    }
};
__decorate([
    property()
], CollabMessagesAppsMenu.prototype, "keyFavoritesLocalStorage", void 0);
__decorate([
    property()
], CollabMessagesAppsMenu.prototype, "identifier", void 0);
__decorate([
    property()
], CollabMessagesAppsMenu.prototype, "menuTitle", void 0);
__decorate([
    state()
], CollabMessagesAppsMenu.prototype, "menuModules", void 0);
__decorate([
    state()
], CollabMessagesAppsMenu.prototype, "favorites", void 0);
CollabMessagesAppsMenu = __decorate([
    customElement('collab-messages-apps-menu-102025')
], CollabMessagesAppsMenu);
export { CollabMessagesAppsMenu };
