/// <mls fileReference="_102025_/l2/shared/api.ts" enhancement="_blank"/>
async function handleRequest(promise) {
    try {
        const res = await promise;
        if (res.statusCode >= 200 && res.statusCode < 300) {
            return {
                success: true,
                response: res,
                statusCode: res.statusCode
            };
        }
        return {
            success: false,
            error: res?.msg || 'Request failed',
            statusCode: res.statusCode
        };
    }
    catch (err) {
        return {
            success: false,
            error: err?.message || 'Unexpected error',
            statusCode: 500
        };
    }
}
export async function msgGetUsers(args) {
    return handleRequest(mls.api.msgGetUsers(args));
}
export function msgGetUserUpdate(args) {
    return handleRequest(mls.api.msgGetUserUpdate(args));
}
export function msgUpdateUserDetails(args) {
    return handleRequest(mls.api.msgUpdateUserDetails(args));
}
export function msgAddThread(args) {
    return handleRequest(mls.api.msgAddThread(args));
}
export async function msgUpdateThread(args) {
    return handleRequest(mls.api.msgUpdateThread(args));
}
export function msgRemoveParticipantFromThread(args) {
    const params = {
        action: 'removeUserInThread',
        ...args
    };
    return handleRequest(mls.api.msgUpdateThread(params));
}
export function msgAddParticipantToThread(args) {
    return handleRequest(mls.api.msgAddUserInThread(args));
}
export function msgGetThreadUpdates(args) {
    return handleRequest(mls.api.msgGetThreadUpdate(args));
}
export function msgGetTaskUpdate(args) {
    return handleRequest(mls.api.msgGetTaskUpdate(args));
}
export function msgAddMessage(args) {
    return handleRequest(mls.api.msgAddMessage(args));
}
export function msgAddOrUpdateThreadBot(args) {
    return handleRequest(mls.api.msgAddOrUpdateThreadBot({
        ...args,
    }));
}
export function msgAddOrUpdateThreadIntegration(args) {
    return handleRequest(mls.api.msgAddOrUpdateThreadIntegration({
        ...args
    }));
}
export function msgGetMessagesAfter(args) {
    return handleRequest(mls.api.msgGetMessagesAfter(args));
}
export function msgGetMessagesBefore(args) {
    return handleRequest(mls.api.msgGetMessagesBefore(args));
}
export function msgGetMessage(args) {
    return handleRequest(mls.api.msgGetMessage(args));
}
export function msgUpdateMessage(args) {
    return handleRequest(mls.api.msgUpdateMessage({
        ...args,
    }));
}
export function cbeAddOrUpdateOrgValue(key, value) {
    return handleRequest(mls.api.cbeAddOrUpdateOrgValue(key, value));
}
