/// <mls fileReference="_102025_/l2/collabMessagesTasks.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { collab_spinner_clock } from '/_102025_/l2/collabMessagesIcons.js';
let CollabMessagesTasks = class CollabMessagesTasks extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-tasks-102025 .task-details{padding:1rem;display:flex;flex-direction:column;gap:1rem}collab-messages-tasks-102025 .back-btn{background:none;border:none;color:var(--grey-color-darker);cursor:pointer;font-size:14px;display:flex;align-items:center;gap:.25rem}collab-messages-tasks-102025 .back-btn:hover{text-decoration:underline}collab-messages-tasks-102025 .task-list-container{display:flex;flex-direction:column;gap:2rem;padding:1rem}collab-messages-tasks-102025 .task-stage{display:flex;flex-direction:column}collab-messages-tasks-102025 .task-stage-header{display:flex;align-items:center;gap:1rem;font-size:var(--font-size-12);font-weight:bold;padding:.5rem 0;border-bottom:1px solid rgba(255,255,255,0.1)}collab-messages-tasks-102025 .stage-name{text-transform:uppercase}collab-messages-tasks-102025 .stage-count{color:var(--grey-color-darker)}collab-messages-tasks-102025 .stage-add{margin-left:auto;font-weight:normal;color:var(--grey-color-darker);cursor:pointer}collab-messages-tasks-102025 .stage-add:hover{text-decoration:underline}collab-messages-tasks-102025 .task-items{list-style:none;margin:0;padding:.25rem 0;display:flex;flex-direction:column;gap:.25rem}collab-messages-tasks-102025 .task-row{display:flex;align-items:center;gap:.5rem;font-size:var(--font-size-12);padding:.5rem .25rem;border-radius:4px;cursor:pointer}collab-messages-tasks-102025 .task-row:hover{background:rgba(255,255,255,0.05)}collab-messages-tasks-102025 .task-title{flex:1}collab-messages-tasks-102025 .task-check{font-size:12px;opacity:.7}collab-messages-tasks-102025 .task-meta{font-size:11px;opacity:.6}collab-messages-tasks-102025 .task-tag{font-size:10px;padding:.1rem .4rem;border-radius:4px;text-transform:uppercase}collab-messages-tasks-102025 .task-tag.bug{background:#d32f2f;color:white}`);
        this.view = 'list';
        this.selectedTask = null;
    }
    _backToList() {
        this.view = 'list';
        this.selectedTask = null;
    }
    render() {
        if (this.view === 'list') {
            return this._renderTaskList();
        }
        else {
            return this._renderTaskDetails();
        }
    }
    _renderTaskDetails() {
        return html `
      <div class="task-details">
        <button class="back-btn" @click=${this._backToList}>← Voltar</button>
        <h2>${this.selectedTask?.title}</h2>
        <p>In development</p>
      </div>
    `;
    }
    _renderTaskList() {
        return html `
      <div class="task-list-container">

        <!-- Stage: Em Progresso -->
        <div class="task-stage">
          <div class="task-stage-header">
            <span class="stage-name">EM PROGRESSO</span>
            <span class="stage-count">(2)</span>
            <span class="stage-add">+ Adicionar Tarefa</span>
          </div>
          <ul class="task-items">
            <li class="task-row">
              <span class="task-check">${collab_spinner_clock}</span>
              <span class="task-title">Bug explorer</span>
              <span class="task-tag bug">bug</span>
            </li>
            <li class="task-row">
              <span class="task-check">${collab_spinner_clock}</span>
              <span class="task-title">collab messages - ajustes</span>
              <span class="task-meta">3/23</span>
            </li>
          </ul>
        </div>

        <!-- Stage: Review -->
        <div class="task-stage">
          <div class="task-stage-header">
            <span class="stage-name">REVIEW</span>
            <span class="stage-count">(4)</span>
            <span class="stage-add">+ Adicionar Tarefa</span>
          </div>
          <ul class="task-items">
            <li class="task-row" @click=${() => this._openTaskDetails({ id: 1, title: 'Bug add new file' })}>
              <span class="task-check">✔</span>
              <span class="task-title">Bug add new file</span>
            </li>
            <li class="task-row">✔ <span class="task-title">Bug action</span></li>
            <li class="task-row">✔ <span class="task-title">agentImprovePrototype</span></li>
          </ul>
        </div>
        
        <!-- Stage: Pendente -->
        <div class="task-stage">
          <div class="task-stage-header">
            <span class="stage-name">PENDENTE</span>
            <span class="stage-count">(5)</span>
            <span class="stage-add">+ Adicionar Tarefa</span>
          </div>
          <ul class="task-items">
            <li class="task-row">⏳ <span class="task-title">criar widgets de galeria imagens</span></li>
            <li class="task-row">⏳ <span class="task-title">Bug Inicialização</span> <span class="task-tag bug">bug</span></li>
            <li class="task-row">⏳ <span class="task-title">Bug rename com folder</span></li>
            <li class="task-row">⏳ <span class="task-title">Bug import entre projetos</span></li>
            <li class="task-row">⏳ <span class="task-title">collabPreviewL4</span></li>
          </ul>
        </div>

      </div>
    `;
    }
    _openTaskDetails(task) {
        this.selectedTask = task;
        console.info('aq');
        this.view = 'details';
    }
};
__decorate([
    state()
], CollabMessagesTasks.prototype, "view", void 0);
__decorate([
    state()
], CollabMessagesTasks.prototype, "selectedTask", void 0);
CollabMessagesTasks = __decorate([
    customElement('collab-messages-tasks-102025')
], CollabMessagesTasks);
export { CollabMessagesTasks };
