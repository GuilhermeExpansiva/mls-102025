/// <mls fileReference="_102025_/l2/collabMessagesSettingsOpenClaw.ts" enhancement="_100554_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { generateUUIDv7, generateAgentAvatar, } from '/_102025_/l2/collabMessagesHelper.js';
import { collab_plug, collab_plus, collab_trash, collab_refresh, collab_chevron_left, collab_edit, collab_xmark, collab_floppy_disk, collab_check, collab_warning, collab_robot, } from '/_102025_/l2/collabMessagesIcons.js';
import { msgListOpenClawConnectors, msgAddOrUpdateOpenClawConnector } from '/_102025_/l2/shared/api.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando informações...',
    save: 'Salvar',
    cancel: 'Cancelar',
    back: 'Voltar',
    connectorsTitle: 'OpenClaw',
    newConnector: 'Novo connector',
    editConnector: 'Editar connector',
    noConnectors: 'Nenhum connector configurado',
    connectorName: 'Nome',
    connectorNameHint: 'Nome amigável para identificar esta instância',
    connectorNamePlaceholder: 'Ex: OpenClaw Produção',
    baseUrl: 'URL base',
    baseUrlHint: 'Deve apontar para o Gateway HTTP do OpenClaw (porta padrão: 18789)',
    baseUrlPlaceholder: 'https://chat-gw.collab.codes',
    gatewayToken: 'Gateway token',
    gatewayTokenHint: 'Token para autenticar chamadas ao endpoint /v1/chat/completions',
    inboundToken: 'Inbound token',
    inboundTokenHint: 'Token secreto para validar webhooks vindos do OpenClaw',
    defaultTimeout: 'Timeout (ms)',
    defaultTimeoutHint: 'Chamadas síncronas',
    outputMode: 'Modo de saída',
    outputModeHint: 'Como publicar respostas',
    connectorEnabled: 'Ativo',
    connectorDisabled: 'Inativo',
    configSection: 'Configuração',
    authSection: 'Autenticação',
    behaviorSection: 'Comportamento padrão',
    deleteSection: 'Remover integração',
    changeToken: 'Alterar',
    generateToken: 'Gerar',
    removeConnector: 'Remover',
    errorConnectorName: 'Nome do connector é obrigatório',
    errorBaseUrl: 'URL base é obrigatória',
    errorGatewayToken: 'Gateway token é obrigatório',
    errorInboundToken: 'Inbound token é obrigatório',
    successSavingConnector: 'Connector salvo com sucesso',
    successRemoveConnector: 'Connector removido com sucesso',
    deleteWarningTitle: 'Atenção',
    deleteWarningMessage: 'Ao remover este connector, todas as integrações associadas serão desativadas e os agentes configurados serão perdidos. Esta ação não pode ser desfeita.',
    deleteConfirmInstruction: 'Digite o nome do connector para confirmar:',
    deleteConfirmButton: 'Confirmar remoção',
    agentsSection: 'Agentes',
    addAgent: 'Adicionar agente',
    agentName: 'Nome do agente',
    agentAvatar: 'URL do avatar (opcional)',
    agentNamePlaceholder: 'Ex: Bot de Vendas',
    noAgents: 'Nenhum agente configurado',
    errorAgentName: 'O nome do agente é obrigatório',
    successAddingAgent: 'Agente adicionado com sucesso',
    confirmRemoveAgent: 'Remover este agente?',
    testConnectionSection: 'Verificar conexão',
    testConnectionInfo: 'Teste a conectividade com o servidor antes de salvar para garantir que as configurações estão corretas.',
    testConnectionBtn: 'Testar conexão',
    testConnectionTesting: 'Testando...',
    testConnectionSuccess: 'Conexão estabelecida com sucesso',
    testConnectionLatency: 'Latência',
    testConnectionError: 'Falha na conexão',
    testConnectionErrorTimeout: 'Timeout - servidor não respondeu',
    testConnectionErrorAuth: 'Erro de autenticação - verifique o token',
    testConnectionErrorNetwork: 'Erro de rede - verifique a URL',
    testConnectionErrorUnknown: 'Erro desconhecido',
};
const message_en = {
    loading: 'Loading...',
    save: 'Save',
    cancel: 'Cancel',
    back: 'Back',
    connectorsTitle: 'OpenClaw',
    newConnector: 'New connector',
    editConnector: 'Edit connector',
    noConnectors: 'No connectors configured',
    connectorName: 'Name',
    connectorNameHint: 'Friendly name to identify this instance',
    connectorNamePlaceholder: 'Ex: OpenClaw Production',
    baseUrl: 'Base URL',
    baseUrlHint: 'Must point to the OpenClaw HTTP Gateway (default port: 18789)',
    baseUrlPlaceholder: 'https://chat-gw.collab.codes',
    gatewayToken: 'Gateway token',
    gatewayTokenHint: 'Token to authenticate calls to /v1/chat/completions endpoint',
    inboundToken: 'Inbound token',
    inboundTokenHint: 'Secret token to validate webhooks from OpenClaw',
    defaultTimeout: 'Timeout (ms)',
    defaultTimeoutHint: 'Synchronous calls',
    outputMode: 'Output mode',
    outputModeHint: 'How to publish responses',
    connectorEnabled: 'Active',
    connectorDisabled: 'Inactive',
    configSection: 'Configuration',
    authSection: 'Authentication',
    behaviorSection: 'Default behavior',
    deleteSection: 'Remove integration',
    changeToken: 'Change',
    generateToken: 'Generate',
    removeConnector: 'Remove',
    errorConnectorName: 'Connector name is required',
    errorBaseUrl: 'Base URL is required',
    errorGatewayToken: 'Gateway token is required',
    errorInboundToken: 'Inbound token is required',
    successSavingConnector: 'Connector saved successfully',
    successRemoveConnector: 'Connector removed successfully',
    deleteWarningTitle: 'Warning',
    deleteWarningMessage: 'Removing this connector will disable all associated integrations and configured agents will be lost. This action cannot be undone.',
    deleteConfirmInstruction: 'Type the connector name to confirm:',
    deleteConfirmButton: 'Confirm removal',
    agentsSection: 'Agents',
    addAgent: 'Add agent',
    agentName: 'Agent name',
    agentAvatar: 'Avatar URL (optional)',
    agentNamePlaceholder: 'Ex: Sales Bot',
    noAgents: 'No agents configured',
    errorAgentName: 'Agent name is required',
    successAddingAgent: 'Agent added successfully',
    confirmRemoveAgent: 'Remove this agent?',
    testConnectionSection: 'Verify connection',
    testConnectionInfo: 'Test connectivity with the server before saving to ensure the settings are correct.',
    testConnectionBtn: 'Test connection',
    testConnectionTesting: 'Testing...',
    testConnectionSuccess: 'Connection established successfully',
    testConnectionLatency: 'Latency',
    testConnectionError: 'Connection failed',
    testConnectionErrorTimeout: 'Timeout - server did not respond',
    testConnectionErrorAuth: 'Authentication error - check the token',
    testConnectionErrorNetwork: 'Network error - check the URL',
    testConnectionErrorUnknown: 'Unknown error',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let CollabMessagesSettingsOpenClaw = class CollabMessagesSettingsOpenClaw extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-open-claw-102025{display:block}collab-messages-settings-open-claw-102025 button{background-color:var(--info-color);box-shadow:0 1px 3px 0 var(--grey-color);flex-direction:row;justify-content:center;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);color:#ffffff;padding:.5rem 1rem;border:none;border-radius:6px;cursor:pointer;font-size:var(--font-size-12);font-weight:var(--font-weight-bold);display:flex;align-items:center;gap:.25rem;white-space:nowrap;flex-shrink:0}collab-messages-settings-open-claw-102025 button svg{flex-shrink:0;fill:currentColor}collab-messages-settings-open-claw-102025 button:hover{background-color:var(--info-color-hover)}collab-messages-settings-open-claw-102025 button:disabled{opacity:.6;cursor:not-allowed}collab-messages-settings-open-claw-102025 button.btn-icon{width:32px;height:32px;padding:.25rem;border-radius:6px;background-color:transparent;color:var(--text-primary-color-lighter);box-shadow:none;border:1px solid var(--grey-color)}collab-messages-settings-open-claw-102025 button.btn-icon:hover{background-color:var(--bg-secondary-color)}collab-messages-settings-open-claw-102025 button.btn-icon svg{width:16px;height:16px}collab-messages-settings-open-claw-102025 button.btn-icon.btn-danger{color:var(--error-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-danger:hover{background-color:rgba(255,77,79,0.1)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-danger svg{fill:var(--error-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-toggle.on{color:var(--success-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-toggle.on svg{stroke:var(--success-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-toggle.off{color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-back{width:32px;height:32px;padding:.25rem;border-radius:6px;background-color:transparent;color:var(--text-primary-color);box-shadow:none;margin-right:.5rem}collab-messages-settings-open-claw-102025 button.btn-icon.btn-back:hover{background-color:var(--bg-secondary-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-back svg{width:20px;height:20px}collab-messages-settings-open-claw-102025 button.btn-secondary{background-color:var(--bg-secondary-color);color:var(--text-primary-color)}collab-messages-settings-open-claw-102025 button.btn-secondary:hover{background-color:var(--bg-secondary-color-hover)}collab-messages-settings-open-claw-102025 button.btn-link{border:none;background-color:transparent;color:var(--active-color);box-shadow:none;cursor:pointer;padding:0;height:auto}collab-messages-settings-open-claw-102025 button.btn-link:hover{text-decoration:underline}collab-messages-settings-open-claw-102025 button.btn-link svg{width:14px;height:14px}collab-messages-settings-open-claw-102025 button.btn-danger-outline{background-color:transparent !important;color:var(--error-color) !important;border:1px solid var(--error-color) !important;width:100%;justify-content:center}collab-messages-settings-open-claw-102025 button.btn-danger-outline:hover{background-color:rgba(255,77,79,0.1) !important}collab-messages-settings-open-claw-102025 button.btn-danger-outline svg{width:16px;height:16px;fill:var(--error-color)}collab-messages-settings-open-claw-102025 button.btn-back{width:32px;height:32px;padding:.25rem;border-radius:6px;background-color:transparent;color:var(--text-primary-color);box-shadow:none}collab-messages-settings-open-claw-102025 button.btn-back:hover{background-color:var(--bg-secondary-color)}collab-messages-settings-open-claw-102025 button.btn-back svg{width:20px;height:20px}collab-messages-settings-open-claw-102025 button.btn-change-token{height:30px;padding:0 12px;background-color:var(--bg-secondary-color);color:var(--text-primary-color-lighter);border:1px solid var(--grey-color);font-size:var(--font-size-12)}collab-messages-settings-open-claw-102025 button.btn-change-token:hover{background-color:var(--bg-secondary-color-hover)}collab-messages-settings-open-claw-102025 button.btn-change-token svg{width:14px;height:14px}collab-messages-settings-open-claw-102025 .section{padding:1.4rem .75rem;border-radius:10px;box-shadow:#e7e3e3 0 1px 4px;background-color:var(--bg-primary-color-darker);margin-bottom:1.5rem}collab-messages-settings-open-claw-102025 .section h4{display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem;margin-block-start:0;padding-bottom:.4rem;border-bottom:1px solid #d2d2d2}collab-messages-settings-open-claw-102025 .section h4 svg{fill:currentColor;width:20px;height:20px}collab-messages-settings-open-claw-102025 .section .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-settings-open-claw-102025 .section .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-settings-open-claw-102025 .section .saving-error{color:var(--error-color);font-size:var(--font-size-12)}collab-messages-settings-open-claw-102025 .section .no-items{color:var(--text-primary-color-lighter);font-style:italic;margin:.5rem 0}collab-messages-settings-open-claw-102025 .section .form-field{margin-bottom:1rem}collab-messages-settings-open-claw-102025 .section .form-field label{display:block;font-size:var(--font-size-12);margin-bottom:.3rem}collab-messages-settings-open-claw-102025 .section .form-field .field-hint{display:block;font-size:11px;color:var(--text-primary-color-lighter);margin-top:3px}collab-messages-settings-open-claw-102025 .section .form-field .field-hint.warning{color:var(--warning-color);display:flex;align-items:flex-start;gap:4px}collab-messages-settings-open-claw-102025 .section .form-field .field-hint.warning svg{flex-shrink:0;width:12px;height:12px;fill:currentColor;margin-top:1px}collab-messages-settings-open-claw-102025 .section .form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}collab-messages-settings-open-claw-102025 .section .form-actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:.75rem;margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--grey-color)}collab-messages-settings-open-claw-102025 .section input,collab-messages-settings-open-claw-102025 .section select{display:flex;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;max-height:30px;height:30px;padding:0 .5rem}collab-messages-settings-open-claw-102025 .section input[type="number"],collab-messages-settings-open-claw-102025 .section input[type="text"],collab-messages-settings-open-claw-102025 .section input[type="url"],collab-messages-settings-open-claw-102025 .section input[type="password"]{width:100%;box-sizing:border-box}collab-messages-settings-open-claw-102025 .section select{width:100%;box-sizing:border-box}collab-messages-settings-open-claw-102025 .connector-details-header{display:flex;align-items:center;gap:.5rem;margin-bottom:1rem;padding-bottom:.5rem}collab-messages-settings-open-claw-102025 .connector-details-header h3{display:flex;align-items:center;gap:.5rem;margin:0;font-size:var(--font-size-20)}collab-messages-settings-open-claw-102025 .connector-details-header h3 svg{fill:currentColor;width:24px;height:24px}collab-messages-settings-open-claw-102025 .connectors .connectors-list{display:flex;flex-direction:column;gap:12px}collab-messages-settings-open-claw-102025 .connectors .connector-add-link{margin-top:1rem}collab-messages-settings-open-claw-102025 .connector-card{background-color:var(--bg-primary-color);border:1px solid var(--grey-color);border-radius:8px;padding:1rem;display:flex;justify-content:space-between;align-items:flex-start;gap:12px}collab-messages-settings-open-claw-102025 .connector-card.disabled{opacity:.65}collab-messages-settings-open-claw-102025 .connector-card .connector-info{flex:1;min-width:0}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-header{display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-name{font-size:15px;font-weight:var(--font-weight-bold)}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-status{display:inline-flex;align-items:center;gap:4px;font-size:11px;padding:2px 8px;border-radius:10px}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-status .status-dot{width:6px;height:6px;border-radius:50%;background-color:currentColor}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-status.active{background-color:rgba(82,196,26,0.15);color:var(--success-color)}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-status.inactive{background-color:var(--bg-secondary-color);color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-url{font-size:13px;color:var(--text-primary-color-lighter);margin-bottom:8px;word-break:break-all}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-meta{display:flex;flex-wrap:wrap;gap:12px;font-size:12px;color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-meta strong{color:var(--text-primary-color);font-weight:var(--font-weight-normal)}collab-messages-settings-open-claw-102025 .connector-card .connector-actions{display:flex;gap:4px;flex-shrink:0}collab-messages-settings-open-claw-102025 .connector-form .section-header{display:flex;align-items:center;justify-content:space-between;padding-bottom:1rem;margin-bottom:1.25rem;border-bottom:1px solid #cecece}collab-messages-settings-open-claw-102025 .connector-form .section-divider{padding-bottom:1rem;margin-bottom:1.25rem;border-bottom:1px solid #cecece}collab-messages-settings-open-claw-102025 .connector-form .section-title{font-size:14px;font-weight:var(--font-weight-bold);color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 .connector-form .toggle-label{display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer}collab-messages-settings-open-claw-102025 .connector-form .toggle-label .toggle-switch{position:relative;width:36px;height:20px;background-color:var(--grey-color-dark);border-radius:10px;transition:background-color .2s}collab-messages-settings-open-claw-102025 .connector-form .toggle-label .toggle-switch .toggle-thumb{position:absolute;top:2px;left:2px;width:16px;height:16px;background-color:white;border-radius:50%;box-shadow:0 1px 3px rgba(0,0,0,0.2);transition:left .2s}collab-messages-settings-open-claw-102025 .connector-form .toggle-label .toggle-switch.on{background-color:var(--success-color)}collab-messages-settings-open-claw-102025 .connector-form .toggle-label .toggle-switch.on .toggle-thumb{left:18px}collab-messages-settings-open-claw-102025 .connector-form .token-field{display:flex;gap:6px}collab-messages-settings-open-claw-102025 .connector-form .token-field input{flex:1;font-family:monospace;font-size:13px;letter-spacing:2px}collab-messages-settings-open-claw-102025 .connector-form .token-field .btn-icon{width:30px;height:30px;flex-shrink:0}collab-messages-settings-open-claw-102025 .connector-form .avatar-input-group{display:flex;gap:.5rem;align-items:center}collab-messages-settings-open-claw-102025 .connector-form .avatar-input-group input{flex:1}collab-messages-settings-open-claw-102025 .test-connection-section .test-connection-info{font-size:var(--font-size-12);color:var(--text-primary-color-lighter);line-height:1.5;margin:0 0 1rem}collab-messages-settings-open-claw-102025 .test-connection-section .test-result{display:flex;align-items:flex-start;gap:12px;padding:12px;border-radius:8px;margin-bottom:1rem}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-icon{flex-shrink:0;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-icon svg{width:14px;height:14px;fill:currentColor}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-content{display:flex;flex-direction:column;gap:2px}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-content .test-result-title{font-size:14px;font-weight:var(--font-weight-bold)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-content .test-result-detail{font-size:12px}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.success{background-color:rgba(82,196,26,0.1);border:1px solid rgba(82,196,26,0.25)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.success .test-result-icon{background-color:var(--success-color);color:white}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.success .test-result-title{color:#368011}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.success .test-result-detail{color:var(--success-color)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.error{background-color:rgba(255,77,79,0.08);border:1px solid rgba(255,77,79,0.25)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.error .test-result-icon{background-color:var(--error-color);color:white}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.error .test-result-title{color:#ff1a1d}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.error .test-result-detail{color:var(--error-color)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection{width:100%;height:44px;background-color:rgba(10,109,201,0.1);border:1px solid rgba(10,109,201,0.25);color:var(--info-color);border-radius:8px;font-size:14px;font-weight:var(--font-weight-bold);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .2s ease;box-shadow:none}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection svg{width:18px;height:18px;stroke:currentColor;fill:none}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection:hover:not(:disabled){background-color:rgba(10,109,201,0.18);border-color:rgba(10,109,201,0.4)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection:disabled{opacity:.5;cursor:not-allowed}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection.success{background-color:rgba(82,196,26,0.1);border-color:rgba(82,196,26,0.25);color:var(--success-color)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection.success:hover:not(:disabled){background-color:rgba(82,196,26,0.18);border-color:rgba(82,196,26,0.4)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection.error{background-color:rgba(255,77,79,0.08);border-color:rgba(255,77,79,0.25);color:var(--error-color)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection.error:hover:not(:disabled){background-color:rgba(255,77,79,0.15);border-color:rgba(255,77,79,0.4)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection .loader{width:18px;height:18px;border-width:2px}collab-messages-settings-open-claw-102025 .delete-warning-section{margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--grey-color)}collab-messages-settings-open-claw-102025 .delete-warning-box{background-color:rgba(255,77,79,0.08);border:1px solid rgba(255,77,79,0.25);border-radius:8px;padding:1rem}collab-messages-settings-open-claw-102025 .delete-warning-box .warning-header{display:flex;align-items:center;gap:8px;font-weight:var(--font-weight-bold);color:var(--error-color);margin-bottom:.5rem}collab-messages-settings-open-claw-102025 .delete-warning-box .warning-header svg{width:18px;height:18px;fill:var(--error-color);flex-shrink:0}collab-messages-settings-open-claw-102025 .delete-warning-box .warning-message{font-size:var(--font-size-12);color:var(--text-primary-color);line-height:1.5;margin:0 0 1rem 0}collab-messages-settings-open-claw-102025 .delete-confirmation{width:100%;animation:slideDown .2s ease;margin-top:1rem}@keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}collab-messages-settings-open-claw-102025 .delete-confirmation label{display:block;font-size:var(--font-size-12);color:var(--text-primary-color);margin-bottom:.25rem}collab-messages-settings-open-claw-102025 .delete-confirmation .confirm-name{display:block;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);font-family:monospace;margin-bottom:.5rem}collab-messages-settings-open-claw-102025 .delete-confirmation input{width:100%;padding:.5rem;height:auto !important;max-height:none !important;box-sizing:border-box}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions{display:flex;justify-content:flex-end;gap:.5rem;margin-top:.75rem}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions button{height:32px;font-size:var(--font-size-12);padding:0 .75rem;box-shadow:none}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-cancel{background:transparent;color:var(--text-primary-color);border:1px solid var(--grey-color-dark)}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-cancel:hover{background:var(--bg-secondary-color)}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-confirm{background:var(--error-color);color:white}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-confirm:hover:not(:disabled){background:var(--error-color-hover)}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-confirm:disabled{background:var(--grey-color-dark);color:var(--text-primary-color-lighter);cursor:not-allowed}collab-messages-settings-open-claw-102025 .agents-list{display:flex;flex-direction:column;gap:8px;margin-bottom:.5rem}collab-messages-settings-open-claw-102025 .agent-add-link{margin-top:.5rem;margin-bottom:1rem}collab-messages-settings-open-claw-102025 .agent-card{display:flex;align-items:center;gap:10px;background-color:var(--bg-secondary-color-lighter);border-radius:8px;padding:10px 12px}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar{flex-shrink:0}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar img{width:36px;height:36px;border-radius:50%;object-fit:cover}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar .agent-avatar-placeholder{width:36px;height:36px;border-radius:50%;background-color:var(--grey-color);display:flex;align-items:center;justify-content:center}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar .agent-avatar-placeholder svg{width:18px;height:18px;color:var(--text-primary-color-lighter);fill:currentColor}collab-messages-settings-open-claw-102025 .agent-card .agent-info{flex:1;min-width:0;display:flex;flex-direction:column}collab-messages-settings-open-claw-102025 .agent-card .agent-info .agent-name{font-weight:var(--font-weight-bold);font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-settings-open-claw-102025 .agent-card .agent-info .agent-sender-id{font-family:monospace;font-size:11px;color:var(--text-primary-color-lighter);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-settings-open-claw-102025 .agent-card .agent-actions{display:flex;gap:4px;flex-shrink:0}collab-messages-settings-open-claw-102025 .agent-card .agent-actions .btn-icon{width:28px;height:28px;border:none}collab-messages-settings-open-claw-102025 .agent-card .agent-actions .btn-icon svg{width:14px;height:14px}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large{display:flex;align-items:center;gap:16px;padding:16px;background-color:var(--bg-secondary-color-lighter);border-radius:10px;margin-bottom:1.5rem}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-avatar{width:64px;height:64px;border-radius:50%;object-fit:cover;border:2px solid var(--grey-color)}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-avatar-placeholder{width:64px;height:64px;border-radius:50%;background-color:var(--grey-color);display:flex;align-items:center;justify-content:center;border:2px solid var(--grey-color-dark)}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-avatar-placeholder svg{width:32px;height:32px;color:var(--text-primary-color-lighter);fill:currentColor}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-info{display:flex;flex-direction:column;gap:4px}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-info .preview-name{font-weight:var(--font-weight-bold);font-size:var(--font-size-16);color:var(--text-primary-color)}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-info .preview-sender-id{font-family:monospace;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}`);
        this.msg = messages['en'];
        this.userId = '';
        // OpenClaw Connector states
        this.connectors = [];
        this.viewMode = 'main';
        this.currentConnectorId = '';
        this.editingConnector = null;
        this.isTestingConnection = false;
        this.connectionTestResult = 'none';
        this.connectionTestMessage = '';
        this.connectionTestLatency = 0;
        // Delete confirmation states
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        // Agent states
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.editingAgent = null;
        this.isNewAgent = false;
        this.labelOkConnector = '';
        this.labelErrorConnector = '';
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.isSavingConnector = false;
        this.isSavingAgent = false;
    }
    async firstUpdated() {
        if (!this.userId)
            return;
        const rc = await msgListOpenClawConnectors({
            userId: this.userId
        });
        if (rc.response) {
            this.connectors = rc.response.connectors.map((item) => {
                return {
                    ...item, isNew: false, agents: [
                        {
                            "id": "main",
                            "identityName": "Eduardo",
                            "identityEmoji": "🧭",
                            "identitySource": "identity",
                            "workspace": "/home/node/.openclaw/workspace",
                            "agentDir": "/home/node/.openclaw/agents/main/agent",
                            "model": "microsoft-foundry/gpt-4.1",
                            "bindings": 0,
                            "isDefault": true,
                            "routes": [
                                "default (no explicit rules)"
                            ]
                        },
                    ], gatewayTokenChanged: false, inboundTokenChanged: false
                };
            });
        }
        // Dados de teste
        /*this.connectors = [
            {
                "connectorId": "01936f8a-7c2e-7d4b-9a1f-3e8b5c6d7a2f",
                "name": "OpenClaw Produção",
                "baseUrl": "https://openclaw.collab.codes",
                "gatewayToken": "d46e07c67f4196e537c69d1998c3a7ea03529fd89f43f3e2dbe52d7d12059c68",
                "inboundToken": "wh-prod-x9y8z7w6v5u4t3s2r1q0p9o8n7m6l5k4",
                "enabled": true,
                "defaultTimeoutMs": 60000,
                "defaultOutputMode": "final_only",
                "agents": [
                    {
                        "id": "01936f8a-8d3e-7f4a-9b2c-1d4e5f6a7b8c",
                        "name": "Assistant Bot",
                        "avatarUrl": "https://api.dicebear.com/7.x/bottts/svg?seed=assistant",
                        "senderId": "integration:openclaw:assistantbot",
                        "createdAt": "2024-11-15T10:35:00.000Z"
                    },
                    {
                        "id": "01936f8a-9e4f-8a5b-0c3d-2e5f6a7b8c9d",
                        "name": "Support Agent",
                        "avatarUrl": "https://api.dicebear.com/7.x/bottts/svg?seed=support",
                        "senderId": "integration:openclaw:supportagent",
                        "createdAt": "2024-11-16T14:20:00.000Z"
                    }
                ],
            },
        ];*/
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.viewMode === 'editAgent') {
            return this.renderEditAgentView();
        }
        if (this.viewMode === 'connectorDetails') {
            return this.renderConnectorDetailsView();
        }
        return this.renderOpenClawConnectors();
    }
    renderOpenClawConnectors() {
        return html `
        <div>
            <div class="section connectors">
                <h4>${collab_plug} ${this.msg.connectorsTitle}</h4>

                ${this.connectors.length === 0
            ? html `<p class="no-items">${this.msg.noConnectors}</p>`
            : html `
                        <div class="connectors-list">
                            ${this.connectors.map(connector => this.renderConnectorCard(connector))}
                        </div>
                    `}

                <div class="connector-add-link">
                    <button class="btn-link" @click=${this.handleAddConnector}>
                        ${collab_plus} ${this.msg.newConnector}
                    </button>
                </div>
            </div>
        </div>`;
    }
    renderConnectorCard(connector) {
        const isEnabled = connector.enabled;
        const agentCount = connector.agents?.length || 0;
        return html `
        <div class="connector-card ${!isEnabled ? 'disabled' : ''}">
            <div class="connector-info">
                <div class="connector-header">
                    <span class="connector-name">${connector.name || `Connector #${connector.connectorId.slice(0, 8)}`}</span>
                    <span class="connector-status ${isEnabled ? 'active' : 'inactive'}">
                        <span class="status-dot"></span>
                        ${isEnabled ? this.msg.connectorEnabled : this.msg.connectorDisabled}
                    </span>
                </div>
                <div class="connector-url">${connector.baseUrl}</div>
                <div class="connector-meta">
                    <span>Timeout: <strong>${connector.defaultTimeoutMs}ms</strong></span>
                    <span>${this.msg.agentsSection}: <strong>${agentCount}</strong></span>
                </div>
            </div>
            <div class="connector-actions">
                <button class="btn-icon" @click=${() => this.handleOpenConnectorDetails(connector.connectorId)} title="Editar">
                    ${collab_edit}
                </button>
                <button class="btn-icon btn-toggle ${isEnabled ? 'on' : 'off'}" @click=${() => this.handleToggleConnector(connector.connectorId)} title="${isEnabled ? 'Desativar' : 'Ativar'}">
                    ${this.renderToggleIcon(isEnabled)}
                </button>
            </div>
        </div>`;
    }
    renderToggleIcon(isOn) {
        return html `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="1" y="5" width="22" height="14" rx="7"/>
            <circle cx="${isOn ? 16 : 8}" cy="12" r="3" fill="currentColor"/>
        </svg>`;
    }
    renderConnectorDetailsView() {
        if (!this.editingConnector)
            return html ``;
        const connector = this.editingConnector;
        return html `
        <div>
            <div class="connector-details-header">
                <button class="btn-back" @click=${this.handleBackToMain}>
                    ${collab_chevron_left}
                </button>
                <h3>${collab_plug} ${connector.isNew ? this.msg.newConnector : this.msg.editConnector}</h3>
            </div>

            ${this.renderConfigurationSection(connector)}

            ${!connector.isNew ? this.renderAgentSection(connector) : html `${nothing}`}
            ${!connector.isNew ? this.renderDeleteSection(connector) : html `${nothing}`}
            
            ${this.labelOkConnector ? html `<small class="saving-ok">${this.labelOkConnector}</small>` : ''}
            ${this.labelErrorConnector ? html `<small class="saving-error">${this.labelErrorConnector}</small>` : ''}
        </div>`;
    }
    renderConfigurationSection(connector) {
        const isNew = connector.isNew;
        const showGatewayTokenField = isNew || connector.gatewayTokenChanged;
        const showInboundTokenField = isNew || connector.inboundTokenChanged;
        return html `
        <div class="section connector-form">
            <div class="section-header">
                <span class="section-title">${this.msg.configSection}</span>
                <label class="toggle-label" @click=${this.handleConnectorEnabledToggle}>
                    <span class="toggle-switch ${connector.enabled ? 'on' : ''}">
                        <span class="toggle-thumb"></span>
                    </span>
                    ${connector.enabled ? this.msg.connectorEnabled : this.msg.connectorDisabled}
                </label>
            </div>

            <div class="form-field">
                <label>${this.msg.connectorName} *</label>
                <input 
                    type="text" 
                    .value=${connector.name} 
                    @input=${this.handleConnectorNameChange}
                    placeholder="${this.msg.connectorNamePlaceholder}"
                />
                <small class="field-hint">${this.msg.connectorNameHint}</small>
            </div>

            <div class="form-field">
                <label>${this.msg.baseUrl} *</label>
                <input 
                    type="url" 
                    .value=${connector.baseUrl} 
                    @input=${this.handleConnectorUrlChange}
                    placeholder="${this.msg.baseUrlPlaceholder}"
                />
                <small class="field-hint warning">
                    ${collab_warning}
                    ${this.msg.baseUrlHint}
                </small>
            </div>

            <div class="section-divider">
                <span class="section-title">${this.msg.authSection}</span>
            </div>

            <div class="form-field">
                <label>${this.msg.gatewayToken} *</label>
                ${showGatewayTokenField ? html `
                    <div class="token-field">
                        <input 
                            type="text" 
                            .value=${connector.gatewayToken} 
                            @input=${this.handleGatewayTokenChange}
                            placeholder="Token..."
                        />
                        <button class="btn-icon" @click=${() => this.handleGenerateToken('gateway')} title="${this.msg.generateToken}">
                            ${collab_refresh}
                        </button>
                    </div>
                ` : html `
                    <div class="token-field">
                        <input type="password" value="••••••••••••••••••••••••" readonly />
                        <button class="btn-change-token" @click=${() => this.handleChangeToken('gateway')}>
                            ${collab_edit} ${this.msg.changeToken}
                        </button>
                    </div>
                `}
                <small class="field-hint">${this.msg.gatewayTokenHint}</small>
            </div>

            <div class="form-field">
                <label>${this.msg.inboundToken} *</label>
                ${showInboundTokenField ? html `
                    <div class="token-field">
                        <input 
                            type="text" 
                            .value=${connector.inboundToken} 
                            @input=${this.handleInboundTokenChange}
                            placeholder="Token..."
                        />
                        <button class="btn-icon" @click=${() => this.handleGenerateToken('inbound')} title="${this.msg.generateToken}">
                            ${collab_refresh}
                        </button>
                    </div>
                ` : html `
                    <div class="token-field">
                        <input type="password" value="••••••••••••••••••••••••" readonly />
                        <button class="btn-change-token" @click=${() => this.handleChangeToken('inbound')}>
                            ${collab_edit} ${this.msg.changeToken}
                        </button>
                    </div>
                `}
                <small class="field-hint">${this.msg.inboundTokenHint}</small>
            </div>

            <div class="section-divider">
                <span class="section-title">${this.msg.behaviorSection}</span>
            </div>

            <div class="form-row">
                <div class="form-field">
                    <label>${this.msg.defaultTimeout}</label>
                    <input 
                        type="number" 
                        .value=${String(connector.defaultTimeoutMs)} 
                        @input=${this.handleTimeoutChange}
                        min="5000" 
                        max="300000" 
                        step="1000"
                    />
                    <small class="field-hint">${this.msg.defaultTimeoutHint}</small>
                </div>
                <div class="form-field">
                    <label>${this.msg.outputMode}</label>
                    <select .value=${connector.defaultOutputMode} @change=${this.handleOutputModeChange}>
                        <option value="final_only">Final</option>
                        <option value="status_and_final">Status/Final</option>
                    </select>
                    <small class="field-hint">${this.msg.outputModeHint}</small>
                </div>
            </div>


            ${!connector.isNew ? this.renderTestConnectionSection(connector) : html `${nothing}`}


            <div class="form-actions">
                <button class="btn-secondary" @click=${this.handleCancelConnector}>
                    ${collab_xmark} ${this.msg.cancel}
                </button>
                <button @click=${this.handleSaveConnector} ?disabled=${this.isSavingConnector}>
                    ${this.isSavingConnector ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.save}`}
                </button>
            </div>
        </div>`;
    }
    renderTestConnectionSection(connector) {
        return html `
        <div class="section-divider">
            <span class="section-title">${this.msg.testConnectionSection}</span>
        </div>

        <div class="test-connection-section">
            <p class="test-connection-info">${this.msg.testConnectionInfo}</p>
            
            ${this.connectionTestResult === 'success' ? html `
                <div class="test-result success">
                    <div class="test-result-icon">
                        ${collab_check}
                    </div>
                    <div class="test-result-content">
                        <span class="test-result-title">${this.msg.testConnectionSuccess}</span>
                        <span class="test-result-detail">${this.msg.testConnectionLatency}: ${this.connectionTestLatency}ms</span>
                    </div>
                </div>
            ` : this.connectionTestResult === 'error' ? html `
                <div class="test-result error">
                    <div class="test-result-icon">
                        ${collab_xmark}
                    </div>
                    <div class="test-result-content">
                        <span class="test-result-title">${this.msg.testConnectionError}</span>
                        <span class="test-result-detail">${this.connectionTestMessage}</span>
                    </div>
                </div>
            ` : nothing}
            
            <button 
                class="btn-test-connection ${this.connectionTestResult}" 
                @click=${this.handleTestConnection}
                ?disabled=${this.isTestingConnection || !connector.baseUrl || !connector.gatewayToken}
            >
                ${this.isTestingConnection ? html `
                    <span class="loader"></span>
                    ${this.msg.testConnectionTesting}
                ` : html `
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                        <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                    ${this.msg.testConnectionBtn}
                `}
            </button>
        </div>`;
    }
    renderAgentSection(connector) {
        return html `
        <div class="section connector-form">
            <div class="section-divider">
                <span class="section-title">${this.msg.agentsSection}(In develpoment)</span>
            </div>

            <div class="agents-list">
                ${connector.agents.length === 0
            ? html `<p class="no-items">${this.msg.noAgents}</p>`
            : connector.agents.map((agent) => this.renderAgentCard(agent))}
            </div>

            <div class="agent-add-link">
                <button class="btn-link" @click=${this.handleOpenAddAgent} disabled >
                    ${collab_plus} ${this.msg.addAgent}
                </button>
            </div>
        </div>`;
    }
    renderDeleteSection(connector) {
        const isNew = connector.isNew;
        return html `
        <div class="section connector-form">
            <div class="section-divider">
                <span class="section-title">${this.msg.deleteSection}</span>
            </div>

            ${!isNew && !this.showDeleteConfirmation ? html `
                <div class="delete-warning-section">
                    <div class="delete-warning-box">
                        <div class="warning-header">
                            ${collab_warning}
                            <span>${this.msg.deleteWarningTitle}</span>
                        </div>
                        <p class="warning-message">${this.msg.deleteWarningMessage}</p>
                        <button class="btn-danger-outline" @click=${this.handleToggleDeleteConfirmation}>
                            ${collab_trash} ${this.msg.removeConnector}
                        </button>
                    </div>
                </div>
            ` : nothing}
            ${this.showDeleteConfirmation ? this.renderDeleteConfirmation(connector) : nothing}
        </div>`;
    }
    renderDeleteConfirmation(connector) {
        const connectorName = connector.name || `Connector #${connector.connectorId.slice(0, 8)}`;
        const isMatch = this.deleteConfirmationInput.trim() === connectorName;
        return html `
        <div class="delete-confirmation">
            <label>${this.msg.deleteConfirmInstruction}</label>
            <span class="confirm-name">${connectorName}</span>
            <input 
                type="text" 
                .value=${this.deleteConfirmationInput}
                @input=${this.handleDeleteConfirmationInput}
            />
            <div class="delete-actions">
                <button class="btn-cancel" @click=${this.handleCancelDelete}>
                    ${this.msg.cancel}
                </button>
                <button 
                    class="btn-confirm" 
                    @click=${() => this.handleConfirmDelete(connector.connectorId)}
                    ?disabled=${!isMatch || this.isSavingConnector}
                >
                    ${this.isSavingConnector ? html `<span class="loader"></span>` : this.msg.deleteConfirmButton}
                </button>
            </div>
        </div>`;
    }
    renderAgentCard(agent) {
        return html `
        <div class="agent-card">
            <div class="agent-avatar">
              ${this.renderAvatar(agent)}
            </div>
            <div class="agent-info">
                <span class="agent-name">${agent.identityName}</span>
                <span class="agent-sender-id">${agent.id}</span>
            </div>
            <div class="agent-actions" style="display:none"> 
                <button class="btn-icon" @click=${() => this.handleOpenEditAgent(agent)} title="${this.msg.editConnector}">
                    ${collab_edit}
                </button>
                <button class="btn-icon btn-danger" @click=${() => this.handleRemoveAgent(agent.id)} title="${this.msg.confirmRemoveAgent}">
                    ${collab_trash}
                </button>
            </div>
        </div>`;
    }
    renderAvatar(agent) {
        const value = agent.identityEmoji;
        if (!value) {
            return html `<div class="agent-avatar-placeholder">${collab_robot}</div>`;
        }
        // 1. SVG string
        if (value.trim().startsWith("<svg")) {
            return html `<div class="agent-avatar-svg" .innerHTML=${value}></div>`;
        }
        // 2. URL (http, https, data, etc)
        if (this.isUrl(value)) {
            return html `<img src="${value}" alt="${agent.identityName}" />`;
        }
        // 3. Emoji ou texto simples
        return html `<div class="agent-avatar-emoji">${value}</div>`;
    }
    isUrl(value) {
        try {
            new URL(value);
            return true;
        }
        catch {
            return value.startsWith("data:image");
        }
    }
    renderEditAgentView() {
        if (!this.editingConnector)
            return html ``;
        const previewAvatar = this.newAgentAvatarUrl || (this.newAgentName ? generateAgentAvatar(this.newAgentName) : '');
        const previewSenderId = this.newAgentName
            ? `integration:openclaw:${this.newAgentName.toLowerCase().replace(/\s+/g, '')}`
            : 'integration:openclaw:...';
        return html `
        <div>
            <div class="connector-details-header">
                <button class="btn-back" @click=${this.handleBackToConnectorDetails}>
                    ${collab_chevron_left}
                </button>
                <h3>${collab_robot} ${this.isNewAgent ? this.msg.addAgent : this.msg.editConnector}</h3>
            </div>

            <div class="section agent-form">
                <div class="agent-preview-large">
                    ${previewAvatar
            ? html `<img src="${previewAvatar}" alt="Preview" class="preview-avatar" />`
            : html `<div class="preview-avatar-placeholder">${collab_robot}</div>`}
                    <div class="preview-info">
                        <span class="preview-name">${this.newAgentName || '...'}</span>
                        <span class="preview-sender-id">${previewSenderId}</span>
                    </div>
                </div>

                <div class="form-field">
                    <label>${this.msg.agentName} *</label>
                    <input 
                        type="text" 
                        .value=${this.newAgentName} 
                        @input=${this.handleNewAgentNameInput} 
                        placeholder="${this.msg.agentNamePlaceholder}" 
                    />
                </div>

                <div class="form-field">
                    <label>${this.msg.agentAvatar}</label>
                    <div class="avatar-input-group">
                        <input 
                            type="url" 
                            .value=${this.newAgentAvatarUrl} 
                            @input=${this.handleNewAgentAvatarInput} 
                            placeholder="https://..." 
                        />
                        <button class="btn-icon" @click=${this.handleGenerateAgentAvatar} title="${this.msg.generateToken}">
                            ${collab_refresh}
                        </button>
                    </div>
                </div>

                <div class="form-actions">
                    <button class="btn-secondary" @click=${this.handleBackToConnectorDetails}>
                        ${collab_xmark} ${this.msg.cancel}
                    </button>
                    <button @click=${this.handleSaveAgent} ?disabled=${this.isSavingAgent}>
                        ${this.isSavingAgent
            ? html `<span class="loader"></span>`
            : html `${collab_floppy_disk} ${this.msg.save}`}
                    </button>
                </div>

                ${this.labelOkAgent ? html `<small class="saving-ok">${this.labelOkAgent}</small>` : ''}
                ${this.labelErrorAgent ? html `<small class="saving-error">${this.labelErrorAgent}</small>` : ''}
            </div>
        </div>`;
    }
    // ========== NAVIGATION ==========
    navigateTo(newView, resetScroll = false) {
        this.viewMode = newView;
        this.dispatchEvent(new CustomEvent('settings-change', {
            detail: { mode: 'view', viewMode: newView === 'main' ? 'all' : 'openclaw' },
            bubbles: true,
            composed: true
        }));
    }
    // ========== CONNECTOR HANDLERS ==========
    async handleAddConnector() {
        const newConnector = {
            connectorId: generateUUIDv7(),
            name: '',
            baseUrl: '',
            gatewayToken: '',
            inboundToken: '',
            enabled: true,
            defaultTimeoutMs: 60000,
            defaultOutputMode: 'final_only',
            agents: [],
            isNew: true
        };
        this.editingConnector = newConnector;
        this.currentConnectorId = newConnector.connectorId;
        this.clearStates();
        this.clearErrors();
        this.navigateTo('connectorDetails', true);
    }
    clearErrors() {
        this.labelOkConnector = '';
        this.labelErrorConnector = '';
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
    }
    clearStates() {
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.isTestingConnection = false;
        this.connectionTestResult = 'none';
        this.connectionTestMessage = '';
        this.connectionTestLatency = 0;
    }
    handleOpenConnectorDetails(connectorId) {
        const connector = this.connectors.find(c => c.connectorId === connectorId);
        if (!connector)
            return;
        this.editingConnector = {
            ...connector,
            agents: connector.agents || [],
            isNew: false,
            gatewayTokenChanged: false,
            inboundTokenChanged: false
        };
        this.currentConnectorId = connectorId;
        this.labelOkConnector = '';
        this.labelErrorConnector = '';
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.isTestingConnection = false;
        this.connectionTestResult = 'none';
        this.connectionTestMessage = '';
        this.connectionTestLatency = 0;
        this.navigateTo('connectorDetails', true);
    }
    handleBackToMain() {
        this.currentConnectorId = '';
        this.editingConnector = null;
        this.labelErrorConnector = '';
        this.labelOkConnector = '';
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.isTestingConnection = false;
        this.connectionTestResult = 'none';
        this.connectionTestMessage = '';
        this.connectionTestLatency = 0;
        this.navigateTo('main');
    }
    handleCancelConnector() {
        this.handleBackToMain();
    }
    handleConnectorNameChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, name: input.value };
    }
    handleConnectorUrlChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, baseUrl: input.value };
    }
    handleGatewayTokenChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, gatewayToken: input.value };
    }
    handleInboundTokenChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, inboundToken: input.value };
    }
    handleChangeToken(type) {
        if (!this.editingConnector)
            return;
        if (type === 'gateway') {
            this.editingConnector = { ...this.editingConnector, gatewayToken: '', gatewayTokenChanged: true };
        }
        else {
            this.editingConnector = { ...this.editingConnector, inboundToken: '', inboundTokenChanged: true };
        }
    }
    handleTimeoutChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, defaultTimeoutMs: parseInt(input.value) || 60000 };
    }
    handleOutputModeChange(e) {
        if (!this.editingConnector)
            return;
        const select = e.target;
        this.editingConnector = { ...this.editingConnector, defaultOutputMode: select.value };
    }
    handleConnectorEnabledToggle() {
        if (!this.editingConnector)
            return;
        this.editingConnector = { ...this.editingConnector, enabled: !this.editingConnector.enabled };
    }
    handleGenerateToken(type) {
        if (!this.editingConnector)
            return;
        const newToken = generateUUIDv7();
        if (type === 'gateway') {
            this.editingConnector = { ...this.editingConnector, gatewayToken: newToken };
        }
        else {
            this.editingConnector = { ...this.editingConnector, inboundToken: newToken };
        }
    }
    async handleToggleConnector(connectorId) {
        const connector = this.connectors.find(c => c.connectorId === connectorId);
        if (!connector)
            return;
        this.connectors = this.connectors.map(c => c.connectorId === connectorId ? { ...c, enabled: !c.enabled } : c);
        try {
            // await saveOpenClawConnectors(this.connectors);
        }
        catch (err) {
            this.connectors = this.connectors.map(c => c.connectorId === connectorId ? { ...c, enabled: !c.enabled } : c);
        }
    }
    async handleSaveConnector() {
        if (!this.editingConnector)
            return;
        this.labelOkConnector = '';
        this.labelErrorConnector = '';
        if (!this.editingConnector.name.trim()) {
            this.labelErrorConnector = this.msg.errorConnectorName;
            return;
        }
        if (!this.editingConnector.baseUrl.trim()) {
            this.labelErrorConnector = this.msg.errorBaseUrl;
            return;
        }
        const isNew = this.editingConnector.isNew;
        if (isNew) {
            if (!this.editingConnector.gatewayToken.trim()) {
                this.labelErrorConnector = this.msg.errorGatewayToken;
                return;
            }
            if (!this.editingConnector.inboundToken.trim()) {
                this.labelErrorConnector = this.msg.errorInboundToken;
                return;
            }
        }
        this.isSavingConnector = true;
        const { isNew: _, gatewayTokenChanged, inboundTokenChanged, ...connectorData } = this.editingConnector;
        let updatedConnectors;
        if (isNew) {
            updatedConnectors = [...this.connectors, connectorData];
        }
        else {
            updatedConnectors = this.connectors.map(c => {
                if (c.connectorId === connectorData.connectorId) {
                    return {
                        ...c,
                        ...connectorData,
                        gatewayToken: gatewayTokenChanged ? connectorData.gatewayToken : c.gatewayToken,
                        inboundToken: inboundTokenChanged ? connectorData.inboundToken : c.inboundToken,
                    };
                }
                return c;
            });
        }
        try {
            await this.saveOpenClawConnector(this.editingConnector);
            this.connectors = updatedConnectors;
            this.labelOkConnector = this.msg.successSavingConnector;
            if (isNew) {
                this.editingConnector = {
                    ...this.editingConnector,
                    isNew: false,
                    gatewayTokenChanged: false,
                    inboundTokenChanged: false
                };
            }
        }
        catch (err) {
            this.labelErrorConnector = err.message;
        }
        finally {
            this.isSavingConnector = false;
        }
    }
    async saveOpenClawConnector(newConnector) {
        if (!this.userId)
            throw new Error('Invalid user id');
        const { isNew, agents, gatewayTokenChanged, inboundTokenChanged, ...payload } = newConnector;
        const result = await msgAddOrUpdateOpenClawConnector({
            userId: this.userId,
            ...payload
        });
        if (!result.success || !result.response) {
            throw new Error(result.error || 'Failed to update the thread avatar. Please try again.');
        }
        ;
        return result;
    }
    async handleTestConnection() {
        if (!this.editingConnector)
            return;
        const { baseUrl, gatewayToken } = this.editingConnector;
        if (!baseUrl || !gatewayToken)
            return;
        this.isTestingConnection = true;
        this.connectionTestResult = 'none';
        this.connectionTestMessage = '';
        this.connectionTestLatency = 0;
        const startTime = performance.now();
        try {
            const response = await fetch(`${baseUrl}/v1/chat/completions`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${gatewayToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'gpt-4.1',
                    messages: [{ role: 'user', content: 'ping' }],
                    max_tokens: 1,
                    stream: false
                }),
                signal: AbortSignal.timeout(this.editingConnector.defaultTimeoutMs || 30000)
            });
            const endTime = performance.now();
            this.connectionTestLatency = Math.round(endTime - startTime);
            if (response.ok) {
                this.connectionTestResult = 'success';
            }
            else if (response.status === 401) {
                this.connectionTestResult = 'error';
                this.connectionTestMessage = this.msg.testConnectionErrorAuth;
            }
            else if (response.status === 403) {
                this.connectionTestResult = 'error';
                this.connectionTestMessage = this.msg.testConnectionErrorAuth;
            }
            else {
                let errorDetail = '';
                try {
                    const errorBody = await response.json();
                    errorDetail = errorBody?.error?.message || errorBody?.message || '';
                }
                catch {
                    errorDetail = response.statusText;
                }
                this.connectionTestResult = 'error';
                this.connectionTestMessage = `HTTP ${response.status}${errorDetail ? ': ' + errorDetail : ''}`;
            }
        }
        catch (error) {
            const endTime = performance.now();
            this.connectionTestLatency = Math.round(endTime - startTime);
            this.connectionTestResult = 'error';
            if (error.name === 'TimeoutError' || error.name === 'AbortError') {
                this.connectionTestMessage = this.msg.testConnectionErrorTimeout;
            }
            else if (error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError')) {
                this.connectionTestMessage = this.msg.testConnectionErrorNetwork;
            }
            else if (error.message?.includes('CORS')) {
                this.connectionTestMessage = 'Erro de CORS - servidor não permite requisições do navegador';
            }
            else {
                this.connectionTestMessage = error.message || this.msg.testConnectionErrorUnknown;
            }
        }
        finally {
            this.isTestingConnection = false;
        }
    }
    // ========== DELETE CONFIRMATION HANDLERS ==========
    handleToggleDeleteConfirmation() {
        this.showDeleteConfirmation = !this.showDeleteConfirmation;
        this.deleteConfirmationInput = '';
    }
    handleDeleteConfirmationInput(e) {
        const input = e.target;
        this.deleteConfirmationInput = input.value;
    }
    handleCancelDelete() {
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
    }
    async handleConfirmDelete(connectorId) {
        if (!this.editingConnector)
            return;
        const connectorName = this.editingConnector.name || `Connector #${connectorId.slice(0, 8)}`;
        if (this.deleteConfirmationInput.trim() !== connectorName)
            return;
        this.isSavingConnector = true;
        const updatedConnectors = this.connectors.filter(c => c.connectorId !== connectorId);
        try {
            // await saveOpenClawConnectors(updatedConnectors);
            this.connectors = updatedConnectors;
            this.labelOkConnector = this.msg.successRemoveConnector;
            this.showDeleteConfirmation = false;
            this.deleteConfirmationInput = '';
            this.handleBackToMain();
        }
        catch (err) {
            this.labelErrorConnector = err.message;
        }
        finally {
            this.isSavingConnector = false;
        }
    }
    // ========== AGENT HANDLERS ==========
    handleOpenAddAgent() {
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.editingAgent = null;
        this.isNewAgent = true;
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.navigateTo('editAgent', true);
    }
    handleOpenEditAgent(agent) {
        this.editingAgent = agent;
        this.newAgentName = agent.identityName;
        this.newAgentAvatarUrl = agent.identityEmoji;
        this.isNewAgent = false;
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.navigateTo('editAgent', true);
    }
    handleBackToConnectorDetails() {
        this.editingAgent = null;
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.navigateTo('connectorDetails');
    }
    handleNewAgentNameInput(e) {
        const input = e.target;
        this.newAgentName = input.value;
    }
    handleNewAgentAvatarInput(e) {
        const input = e.target;
        this.newAgentAvatarUrl = input.value;
    }
    handleGenerateAgentAvatar() {
        if (this.newAgentName) {
            this.newAgentAvatarUrl = generateAgentAvatar(this.newAgentName);
        }
    }
    async handleSaveAgent() {
        if (!this.editingConnector)
            return;
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        if (!this.newAgentName.trim()) {
            this.labelErrorAgent = this.msg.errorAgentName;
            return;
        }
        this.isSavingAgent = true;
        const sanitizedName = this.newAgentName.toLowerCase().replace(/\s+/g, '');
        /*
        if (this.isNewAgent) {
            const agentId = generateUUIDv7();
            const newAgent: IOpenClawAgent = {
                id: agentId,
                identityName: this.newAgentName.trim(),
                identityEmoji: this.newAgentAvatarUrl || generateAgentAvatar(this.newAgentName),
                senderId: `integration:openclaw:${sanitizedName}`,
                createdAt: new Date().toISOString()
            };

            this.editingConnector = {
                ...this.editingConnector,
                agents: [...this.editingConnector.agents, newAgent]
            };
        } else if (this.editingAgent) {
            const updatedAgent: IOpenClawAgent = {
                ...this.editingAgent,
                name: this.newAgentName.trim(),
                avatarUrl: this.newAgentAvatarUrl || generateAgentAvatar(this.newAgentName),
                senderId: `integration:openclaw:${sanitizedName}`,
            };

            this.editingConnector = {
                ...this.editingConnector,
                agents: this.editingConnector.agents.map(a =>
                    a.id === this.editingAgent!.id ? updatedAgent : a
                )
            };
        }

        try {
            const updatedConnectors = this.connectors.map(c =>
                c.connectorId === this.editingConnector!.connectorId
                    ? { ...c, agents: this.editingConnector!.agents }
                    : c
            );

            if (!this.editingConnector.isNew) {
                // await saveOpenClawConnectors(updatedConnectors);
                this.connectors = updatedConnectors;
            }

            this.labelOkAgent = this.msg.successAddingAgent;

            setTimeout(() => {
                this.handleBackToConnectorDetails();
            }, 1000);

        } catch (err: any) {
            this.labelErrorAgent = err.message;
        } finally {
            this.isSavingAgent = false;
        }
        */
    }
    async handleRemoveAgent(agentId) {
        if (!this.editingConnector)
            return;
        if (!confirm(this.msg.confirmRemoveAgent))
            return;
        this.editingConnector = {
            ...this.editingConnector,
            agents: this.editingConnector.agents.filter(a => a.id !== agentId)
        };
        if (!this.editingConnector.isNew) {
            try {
                const updatedConnectors = this.connectors.map(c => c.connectorId === this.editingConnector.connectorId
                    ? { ...c, agents: this.editingConnector.agents }
                    : c);
                // await saveOpenClawConnectors(updatedConnectors);
                this.connectors = updatedConnectors;
            }
            catch (err) {
                console.error('Error removing agent:', err);
            }
        }
    }
};
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "userId", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "connectors", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "viewMode", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "currentConnectorId", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "editingConnector", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "isTestingConnection", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "connectionTestResult", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "connectionTestMessage", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "connectionTestLatency", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "showDeleteConfirmation", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "deleteConfirmationInput", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "newAgentName", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "newAgentAvatarUrl", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "editingAgent", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "isNewAgent", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "labelOkConnector", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "labelErrorConnector", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "labelOkAgent", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "labelErrorAgent", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "isSavingConnector", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "isSavingAgent", void 0);
CollabMessagesSettingsOpenClaw = __decorate([
    customElement('collab-messages-settings-open-claw-102025')
], CollabMessagesSettingsOpenClaw);
export { CollabMessagesSettingsOpenClaw };
