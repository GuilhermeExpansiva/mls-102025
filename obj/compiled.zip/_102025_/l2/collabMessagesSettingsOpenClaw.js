/// <mls fileReference="_102025_/l2/collabMessagesSettingsOpenClaw.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { generateUUIDv7, generateAgentAvatar, saveOpenClawIntegrations, loadOpenClawIntegrations, } from '/_102025_/l2/collabMessagesHelper.js';
import { collab_plug, collab_plus, collab_trash, collab_refresh, collab_chevron_left, collab_edit, collab_xmark, collab_floppy_disk, collab_check, collab_warning, collab_robot, collab_eye_slash, collab_eye, collab_copy } from '/_102025_/l2/collabMessagesIcons.js';
import { msgListOpenClawConnectors, msgAddOrUpdateOpenClawConnector, msgRemoveOpenClawConnector, msgCreateOpenClawAgent, msgDeleteOpenClawAgent } from '/_102025_/l2/shared/api.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando informações...',
    save: 'Salvar',
    cancel: 'Cancelar',
    back: 'Voltar',
    connectorsTitle: 'Conectores OpenClaw ',
    newConnector: 'Novo connector',
    editConnector: 'Editar connector',
    noConnectors: 'Nenhum connector configurado',
    connectorName: 'Nome',
    connectorNameHint: 'Nome amigável para identificar esta instância',
    connectorNamePlaceholder: 'Ex: OpenClaw Produção',
    baseUrl: 'URL base',
    baseUrlHint: 'Deve apontar para o Gateway HTTP do OpenClaw (porta padrão: 18789)',
    baseUrlPlaceholder: 'https://chat-gw.collab.codes',
    gatewayToken: 'Gateway token',
    gatewayTokenHint: 'Token para autenticar chamadas ao endpoint /v1/chat/completions',
    inboundToken: 'Inbound token',
    inboundTokenHint: 'Token secreto para validar webhooks vindos do OpenClaw',
    defaultTimeout: 'Timeout (ms)',
    defaultTimeoutHint: 'Chamadas síncronas',
    outputMode: 'Modo de saída',
    outputModeHint: 'Como publicar respostas',
    connectorEnabled: 'Ativo',
    connectorDisabled: 'Inativo',
    configSection: 'Configuração',
    authSection: 'Autenticação',
    behaviorSection: 'Comportamento padrão',
    deleteSection: 'Remover conector',
    changeToken: 'Alterar',
    generateToken: 'Gerar',
    removeConnector: 'Remover',
    errorConnectorName: 'Nome do connector é obrigatório',
    errorBaseUrl: 'URL base é obrigatória',
    errorGatewayToken: 'Gateway token é obrigatório',
    errorInboundToken: 'Inbound token é obrigatório',
    successSavingConnector: 'Connector salvo com sucesso',
    successRemoveConnector: 'Connector removido com sucesso',
    deleteWarningTitle: 'Atenção',
    deleteWarningMessage: 'Ao remover este connector, todas as integrações associadas serão desativadas e os agentes configurados serão perdidos. Esta ação não pode ser desfeita.',
    deleteConfirmInstruction: 'Digite o nome do connector para confirmar:',
    deleteConfirmButton: 'Confirmar remoção',
    agentsSection: 'Agentes',
    addAgent: 'Adicionar agente',
    agentName: 'Nome do agente',
    agentAvatar: 'URL do avatar (opcional)',
    agentNamePlaceholder: 'Ex: Bot de Vendas',
    noAgents: 'Nenhum agente configurado',
    errorAgentName: 'O nome do agente é obrigatório',
    successAddingAgent: 'Agente adicionado com sucesso',
    confirmRemoveAgent: 'Remover este agente?',
    testConnectionSection: 'Verificar conexão',
    testConnectionInfo: 'Teste a conectividade com o servidor antes de salvar para garantir que as configurações estão corretas.',
    testConnectionBtn: 'Testar conexão',
    testConnectionTesting: 'Testando...',
    testConnectionSuccess: 'Conexão estabelecida com sucesso',
    testConnectionWarning: 'Conexão não verificada',
    testConnectionWarningReason: 'Servidor detectado (não foi possível validar o token via browser)',
    testConnectionLatency: 'Latência',
    testConnectionError: 'Falha na conexão',
    testConnectionErrorTimeout: 'Timeout - servidor não respondeu',
    testConnectionErrorAuth: 'Erro de autenticação - verifique o token',
    testConnectionErrorNetwork: 'Erro de rede - verifique a URL',
    testConnectionErrorUnknown: 'Erro desconhecido',
    copyToken: 'Copiar',
    tokenCopied: 'Copiado!',
    showToken: 'Mostrar token',
    hideToken: 'Ocultar token',
    agentWorkspace: 'Workspace',
    agentWorkspaceHint: 'Identificador do workspace onde o agente será criado',
    agentWorkspacePlaceholder: 'Ex: vendas, suporte, geral',
    agentEmoji: 'Emoji (opcional)',
    agentEmojiHint: 'Emoji para identificar o agente',
    agentSoulMd: 'Soul (Markdown)',
    agentSoulMdHint: 'Personalidade e comportamento do agente',
    agentSoulMdPlaceholder: 'Descreva a personalidade do agente...',
    agentIdentityMd: 'Identity (Markdown)',
    agentIdentityMdHint: 'Identidade e papel do agente',
    agentIdentityMdPlaceholder: 'Descreva a identidade do agente...',
    agentNameHint: 'Apenas letras e números, deve começar com letra',
    errorAgentWorkspace: 'Workspace é obrigatório',
    errorAgentNameInvalid: 'Nome deve conter apenas letras e números, e começar com uma letra',
    creatingAgent: 'Criando agente...',
    // Delete agent
    deleteAgentTitle: 'Remover agente',
    deleteAgentWarning: 'Tem certeza que deseja remover este agente? Esta ação não pode ser desfeita.',
    deleteAgentAlsoDeleteFiles: 'Também excluir arquivos associados',
    deletingAgent: 'Removendo...',
    successRemoveAgent: 'Agente removido com sucesso',
    errorRemoveAgent: 'Erro ao remover agente',
};
const message_en = {
    loading: 'Loading...',
    save: 'Save',
    cancel: 'Cancel',
    back: 'Back',
    connectorsTitle: 'OpenClaw Connectors',
    newConnector: 'New connector',
    editConnector: 'Edit connector',
    noConnectors: 'No connectors configured',
    connectorName: 'Name',
    connectorNameHint: 'Friendly name to identify this instance',
    connectorNamePlaceholder: 'Ex: OpenClaw Production',
    baseUrl: 'Base URL',
    baseUrlHint: 'Must point to the OpenClaw HTTP Gateway (default port: 18789)',
    baseUrlPlaceholder: 'https://chat-gw.collab.codes',
    gatewayToken: 'Gateway token',
    gatewayTokenHint: 'Token to authenticate calls to /v1/chat/completions endpoint',
    inboundToken: 'Inbound token',
    inboundTokenHint: 'Secret token to validate webhooks from OpenClaw',
    defaultTimeout: 'Timeout (ms)',
    defaultTimeoutHint: 'Synchronous calls',
    outputMode: 'Output mode',
    outputModeHint: 'How to publish responses',
    connectorEnabled: 'Active',
    connectorDisabled: 'Inactive',
    configSection: 'Configuration',
    authSection: 'Authentication',
    behaviorSection: 'Default behavior',
    deleteSection: 'Remove conector',
    changeToken: 'Change',
    generateToken: 'Generate',
    removeConnector: 'Remove',
    errorConnectorName: 'Connector name is required',
    errorBaseUrl: 'Base URL is required',
    errorGatewayToken: 'Gateway token is required',
    errorInboundToken: 'Inbound token is required',
    successSavingConnector: 'Connector saved successfully',
    successRemoveConnector: 'Connector removed successfully',
    deleteWarningTitle: 'Warning',
    deleteWarningMessage: 'Removing this connector will disable all associated integrations and configured agents will be lost. This action cannot be undone.',
    deleteConfirmInstruction: 'Type the connector name to confirm:',
    deleteConfirmButton: 'Confirm removal',
    agentsSection: 'Agents',
    addAgent: 'Add agent',
    agentName: 'Agent name',
    agentAvatar: 'Avatar URL (optional)',
    agentNamePlaceholder: 'Ex: Sales Bot',
    noAgents: 'No agents configured',
    errorAgentName: 'Agent name is required',
    successAddingAgent: 'Agent added successfully',
    confirmRemoveAgent: 'Remove this agent?',
    testConnectionSection: 'Verify connection',
    testConnectionInfo: 'Test connectivity with the server before saving to ensure the settings are correct.',
    testConnectionBtn: 'Test connection',
    testConnectionTesting: 'Testing...',
    testConnectionSuccess: 'Connection established successfully',
    testConnectionWarning: 'Connection not verified',
    testConnectionWarningReason: 'Server detected (unable to validate token via browser)',
    testConnectionLatency: 'Latency',
    testConnectionError: 'Connection failed',
    testConnectionErrorTimeout: 'Timeout - server did not respond',
    testConnectionErrorAuth: 'Authentication error - check the token',
    testConnectionErrorNetwork: 'Network error - check the URL',
    testConnectionErrorUnknown: 'Unknown error',
    copyToken: 'Copy',
    tokenCopied: 'Copied!',
    showToken: 'Show token',
    hideToken: 'Hide token',
    agentWorkspace: 'Workspace',
    agentWorkspaceHint: 'Workspace identifier where the agent will be created',
    agentWorkspacePlaceholder: 'Ex: sales, support, general',
    agentEmoji: 'Emoji (optional)',
    agentEmojiHint: 'Emoji to identify the agent',
    agentSoulMd: 'Soul (Markdown)',
    agentSoulMdHint: 'Agent personality and behavior',
    agentSoulMdPlaceholder: 'Describe the agent personality...',
    agentIdentityMd: 'Identity (Markdown)',
    agentIdentityMdHint: 'Agent identity and role',
    agentIdentityMdPlaceholder: 'Describe the agent identity...',
    agentNameHint: 'Letters and numbers only, must start with a letter',
    errorAgentWorkspace: 'Workspace is required',
    errorAgentNameInvalid: 'Name must contain only letters and numbers, and start with a letter',
    creatingAgent: 'Creating agent...',
    // Delete agent
    deleteAgentTitle: 'Remove agent',
    deleteAgentWarning: 'Are you sure you want to remove this agent? This action cannot be undone.',
    deleteAgentAlsoDeleteFiles: 'Also delete associated files',
    deletingAgent: 'Removing...',
    successRemoveAgent: 'Agent removed successfully',
    errorRemoveAgent: 'Error removing agent',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let CollabMessagesSettingsOpenClaw = class CollabMessagesSettingsOpenClaw extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-open-claw-102025{display:block}collab-messages-settings-open-claw-102025 .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-settings-open-claw-102025 .saving-error{color:var(--error-color);font-size:var(--font-size-12)}collab-messages-settings-open-claw-102025 button{background-color:var(--info-color);box-shadow:0 1px 3px 0 var(--grey-color);flex-direction:row;justify-content:center;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);color:#ffffff;padding:.5rem 1rem;border:none;border-radius:6px;cursor:pointer;font-size:var(--font-size-12);font-weight:var(--font-weight-bold);display:flex;align-items:center;gap:.25rem;white-space:nowrap;flex-shrink:0}collab-messages-settings-open-claw-102025 button svg{flex-shrink:0;fill:currentColor}collab-messages-settings-open-claw-102025 button:hover{background-color:var(--info-color-hover)}collab-messages-settings-open-claw-102025 button:disabled{opacity:.6;cursor:not-allowed}collab-messages-settings-open-claw-102025 button.btn-icon{width:32px;height:32px;padding:.25rem;border-radius:6px;background-color:transparent;color:var(--text-primary-color-lighter);box-shadow:none;border:1px solid var(--grey-color)}collab-messages-settings-open-claw-102025 button.btn-icon:hover{background-color:var(--bg-secondary-color)}collab-messages-settings-open-claw-102025 button.btn-icon svg{width:16px;height:16px}collab-messages-settings-open-claw-102025 button.btn-icon.copied{color:var(--success-color) !important;border-color:var(--success-color) !important}collab-messages-settings-open-claw-102025 button.btn-icon.copied svg{fill:var(--success-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-danger{color:var(--error-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-danger:hover{background-color:rgba(255,77,79,0.1)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-danger svg{fill:var(--error-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-toggle.on{color:var(--success-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-toggle.on svg{stroke:var(--success-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-toggle.off{color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-back{width:32px;height:32px;padding:.25rem;border-radius:6px;background-color:transparent;color:var(--text-primary-color);box-shadow:none;margin-right:.5rem}collab-messages-settings-open-claw-102025 button.btn-icon.btn-back:hover{background-color:var(--bg-secondary-color)}collab-messages-settings-open-claw-102025 button.btn-icon.btn-back svg{width:20px;height:20px}collab-messages-settings-open-claw-102025 button.btn-secondary{background-color:var(--bg-secondary-color);color:var(--text-primary-color)}collab-messages-settings-open-claw-102025 button.btn-secondary:hover{background-color:var(--bg-secondary-color-hover)}collab-messages-settings-open-claw-102025 button.btn-link{border:none;background-color:transparent;color:var(--active-color);box-shadow:none;cursor:pointer;padding:0;height:auto}collab-messages-settings-open-claw-102025 button.btn-link:hover{text-decoration:underline}collab-messages-settings-open-claw-102025 button.btn-link svg{width:14px;height:14px}collab-messages-settings-open-claw-102025 button.btn-danger-outline{background-color:transparent !important;color:var(--error-color) !important;border:1px solid var(--error-color) !important;width:100%;justify-content:center}collab-messages-settings-open-claw-102025 button.btn-danger-outline:hover{background-color:rgba(255,77,79,0.1) !important}collab-messages-settings-open-claw-102025 button.btn-danger-outline svg{width:16px;height:16px;fill:var(--error-color)}collab-messages-settings-open-claw-102025 button.btn-danger{color:#ffffff}collab-messages-settings-open-claw-102025 button.btn-danger:hover{background-color:var(--error-color-hover)}collab-messages-settings-open-claw-102025 button.btn-danger svg{fill:currentColor}collab-messages-settings-open-claw-102025 button.btn-back{width:32px;height:32px;padding:.25rem;border-radius:6px;background-color:transparent;color:var(--text-primary-color);box-shadow:none}collab-messages-settings-open-claw-102025 button.btn-back:hover{background-color:var(--bg-secondary-color)}collab-messages-settings-open-claw-102025 button.btn-back svg{width:20px;height:20px}collab-messages-settings-open-claw-102025 button.btn-change-token{height:30px;padding:0 12px;background-color:var(--bg-secondary-color);color:var(--text-primary-color-lighter);border:1px solid var(--grey-color);font-size:var(--font-size-12)}collab-messages-settings-open-claw-102025 button.btn-change-token:hover{background-color:var(--bg-secondary-color-hover)}collab-messages-settings-open-claw-102025 button.btn-change-token svg{width:14px;height:14px}collab-messages-settings-open-claw-102025 .section{padding:1.4rem .75rem;border-radius:10px;box-shadow:#e7e3e3 0 1px 4px;background-color:var(--bg-primary-color-darker);margin-bottom:1.5rem}collab-messages-settings-open-claw-102025 .section h4{display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem;margin-block-start:0;padding-bottom:.4rem;border-bottom:1px solid #d2d2d2}collab-messages-settings-open-claw-102025 .section h4 svg{fill:currentColor;width:20px;height:20px}collab-messages-settings-open-claw-102025 .section .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-settings-open-claw-102025 .section .no-items{color:var(--text-primary-color-lighter);font-style:italic;margin:.5rem 0}collab-messages-settings-open-claw-102025 .section .form-field{margin-bottom:1rem}collab-messages-settings-open-claw-102025 .section .form-field label{display:block;font-size:var(--font-size-12);margin-bottom:.3rem}collab-messages-settings-open-claw-102025 .section .form-field .field-hint{display:block;font-size:11px;color:var(--text-primary-color-lighter);margin-top:3px}collab-messages-settings-open-claw-102025 .section .form-field .field-hint.warning{color:var(--warning-color);display:flex;align-items:flex-start;gap:4px}collab-messages-settings-open-claw-102025 .section .form-field .field-hint.warning svg{flex-shrink:0;width:12px;height:12px;fill:currentColor;margin-top:1px}collab-messages-settings-open-claw-102025 .section .form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}collab-messages-settings-open-claw-102025 .section .form-row .form-field input[maxlength="4"]{text-align:center;font-size:20px}collab-messages-settings-open-claw-102025 .section .form-actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:.75rem;margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--grey-color)}collab-messages-settings-open-claw-102025 .section input,collab-messages-settings-open-claw-102025 .section select{display:flex;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;max-height:30px;height:30px;padding:0 .5rem}collab-messages-settings-open-claw-102025 .section input[type="number"],collab-messages-settings-open-claw-102025 .section input[type="text"],collab-messages-settings-open-claw-102025 .section input[type="url"],collab-messages-settings-open-claw-102025 .section input[type="password"]{width:100%;box-sizing:border-box}collab-messages-settings-open-claw-102025 .section select{width:100%;box-sizing:border-box}collab-messages-settings-open-claw-102025 .connector-details-header{display:flex;align-items:center;gap:.5rem;margin-bottom:1rem;padding-bottom:.5rem}collab-messages-settings-open-claw-102025 .connector-details-header h3{display:flex;align-items:center;gap:.5rem;margin:0;font-size:var(--font-size-20)}collab-messages-settings-open-claw-102025 .connector-details-header h3 svg{fill:currentColor;width:24px;height:24px}collab-messages-settings-open-claw-102025 .connectors .connectors-list{display:flex;flex-direction:column;gap:12px}collab-messages-settings-open-claw-102025 .connectors .connector-add-link{margin-top:1rem}collab-messages-settings-open-claw-102025 .connector-card{background-color:var(--bg-primary-color);border:1px solid var(--grey-color);border-radius:8px;padding:1rem;display:flex;justify-content:space-between;align-items:flex-start;gap:12px}collab-messages-settings-open-claw-102025 .connector-card.disabled{opacity:.65}collab-messages-settings-open-claw-102025 .connector-card .connector-info{flex:1;min-width:0}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-header{display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-name{font-size:15px;font-weight:var(--font-weight-bold)}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-status{display:inline-flex;align-items:center;gap:4px;font-size:11px;padding:2px 8px;border-radius:10px}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-status .status-dot{width:6px;height:6px;border-radius:50%;background-color:currentColor}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-status.active{background-color:rgba(82,196,26,0.15);color:var(--success-color)}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-status.inactive{background-color:var(--bg-secondary-color);color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-url{font-size:13px;color:var(--text-primary-color-lighter);margin-bottom:8px;word-break:break-all}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-meta{display:flex;flex-wrap:wrap;gap:12px;font-size:12px;color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 .connector-card .connector-info .connector-meta strong{color:var(--text-primary-color);font-weight:var(--font-weight-normal)}collab-messages-settings-open-claw-102025 .connector-card .connector-actions{display:flex;gap:4px;flex-shrink:0}collab-messages-settings-open-claw-102025 .connector-form .section-header{display:flex;align-items:center;justify-content:space-between;padding-bottom:1rem;margin-bottom:1.25rem;border-bottom:1px solid #cecece}collab-messages-settings-open-claw-102025 .connector-form .section-divider{padding-bottom:1rem;margin-bottom:1.25rem;border-bottom:1px solid #cecece}collab-messages-settings-open-claw-102025 .connector-form .section-title{font-size:14px;font-weight:var(--font-weight-bold);color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 .connector-form .toggle-label{display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer}collab-messages-settings-open-claw-102025 .connector-form .toggle-label .toggle-switch{position:relative;width:36px;height:20px;background-color:var(--grey-color-dark);border-radius:10px;transition:background-color .2s}collab-messages-settings-open-claw-102025 .connector-form .toggle-label .toggle-switch .toggle-thumb{position:absolute;top:2px;left:2px;width:16px;height:16px;background-color:white;border-radius:50%;box-shadow:0 1px 3px rgba(0,0,0,0.2);transition:left .2s}collab-messages-settings-open-claw-102025 .connector-form .toggle-label .toggle-switch.on{background-color:var(--success-color)}collab-messages-settings-open-claw-102025 .connector-form .toggle-label .toggle-switch.on .toggle-thumb{left:18px}collab-messages-settings-open-claw-102025 .connector-form .token-field{display:flex;gap:6px}collab-messages-settings-open-claw-102025 .connector-form .token-field input{flex:1;font-family:monospace;font-size:13px;letter-spacing:2px}collab-messages-settings-open-claw-102025 .connector-form .token-field .btn-icon{width:30px;height:30px;flex-shrink:0}collab-messages-settings-open-claw-102025 .connector-form .token-field.with-actions{flex-wrap:wrap}collab-messages-settings-open-claw-102025 .connector-form .token-field.with-actions input{flex:1;min-width:150px}collab-messages-settings-open-claw-102025 .connector-form .token-field.with-actions .token-actions{display:flex;gap:4px;align-items:center}collab-messages-settings-open-claw-102025 .connector-form .avatar-input-group{display:flex;gap:.5rem;align-items:center}collab-messages-settings-open-claw-102025 .connector-form .avatar-input-group input{flex:1}collab-messages-settings-open-claw-102025 .test-connection-section .test-connection-info{font-size:var(--font-size-12);color:var(--text-primary-color-lighter);line-height:1.5;margin:0 0 1rem}collab-messages-settings-open-claw-102025 .test-connection-section .test-result{display:flex;align-items:flex-start;gap:12px;padding:12px;border-radius:8px;margin-bottom:1rem}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-icon{flex-shrink:0;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-icon svg{width:14px;height:14px;fill:currentColor}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-content{display:flex;flex-direction:column;gap:2px}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-content .test-result-title{font-size:14px;font-weight:var(--font-weight-bold)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result .test-result-content .test-result-detail{font-size:12px}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.success{background-color:rgba(82,196,26,0.1);border:1px solid rgba(82,196,26,0.25)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.success .test-result-icon{background-color:var(--success-color);color:white}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.success .test-result-title{color:#368011}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.success .test-result-detail{color:var(--success-color)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.warning{background-color:rgba(250,173,20,0.1);border:1px solid rgba(250,173,20,0.25)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.warning .test-result-icon{background-color:var(--warning-color);color:white}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.warning .test-result-title{color:#bd7f04}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.warning .test-result-detail{color:var(--warning-color)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.error{background-color:rgba(255,77,79,0.08);border:1px solid rgba(255,77,79,0.25)}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.error .test-result-icon{background-color:var(--error-color);color:white}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.error .test-result-title{color:#ff1a1d}collab-messages-settings-open-claw-102025 .test-connection-section .test-result.error .test-result-detail{color:var(--error-color)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection{width:100%;height:44px;background-color:rgba(10,109,201,0.1);border:1px solid rgba(10,109,201,0.25);color:var(--info-color);border-radius:8px;font-size:14px;font-weight:var(--font-weight-bold);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .2s ease;box-shadow:none}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection svg{width:18px;height:18px;stroke:currentColor;fill:none}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection:hover:not(:disabled){background-color:rgba(10,109,201,0.18);border-color:rgba(10,109,201,0.4)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection:disabled{opacity:.5;cursor:not-allowed}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection.success{background-color:rgba(82,196,26,0.1);border-color:rgba(82,196,26,0.25);color:var(--success-color)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection.success:hover:not(:disabled){background-color:rgba(82,196,26,0.18);border-color:rgba(82,196,26,0.4)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection.error{background-color:rgba(255,77,79,0.08);border-color:rgba(255,77,79,0.25);color:var(--error-color)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection.error:hover:not(:disabled){background-color:rgba(255,77,79,0.15);border-color:rgba(255,77,79,0.4)}collab-messages-settings-open-claw-102025 .test-connection-section .btn-test-connection .loader{width:18px;height:18px;border-width:2px}collab-messages-settings-open-claw-102025 .delete-warning-section{margin-top:1.5rem;padding-top:1rem}collab-messages-settings-open-claw-102025 .delete-warning-box{background-color:rgba(255,77,79,0.08);border:1px solid rgba(255,77,79,0.25);border-radius:8px;padding:1rem}collab-messages-settings-open-claw-102025 .delete-warning-box .warning-header{display:flex;align-items:center;gap:8px;font-weight:var(--font-weight-bold);color:var(--error-color);margin-bottom:.5rem}collab-messages-settings-open-claw-102025 .delete-warning-box .warning-header svg{width:18px;height:18px;fill:var(--error-color);flex-shrink:0}collab-messages-settings-open-claw-102025 .delete-warning-box .warning-message{font-size:var(--font-size-12);color:var(--text-primary-color);line-height:1.5;margin:0 0 1rem 0}collab-messages-settings-open-claw-102025 .delete-confirmation{width:100%;animation:slideDown .2s ease;margin-top:1rem}@keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}collab-messages-settings-open-claw-102025 .delete-confirmation label{display:block;font-size:var(--font-size-12);color:var(--text-primary-color);margin-bottom:.25rem}collab-messages-settings-open-claw-102025 .delete-confirmation .confirm-name{display:block;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);font-family:monospace;margin-bottom:.5rem}collab-messages-settings-open-claw-102025 .delete-confirmation input{width:100%;padding:.5rem;height:auto !important;max-height:none !important;box-sizing:border-box}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions{display:flex;justify-content:flex-end;gap:.5rem;margin-top:.75rem}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions button{height:32px;font-size:var(--font-size-12);padding:0 .75rem;box-shadow:none}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-cancel{background:transparent;color:var(--text-primary-color);border:1px solid var(--grey-color-dark)}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-cancel:hover{background:var(--bg-secondary-color)}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-confirm{background:var(--error-color);color:white}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-confirm:hover:not(:disabled){background:var(--error-color-hover)}collab-messages-settings-open-claw-102025 .delete-confirmation .delete-actions .btn-confirm:disabled{background:var(--grey-color-dark);color:var(--text-primary-color-lighter);cursor:not-allowed}collab-messages-settings-open-claw-102025 .agents-list{display:flex;flex-direction:column;gap:8px;margin-bottom:.5rem}collab-messages-settings-open-claw-102025 .agent-add-link{margin-top:.5rem;margin-bottom:1rem}collab-messages-settings-open-claw-102025 .agent-card{display:flex;align-items:center;gap:10px;background-color:var(--bg-secondary-color-lighter);border-radius:8px;padding:10px 12px}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar{flex-shrink:0}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar .agent-avatar-svg{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;overflow:hidden}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar .agent-avatar-svg svg{width:100%;height:100%}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar .agent-avatar-emoji{width:36px;height:36px;border-radius:50%;background-color:var(--bg-secondary-color);display:flex;align-items:center;justify-content:center;font-size:20px}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar img{width:36px;height:36px;border-radius:50%;object-fit:cover}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar .agent-avatar-placeholder{width:36px;height:36px;border-radius:50%;background-color:var(--grey-color);display:flex;align-items:center;justify-content:center}collab-messages-settings-open-claw-102025 .agent-card .agent-avatar .agent-avatar-placeholder svg{width:18px;height:18px;color:var(--text-primary-color-lighter);fill:currentColor}collab-messages-settings-open-claw-102025 .agent-card .agent-info{flex:1;min-width:0;display:flex;flex-direction:column}collab-messages-settings-open-claw-102025 .agent-card .agent-info .agent-name{font-weight:var(--font-weight-bold);font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-settings-open-claw-102025 .agent-card .agent-info .agent-sender-id{font-family:monospace;font-size:11px;color:var(--text-primary-color-lighter);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-settings-open-claw-102025 .agent-card .agent-actions{display:flex;gap:4px;flex-shrink:0}collab-messages-settings-open-claw-102025 .agent-card .agent-actions .btn-icon{width:28px;height:28px;border:none}collab-messages-settings-open-claw-102025 .agent-card .agent-actions .btn-icon svg{width:14px;height:14px}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large{display:flex;align-items:center;gap:16px;padding:16px;background-color:var(--bg-secondary-color-lighter);border-radius:10px;margin-bottom:1.5rem}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-avatar{width:64px;height:64px;border-radius:50%;object-fit:cover;border:2px solid var(--grey-color)}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-avatar-placeholder{width:64px;height:64px;border-radius:50%;background-color:var(--grey-color);display:flex;align-items:center;justify-content:center;border:2px solid var(--grey-color-dark)}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-avatar-placeholder svg{width:32px;height:32px;color:var(--text-primary-color-lighter);fill:currentColor}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-info{display:flex;flex-direction:column;gap:4px}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-info .preview-name{font-weight:var(--font-weight-bold);font-size:var(--font-size-16);color:var(--text-primary-color)}collab-messages-settings-open-claw-102025 .agent-form .agent-preview-large .preview-info .preview-sender-id{font-family:monospace;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 .agent-form .preview-avatar-emoji{width:64px;height:64px;border-radius:50%;background-color:var(--bg-secondary-color);display:flex;align-items:center;justify-content:center;font-size:32px;border:2px solid var(--grey-color-dark)}collab-messages-settings-open-claw-102025 .agent-form textarea{display:block;width:100%;min-height:100px;padding:.75rem;font-size:var(--font-size-12);font-family:var(--font-family-primary);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);border:1px solid var(--grey-color-dark);border-radius:6px;resize:vertical;box-sizing:border-box;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}collab-messages-settings-open-claw-102025 .agent-form textarea:focus{outline:none;border-color:var(--info-color);box-shadow:0 0 0 2px rgba(10,109,201,0.2)}collab-messages-settings-open-claw-102025 .agent-form textarea::placeholder{color:var(--text-primary-color-lighter)}collab-messages-settings-open-claw-102025 .agent-form .avatar-input-group{display:flex;gap:.5rem;align-items:center}collab-messages-settings-open-claw-102025 .agent-form .avatar-input-group input{flex:1}collab-messages-settings-open-claw-102025 .modal-overlay{position:fixed;top:0;left:0;right:0;bottom:0;background-color:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:1000;animation:fadeIn .2s ease}@keyframes fadeIn{from{opacity:0}to{opacity:1}}collab-messages-settings-open-claw-102025 .modal-content{background-color:var(--bg-primary-color);border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.2);width:90%;max-width:400px;animation:slideUp .2s ease}@keyframes slideUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}collab-messages-settings-open-claw-102025 .modal-content .modal-header{padding:1rem 1.25rem;border-bottom:1px solid var(--grey-color)}collab-messages-settings-open-claw-102025 .modal-content .modal-header h4{margin:0;display:flex;align-items:center;gap:8px;font-size:var(--font-size-16);color:var(--error-color)}collab-messages-settings-open-claw-102025 .modal-content .modal-header h4 svg{width:20px;height:20px;fill:var(--error-color)}collab-messages-settings-open-claw-102025 .modal-content .modal-body{padding:1.25rem}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview{display:flex;align-items:center;gap:12px;padding:12px;background-color:var(--bg-secondary-color-lighter);border-radius:8px;margin-bottom:1rem}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-avatar{flex-shrink:0}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-avatar .agent-avatar-svg{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;overflow:hidden}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-avatar .agent-avatar-svg svg{width:100%;height:100%}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-avatar .agent-avatar-emoji{width:40px;height:40px;border-radius:50%;background-color:var(--bg-secondary-color);display:flex;align-items:center;justify-content:center;font-size:22px}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-avatar img{width:40px;height:40px;border-radius:50%;object-fit:cover}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-avatar .agent-avatar-placeholder{width:40px;height:40px;border-radius:50%;background-color:var(--grey-color);display:flex;align-items:center;justify-content:center}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-avatar .agent-avatar-placeholder svg{width:20px;height:20px;color:var(--text-primary-color-lighter);fill:currentColor}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-info{flex:1;min-width:0;display:flex;flex-direction:column}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-info .agent-name{font-weight:var(--font-weight-bold);font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-settings-open-claw-102025 .modal-content .modal-body .agent-to-delete-preview .agent-info .agent-sender-id{font-family:monospace;font-size:11px;color:var(--text-primary-color-lighter);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-settings-open-claw-102025 .modal-content .modal-body .delete-agent-warning{font-size:var(--font-size-12);color:var(--text-primary-color);line-height:1.5;margin:0 0 1rem 0}collab-messages-settings-open-claw-102025 .modal-content .modal-body .checkbox-label{display:flex;align-items:center;gap:8px;font-size:var(--font-size-12);color:var(--text-primary-color);cursor:pointer}collab-messages-settings-open-claw-102025 .modal-content .modal-body .checkbox-label input[type="checkbox"]{width:16px;height:16px;cursor:pointer;accent-color:var(--info-color)}collab-messages-settings-open-claw-102025 .modal-content .modal-footer{padding:1rem 1.25rem;border-top:1px solid var(--grey-color);display:flex;justify-content:flex-end;gap:.75rem}collab-messages-settings-open-claw-102025 .modal-content .modal-footer button{min-width:100px}`);
        this.msg = messages['en'];
        this.userId = '';
        this.integrations = [];
        // OpenClaw Connector states
        this.connectors = [];
        this.viewMode = 'main';
        this.currentConnectorId = '';
        this.editingConnector = null;
        this.isTestingConnection = false;
        this.connectionTestResult = 'none';
        this.connectionTestMessage = '';
        this.connectionTestLatency = 0;
        this.showGatewayToken = false;
        this.showInboundToken = false;
        this.copiedToken = null;
        // Delete confirmation states
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        // Agent states
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.editingAgent = null;
        this.isNewAgent = false;
        this.newAgentWorkspace = '';
        this.newAgentEmoji = '';
        this.newAgentSoulMd = '';
        this.newAgentIdentityMd = '';
        // Delete agent states
        this.showDeleteAgentConfirmation = false;
        this.agentToDelete = null;
        this.deleteAgentFiles = false;
        this.isDeletingAgent = false;
        this.labelOkConnector = '';
        this.labelErrorConnector = '';
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.isSavingConnector = false;
        this.isSavingAgent = false;
    }
    async firstUpdated() {
        if (!this.userId)
            return;
        const rc = await msgListOpenClawConnectors({
            userId: this.userId
        });
        if (rc.response) {
            this.connectors = rc.response.connectors.map((item) => {
                return {
                    ...item, isNew: false, gatewayTokenChanged: false, inboundTokenChanged: false
                };
            });
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.viewMode === 'editAgent') {
            return this.renderEditAgentView();
        }
        if (this.viewMode === 'connectorDetails') {
            return this.renderConnectorDetailsView();
        }
        return this.renderOpenClawConnectors();
    }
    renderOpenClawConnectors() {
        return html `
        <div>
            <div class="section connectors">
                <h4>${collab_plug} ${this.msg.connectorsTitle}</h4>

                ${this.connectors.length === 0
            ? html `<p class="no-items">${this.msg.noConnectors}</p>`
            : html `
                        <div class="connectors-list">
                            ${this.connectors.map(connector => this.renderConnectorCard(connector))}
                        </div>
                    `}

                <div class="connector-add-link">
                    <button class="btn-link" @click=${this.handleAddConnector}>
                        ${collab_plus} ${this.msg.newConnector}
                    </button>
                </div>
            </div>
        </div>`;
    }
    renderConnectorCard(connector) {
        const isEnabled = connector.enabled;
        return html `
        <div class="connector-card ${!isEnabled ? 'disabled' : ''}">
            <div class="connector-info">
                <div class="connector-header">
                    <span class="connector-name">${connector.name || `Connector #${connector.connectorId.slice(0, 8)}`}</span>
                    <span class="connector-status ${isEnabled ? 'active' : 'inactive'}">
                        <span class="status-dot"></span>
                        ${isEnabled ? this.msg.connectorEnabled : this.msg.connectorDisabled}
                    </span>
                </div>
                <div class="connector-url">${connector.baseUrl}</div>
                <div class="connector-meta">
                    <span>Timeout: <strong>${connector.defaultTimeoutMs}ms</strong></span>
                </div>
            </div>
            <div class="connector-actions">
                <button class="btn-icon" @click=${() => this.handleOpenConnectorDetails(connector.connectorId)} title="Editar">
                    ${collab_edit}
                </button>
            </div>
        </div>`;
    }
    renderToggleIcon(isOn) {
        return html `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="1" y="5" width="22" height="14" rx="7"/>
            <circle cx="${isOn ? 16 : 8}" cy="12" r="3" fill="currentColor"/>
        </svg>`;
    }
    renderConnectorDetailsView() {
        if (!this.editingConnector)
            return html ``;
        const connector = this.editingConnector;
        return html `
        <div>
            <div class="connector-details-header">
                <button class="btn-back" @click=${this.handleBackToMain}>
                    ${collab_chevron_left}
                </button>
                <h3>${collab_plug} ${connector.isNew ? this.msg.newConnector : this.msg.editConnector}</h3>
            </div>

            ${this.renderConfigurationSection(connector)}

            ${!connector.isNew ? this.renderAgentSection() : html `${nothing}`}
            ${!connector.isNew ? this.renderDeleteSection(connector) : html `${nothing}`}
            
            ${this.renderDeleteAgentModal()}
        </div>`;
    }
    renderConfigurationSection(connector) {
        const isNew = connector.isNew;
        const showGatewayTokenField = isNew || connector.gatewayTokenChanged;
        const showInboundTokenField = isNew || connector.inboundTokenChanged;
        return html `
        <div class="section connector-form">
            <div class="section-header">
                <span class="section-title">${this.msg.configSection}</span>
                <label class="toggle-label" @click=${this.handleConnectorEnabledToggle}>
                    <span class="toggle-switch ${connector.enabled ? 'on' : ''}">
                        <span class="toggle-thumb"></span>
                    </span>
                    ${connector.enabled ? this.msg.connectorEnabled : this.msg.connectorDisabled}
                </label>
            </div>

            <div class="form-field">
                <label>${this.msg.connectorName} *</label>
                <input 
                    type="text" 
                    .value=${connector.name} 
                    @input=${this.handleConnectorNameChange}
                    placeholder="${this.msg.connectorNamePlaceholder}"
                />
                <small class="field-hint">${this.msg.connectorNameHint}</small>
            </div>

            <div class="form-field">
                <label>${this.msg.baseUrl} *</label>
                <input 
                    type="url" 
                    .value=${connector.baseUrl} 
                    @input=${this.handleConnectorUrlChange}
                    placeholder="${this.msg.baseUrlPlaceholder}"
                />
                <small class="field-hint warning">
                    ${collab_warning}
                    ${this.msg.baseUrlHint}
                </small>
            </div>

            <div class="section-divider">
                <span class="section-title">${this.msg.authSection}</span>
            </div>

            <div class="form-field">
                <label>${this.msg.gatewayToken} *</label>
                ${showGatewayTokenField ? html `
                    <div class="token-field">
                        <input 
                            type="text" 
                            .value=${connector.gatewayToken} 
                            @input=${this.handleGatewayTokenChange}
                            placeholder="Token..."
                        />
                        <button class="btn-icon" @click=${() => this.handleGenerateToken('gateway')} title="${this.msg.generateToken}">
                            ${collab_refresh}
                        </button>
                    </div>
                ` : html `
                    <div class="token-field with-actions">
                        <input 
                            type="${this.showGatewayToken ? 'text' : 'password'}" 
                            .value=${this.showGatewayToken ? connector.gatewayToken : '••••••••••••••••••••••••'} 
                            readonly 
                        />
                        <div class="token-actions">
                            <button 
                                class="btn-icon" 
                                @click=${() => this.handleToggleTokenVisibility('gateway')} 
                                title="${this.showGatewayToken ? this.msg.hideToken : this.msg.showToken}"
                            >
                                ${this.showGatewayToken ? collab_eye_slash : collab_eye}
                            </button>
                            <button 
                                class="btn-icon ${this.copiedToken === 'gateway' ? 'copied' : ''}" 
                                @click=${() => this.handleCopyToken('gateway')} 
                                title="${this.copiedToken === 'gateway' ? this.msg.tokenCopied : this.msg.copyToken}"
                            >
                                ${this.copiedToken === 'gateway' ? collab_check : collab_copy}
                            </button>
                            <button class="btn-change-token" @click=${() => this.handleChangeToken('gateway')}>
                                ${collab_edit} ${this.msg.changeToken}
                            </button>
                        </div>
                    </div>
                `}
                <small class="field-hint">${this.msg.gatewayTokenHint}</small>
            </div>

            <div class="form-field">
                <label>${this.msg.inboundToken} *</label>
                ${showInboundTokenField ? html `
                    <div class="token-field">
                        <input 
                            type="text" 
                            .value=${connector.inboundToken} 
                            @input=${this.handleInboundTokenChange}
                            placeholder="Token..."
                        />
                        <button class="btn-icon" @click=${() => this.handleGenerateToken('inbound')} title="${this.msg.generateToken}">
                            ${collab_refresh}
                        </button>
                    </div>
                ` : html `
                    <div class="token-field with-actions">
                        <input 
                            type="${this.showInboundToken ? 'text' : 'password'}" 
                            .value=${this.showInboundToken ? connector.inboundToken : '••••••••••••••••••••••••'} 
                            readonly 
                        />
                        <div class="token-actions">
                            <button 
                                class="btn-icon" 
                                @click=${() => this.handleToggleTokenVisibility('inbound')} 
                                title="${this.showInboundToken ? this.msg.hideToken : this.msg.showToken}"
                            >
                                ${this.showInboundToken ? collab_eye_slash : collab_eye}
                            </button>
                            <button 
                                class="btn-icon ${this.copiedToken === 'inbound' ? 'copied' : ''}" 
                                @click=${() => this.handleCopyToken('inbound')} 
                                title="${this.copiedToken === 'inbound' ? this.msg.tokenCopied : this.msg.copyToken}"
                            >
                                ${this.copiedToken === 'inbound' ? collab_check : collab_copy}
                            </button>
                            <button class="btn-change-token" @click=${() => this.handleChangeToken('inbound')}>
                                ${collab_edit} ${this.msg.changeToken}
                            </button>
                        </div>
                    </div>
                `}
                <small class="field-hint">${this.msg.inboundTokenHint}</small>
            </div>

            <div class="section-divider">
                <span class="section-title">${this.msg.behaviorSection}</span>
            </div>

            <div class="form-row">
                <div class="form-field">
                    <label>${this.msg.defaultTimeout}</label>
                    <input 
                        type="number" 
                        .value=${String(connector.defaultTimeoutMs)} 
                        @input=${this.handleTimeoutChange}
                        min="5000" 
                        max="300000" 
                        step="1000"
                    />
                    <small class="field-hint">${this.msg.defaultTimeoutHint}</small>
                </div>
                <div class="form-field">
                    <label>${this.msg.outputMode}</label>
                    <select .value=${connector.defaultOutputMode} @change=${this.handleOutputModeChange}>
                        <option value="final_only">Final</option>
                        <option value="status_and_final">Status/Final</option>
                    </select>
                    <small class="field-hint">${this.msg.outputModeHint}</small>
                </div>
            </div>


            ${!connector.isNew ? this.renderTestConnectionSection(connector) : html `${nothing}`}


            <div class="form-actions">
                <button class="btn-secondary" @click=${this.handleCancelConnector}>
                    ${collab_xmark} ${this.msg.cancel}
                </button>
                <button @click=${this.handleSaveConnector} ?disabled=${this.isSavingConnector}>
                    ${this.isSavingConnector ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.save}`}
                </button>
            </div>

            ${this.labelOkConnector ? html `<small class="saving-ok">${this.labelOkConnector}</small>` : ''}
            ${this.labelErrorConnector ? html `<small class="saving-error">${this.labelErrorConnector}</small>` : ''}
        </div>`;
    }
    renderTestConnectionSection(connector) {
        return html `
        <div class="section-divider">
            <span class="section-title">${this.msg.testConnectionSection}</span>
        </div>

        <div class="test-connection-section">
            <p class="test-connection-info">${this.msg.testConnectionInfo}</p>
            
            ${this.connectionTestResult === 'success' ? html `
                <div class="test-result success">
                    <div class="test-result-icon">
                        ${collab_check}
                    </div>
                    <div class="test-result-content">
                        <span class="test-result-title">${this.msg.testConnectionSuccess}</span>
                        <span class="test-result-detail">${this.msg.testConnectionLatency}: ${this.connectionTestLatency}ms</span>
                    </div>
                </div>
            `
            : this.connectionTestResult === 'warning' ? html `
                <div class="test-result warning">
                    <div class="test-result-icon">
                        ${collab_warning}
                    </div>
                    <div class="test-result-content">
                        <span class="test-result-title">${this.msg.testConnectionWarning}</span>
                        <span class="test-result-detail">${this.connectionTestMessage}</span>
                    </div>
                </div>
            `
                : this.connectionTestResult === 'error' ? html `
                <div class="test-result error">
                    <div class="test-result-icon">
                        ${collab_xmark}
                    </div>
                    <div class="test-result-content">
                        <span class="test-result-title">${this.msg.testConnectionError}</span>
                        <span class="test-result-detail">${this.connectionTestMessage}</span>
                    </div>
                </div>
            ` : nothing}
            
            <button 
                class="btn-test-connection ${this.connectionTestResult}" 
                @click=${this.handleTestConnection}
                ?disabled=${this.isTestingConnection || !connector.baseUrl || !connector.gatewayToken}
            >
                ${this.isTestingConnection ? html `
                    <span class="loader"></span>
                    ${this.msg.testConnectionTesting}
                ` : html `
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                        <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                    ${this.msg.testConnectionBtn}
                `}
            </button>
        </div>`;
    }
    renderAgentSection() {
        return html `
        <div class="section connector-form">
            <div class="section-divider">
                <span class="section-title">${this.msg.agentsSection}</span>
            </div>

            <div class="agents-list">
                ${this.actualIntegration?.agents.length === 0
            ? html `<p class="no-items">${this.msg.noAgents}</p>`
            : this.actualIntegration?.agents.map((agent) => this.renderAgentCard(agent))}
            </div>

            <div class="agent-add-link">
                <button class="btn-link" @click=${this.handleOpenAddAgent} >
                    ${collab_plus} ${this.msg.addAgent}
                </button>
            </div>
        </div>`;
    }
    renderDeleteSection(connector) {
        const isNew = connector.isNew;
        return html `
        <div class="section connector-form">
            <div class="section-divider">
                <span class="section-title">${this.msg.deleteSection}</span>
            </div>

            ${!isNew && !this.showDeleteConfirmation ? html `
                <div class="delete-warning-section">
                    <div class="delete-warning-box">
                        <div class="warning-header">
                            ${collab_warning}
                            <span>${this.msg.deleteWarningTitle}</span>
                        </div>
                        <p class="warning-message">${this.msg.deleteWarningMessage}</p>
                        <button class="btn-danger-outline" @click=${this.handleToggleDeleteConfirmation}>
                            ${collab_trash} ${this.msg.removeConnector}
                        </button>
                    </div>
                </div>
            ` : nothing}
            ${this.showDeleteConfirmation ? this.renderDeleteConfirmation(connector) : nothing}
        </div>`;
    }
    renderDeleteConfirmation(connector) {
        const connectorName = connector.name || `Connector #${connector.connectorId.slice(0, 8)}`;
        const isMatch = this.deleteConfirmationInput.trim() === connectorName;
        return html `
        <div class="delete-confirmation">
            <label>${this.msg.deleteConfirmInstruction}</label>
            <span class="confirm-name">${connectorName}</span>
            <input 
                type="text" 
                .value=${this.deleteConfirmationInput}
                @input=${this.handleDeleteConfirmationInput}
            />
            <div class="delete-actions">
                <button class="btn-cancel" @click=${this.handleCancelDelete}>
                    ${this.msg.cancel}
                </button>
                <button 
                    class="btn-confirm" 
                    @click=${() => this.handleConfirmDelete(connector.connectorId)}
                    ?disabled=${!isMatch || this.isSavingConnector}
                >
                    ${this.isSavingConnector ? html `<span class="loader"></span>` : this.msg.deleteConfirmButton}
                </button>
            </div>
        </div>`;
    }
    renderAgentCard(agent) {
        return html `
        <div class="agent-card">
            <div class="agent-avatar">
              ${this.renderAvatar(agent)}
            </div>
            <div class="agent-info">
                <span class="agent-name">${agent.name}(${agent.collabUserId})</span>
                <span class="agent-sender-id">${agent.id}</span>
            
            </div>
            <div class="agent-actions">
                <button class="btn-icon btn-danger" @click=${() => this.handleOpenDeleteAgentConfirmation(agent)} title="${this.msg.confirmRemoveAgent}">
                    ${collab_trash}
                </button>
            </div>
        </div>`;
    }
    renderDeleteAgentModal() {
        if (!this.showDeleteAgentConfirmation || !this.agentToDelete)
            return nothing;
        const agent = this.agentToDelete;
        return html `
        <div class="modal-overlay" @click=${this.handleCloseDeleteAgentConfirmation}>
            <div class="modal-content" @click=${(e) => e.stopPropagation()}>
                <div class="modal-header">
                    <h4>${collab_warning} ${this.msg.deleteAgentTitle}</h4>
                </div>
                <div class="modal-body">
                    <div class="agent-to-delete-preview">
                        <div class="agent-avatar">
                            ${this.renderAvatar(agent)}
                        </div>
                        <div class="agent-info">
                            <span class="agent-name">${agent.name}</span>
                            <span class="agent-sender-id">${agent.id}</span>
                        </div>
                    </div>
                    <p class="delete-agent-warning">${this.msg.deleteAgentWarning}</p>
                    <label class="checkbox-label">
                        <input 
                            type="checkbox" 
                            .checked=${this.deleteAgentFiles}
                            @change=${this.handleDeleteAgentFilesChange}
                        />
                        ${this.msg.deleteAgentAlsoDeleteFiles}
                    </label>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary" @click=${this.handleCloseDeleteAgentConfirmation} ?disabled=${this.isDeletingAgent}>
                        ${this.msg.cancel}
                    </button>
                    <button class="btn-danger" @click=${this.handleConfirmDeleteAgent} ?disabled=${this.isDeletingAgent}>
                        ${this.isDeletingAgent
            ? html `<span class="loader"></span> ${this.msg.deletingAgent}`
            : html `${collab_trash} ${this.msg.deleteConfirmButton}`}
                    </button>
                </div>
            </div>
        </div>`;
    }
    renderAvatar(agent) {
        const value = agent.avatarUrl;
        if (!value) {
            return html `<img src="${generateAgentAvatar(agent.name)}" alt="${agent.name}" />`;
        }
        if (value.trim().startsWith("<svg")) {
            return html `<div class="agent-avatar-svg" .innerHTML=${value}></div>`;
        }
        if (this.isUrl(value)) {
            return html `<img src="${value}" alt="${agent.name}" />`;
        }
        return html `<div class="agent-avatar-emoji">${value}</div>`;
    }
    isUrl(value) {
        try {
            new URL(value);
            return true;
        }
        catch {
            return value.startsWith("data:image");
        }
    }
    renderEditAgentView() {
        if (!this.editingConnector)
            return html ``;
        const isNew = this.isNewAgent;
        const previewName = this.newAgentName || 'Novo Agente';
        return html `
    <div>
        <div class="connector-details-header">
            <button class="btn-back" @click=${this.handleBackToConnectorDetails}>
                ${collab_chevron_left}
            </button>
            <h3>${collab_robot} ${isNew ? this.msg.addAgent : this.msg.editConnector}</h3>
        </div>

        <div class="section agent-form">
            <div class="agent-preview-large">
                ${this.newAgentAvatarUrl
            ? html `<img class="preview-avatar" src="${this.newAgentAvatarUrl}" alt="${previewName}" />`
            : this.newAgentEmoji
                ? html `<div class="preview-avatar-emoji">${this.newAgentEmoji}</div>`
                : html `<div class="preview-avatar-placeholder">${collab_robot}</div>`}
                <div class="preview-info">
                    <span class="preview-name">${previewName}</span>
                    <span class="preview-sender-id">${this.newAgentWorkspace || 'workspace'}</span>
                </div>
            </div>

            <div class="section-divider">
                <span class="section-title">${this.msg.configSection}</span>
            </div>

            <div class="form-field">
                <label>${this.msg.agentName} *</label>
                <input 
                    type="text" 
                    .value=${this.newAgentName} 
                    @input=${this.handleNewAgentNameInput}
                    placeholder="${this.msg.agentNamePlaceholder}"
                    pattern="^[a-zA-Z][a-zA-Z0-9]*$"
                    autocomplete="off"
                    spellcheck="false"
                />
                <small class="field-hint">${this.msg.agentNameHint}</small>
            </div>

            <div class="form-field">
                <label>${this.msg.agentWorkspace} *</label>
                <input 
                    type="text" 
                    .value=${this.newAgentWorkspace} 
                    @input=${this.handleNewAgentWorkspaceInput}
                    placeholder="${this.msg.agentWorkspacePlaceholder}"
                />
                <small class="field-hint">${this.msg.agentWorkspaceHint}</small>
            </div>

            <div class="form-field">
                    <label>${this.msg.agentEmoji}</label>
                    <input 
                        type="text" 
                        .value=${this.newAgentEmoji} 
                        @input=${this.handleNewAgentEmojiInput}
                        maxlength="4"
                    />
                    <small class="field-hint">${this.msg.agentEmojiHint}</small>
            </div>


            <div class="form-field">
                <label>${this.msg.agentAvatar}</label>
                <div class="avatar-input-group">
                    <input 
                        type="text" 
                        .value=${this.newAgentAvatarUrl} 
                        @input=${this.handleNewAgentAvatarInput}
                        placeholder="https://..."
                    />
                    <button class="btn-icon" @click=${this.handleGenerateAgentAvatar} title="${this.msg.generateToken}">
                        ${collab_refresh}
                    </button>
                </div>
            </div>
        
            <div class="section-divider">
                <span class="section-title">${this.msg.behaviorSection}</span>
            </div>

            <div class="form-field">
                <label>${this.msg.agentSoulMd}</label>
                <textarea 
                    .value=${this.newAgentSoulMd} 
                    @input=${this.handleNewAgentSoulMdInput}
                    placeholder="${this.msg.agentSoulMdPlaceholder}"
                    rows="4"
                ></textarea>
                <small class="field-hint">${this.msg.agentSoulMdHint}</small>
            </div>

            <div class="form-field">
                <label>${this.msg.agentIdentityMd}</label>
                <textarea 
                    .value=${this.newAgentIdentityMd} 
                    @input=${this.handleNewAgentIdentityMdInput}
                    placeholder="${this.msg.agentIdentityMdPlaceholder}"
                    rows="4"
                ></textarea>
                <small class="field-hint">${this.msg.agentIdentityMdHint}</small>
            </div>

            <div class="form-actions">
                <button class="btn-secondary" @click=${this.handleBackToConnectorDetails}>
                    ${collab_xmark} ${this.msg.cancel}
                </button>
                <button @click=${this.handleSaveAgent} ?disabled=${this.isSavingAgent}>
                    ${this.isSavingAgent
            ? html `<span class="loader"></span> ${this.msg.creatingAgent}`
            : html `${collab_floppy_disk} ${this.msg.save}`}
                </button>
            </div>

            ${this.labelOkAgent ? html `<small class="saving-ok">${this.labelOkAgent}</small>` : ''}
            ${this.labelErrorAgent ? html `<small class="saving-error">${this.labelErrorAgent}</small>` : ''}
        </div>
    </div>`;
    }
    // ========== NAVIGATION ==========
    navigateTo(newView, resetScroll = false) {
        this.viewMode = newView;
        this.dispatchEvent(new CustomEvent('settings-change', {
            detail: { mode: 'view', viewMode: newView === 'main' ? 'all' : 'openclaw' },
            bubbles: true,
            composed: true
        }));
    }
    // ========== CONNECTOR HANDLERS ==========
    async handleAddConnector() {
        const newConnector = {
            connectorId: generateUUIDv7(),
            name: '',
            baseUrl: '',
            gatewayToken: '',
            inboundToken: '',
            enabled: true,
            defaultTimeoutMs: 60000,
            defaultOutputMode: 'final_only',
            isNew: true
        };
        this.editingConnector = newConnector;
        this.currentConnectorId = newConnector.connectorId;
        this.clearStates();
        this.clearErrors();
        this.actualIntegration = undefined;
        this.navigateTo('connectorDetails', true);
    }
    clearErrors() {
        this.labelOkConnector = '';
        this.labelErrorConnector = '';
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
    }
    clearStates() {
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.newAgentWorkspace = '';
        this.newAgentEmoji = '';
        this.newAgentSoulMd = '';
        this.newAgentIdentityMd = '';
        this.isTestingConnection = false;
        this.connectionTestResult = 'none';
        this.connectionTestMessage = '';
        this.connectionTestLatency = 0;
        this.showGatewayToken = false;
        this.showInboundToken = false;
        this.copiedToken = null;
        // Clear delete agent states
        this.showDeleteAgentConfirmation = false;
        this.agentToDelete = null;
        this.deleteAgentFiles = false;
        this.isDeletingAgent = false;
    }
    async getIntegration(connectorId) {
        this.integrations = await loadOpenClawIntegrations();
        const actual = this.integrations.find((item) => item.connectorId === connectorId);
        if (actual)
            this.actualIntegration = actual;
        else
            this.actualIntegration = undefined;
    }
    async handleOpenConnectorDetails(connectorId) {
        const connector = this.connectors.find(c => c.connectorId === connectorId);
        if (!connector)
            return;
        this.editingConnector = {
            ...connector,
            isNew: false,
            gatewayTokenChanged: false,
            inboundTokenChanged: false
        };
        await this.getIntegration(connectorId);
        this.currentConnectorId = connectorId;
        this.clearErrors();
        this.clearStates();
        this.navigateTo('connectorDetails', true);
    }
    handleBackToMain() {
        this.currentConnectorId = '';
        this.editingConnector = null;
        this.clearErrors();
        this.clearStates();
        this.navigateTo('main');
    }
    handleCancelConnector() {
        this.handleBackToMain();
    }
    handleConnectorNameChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, name: input.value };
    }
    handleConnectorUrlChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, baseUrl: input.value };
    }
    handleGatewayTokenChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, gatewayToken: input.value };
    }
    handleInboundTokenChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, inboundToken: input.value };
    }
    handleChangeToken(type) {
        if (!this.editingConnector)
            return;
        if (type === 'gateway') {
            this.editingConnector = { ...this.editingConnector, gatewayToken: '', gatewayTokenChanged: true };
        }
        else {
            this.editingConnector = { ...this.editingConnector, inboundToken: '', inboundTokenChanged: true };
        }
    }
    handleTimeoutChange(e) {
        if (!this.editingConnector)
            return;
        const input = e.target;
        this.editingConnector = { ...this.editingConnector, defaultTimeoutMs: parseInt(input.value) || 60000 };
    }
    handleOutputModeChange(e) {
        if (!this.editingConnector)
            return;
        const select = e.target;
        this.editingConnector = { ...this.editingConnector, defaultOutputMode: select.value };
    }
    async handleConnectorEnabledToggle() {
        if (!this.editingConnector)
            return;
        this.editingConnector = { ...this.editingConnector, enabled: !this.editingConnector.enabled };
        await this.saveOrUpdateOpenClawConnector(this.editingConnector);
        const { isNew: _, gatewayTokenChanged, inboundTokenChanged, ...connectorData } = this.editingConnector;
        const updatedConnectors = this.connectors.map(c => {
            if (c.connectorId === connectorData.connectorId) {
                return {
                    ...c,
                    ...connectorData,
                    gatewayToken: gatewayTokenChanged ? connectorData.gatewayToken : c.gatewayToken,
                    inboundToken: inboundTokenChanged ? connectorData.inboundToken : c.inboundToken,
                };
            }
            return c;
        });
        this.connectors = updatedConnectors;
    }
    handleGenerateToken(type) {
        if (!this.editingConnector)
            return;
        const newToken = generateUUIDv7();
        if (type === 'gateway') {
            this.editingConnector = { ...this.editingConnector, gatewayToken: newToken };
        }
        else {
            this.editingConnector = { ...this.editingConnector, inboundToken: newToken };
        }
    }
    async handleSaveConnector() {
        if (!this.editingConnector)
            return;
        this.labelOkConnector = '';
        this.labelErrorConnector = '';
        if (!this.editingConnector.name.trim()) {
            this.labelErrorConnector = this.msg.errorConnectorName;
            return;
        }
        if (!this.editingConnector.baseUrl.trim()) {
            this.labelErrorConnector = this.msg.errorBaseUrl;
            return;
        }
        const isNew = this.editingConnector.isNew;
        if (isNew) {
            if (!this.editingConnector.gatewayToken.trim()) {
                this.labelErrorConnector = this.msg.errorGatewayToken;
                return;
            }
            if (!this.editingConnector.inboundToken.trim()) {
                this.labelErrorConnector = this.msg.errorInboundToken;
                return;
            }
        }
        this.isSavingConnector = true;
        const { isNew: _, gatewayTokenChanged, inboundTokenChanged, ...connectorData } = this.editingConnector;
        let updatedConnectors;
        if (isNew) {
            updatedConnectors = [...this.connectors, connectorData];
        }
        else {
            updatedConnectors = this.connectors.map(c => {
                if (c.connectorId === connectorData.connectorId) {
                    return {
                        ...c,
                        ...connectorData,
                        gatewayToken: gatewayTokenChanged ? connectorData.gatewayToken : c.gatewayToken,
                        inboundToken: inboundTokenChanged ? connectorData.inboundToken : c.inboundToken,
                    };
                }
                return c;
            });
        }
        try {
            await this.saveOrUpdateOpenClawConnector(this.editingConnector);
            await this.saveIntegration(this.editingConnector);
            this.connectors = updatedConnectors;
            this.labelOkConnector = this.msg.successSavingConnector;
            if (isNew) {
                this.editingConnector = {
                    ...this.editingConnector,
                    isNew: false,
                    gatewayTokenChanged: false,
                    inboundTokenChanged: false
                };
            }
        }
        catch (err) {
            this.labelErrorConnector = err.message;
        }
        finally {
            this.isSavingConnector = false;
        }
    }
    async saveIntegration(connector) {
        let integration = this.actualIntegration;
        const { isNew: _, gatewayTokenChanged, inboundTokenChanged, ...connectorData } = connector;
        if (!integration) {
            integration = {
                agents: [],
                id: generateUUIDv7(),
                bearerToken: connectorData.gatewayToken,
                connectorId: connectorData.connectorId,
                createdAt: Date.now().toString(),
                name: connectorData.name,
                url: connectorData.baseUrl
            };
            this.integrations = [...this.integrations, integration];
        }
        else {
            const index = this.integrations.findIndex(i => i.connectorId === integration.connectorId);
            if (index !== -1) {
                const updatedIntegration = {
                    ...integration,
                    bearerToken: connectorData.gatewayToken,
                    connectorId: connectorData.connectorId,
                    name: connectorData.name,
                    url: connectorData.baseUrl
                };
                this.integrations = [
                    ...this.integrations.slice(0, index),
                    updatedIntegration,
                    ...this.integrations.slice(index + 1)
                ];
            }
        }
        await saveOpenClawIntegrations(this.integrations);
    }
    async removeIntegration(connector) {
        let integration = this.actualIntegration;
        const { isNew: _, gatewayTokenChanged, inboundTokenChanged, ...connectorData } = connector;
        if (!integration)
            return;
        const index = this.integrations.findIndex(i => i.connectorId === integration.connectorId);
        if (index !== -1) {
            this.integrations.splice(index, 1);
        }
        await saveOpenClawIntegrations(this.integrations);
    }
    async saveOrUpdateOpenClawConnector(connector) {
        if (!this.userId)
            throw new Error('Invalid user id');
        const { isNew, gatewayTokenChanged, inboundTokenChanged, protocolVersion, transport, ...payload } = connector;
        const result = await msgAddOrUpdateOpenClawConnector({
            userId: this.userId,
            ...payload
        });
        if (!result.success || !result.response) {
            throw new Error(result.error || 'Failed to save openClaw connector. Please try again.');
        }
        ;
        return result;
    }
    async handleTestConnection() {
        if (!this.editingConnector)
            return;
        const { baseUrl, gatewayToken } = this.editingConnector;
        if (!baseUrl || !gatewayToken)
            return;
        this.isTestingConnection = true;
        this.connectionTestResult = 'none';
        this.connectionTestMessage = '';
        this.connectionTestLatency = 0;
        const startTime = performance.now();
        const normalizedUrl = baseUrl.replace(/\/+$/, '');
        try {
            const domainExists = await this.checkDomainExists(normalizedUrl);
            if (!domainExists) {
                this.connectionTestLatency = Math.round(performance.now() - startTime);
                this.connectionTestResult = 'error';
                this.connectionTestMessage = this.msg.testConnectionErrorNetwork;
                return;
            }
            const sseUrl = normalizedUrl.endsWith('/sse') ? normalizedUrl : `${normalizedUrl}/sse`;
            const response = await fetch(sseUrl, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${gatewayToken}`,
                    'Accept': 'text/event-stream',
                },
                signal: AbortSignal.timeout(this.editingConnector.defaultTimeoutMs || 30000),
            });
            const endTime = performance.now();
            this.connectionTestLatency = Math.round(endTime - startTime);
            if (response.ok) {
                if (response.body)
                    await response.body.cancel();
                this.connectionTestResult = 'success';
                this.connectionTestMessage = this.msg.testConnectionSuccess;
            }
            else if (response.status === 401 || response.status === 403) {
                this.connectionTestResult = 'error';
                this.connectionTestMessage = this.msg.testConnectionErrorAuth;
            }
            else {
                this.connectionTestResult = 'error';
                this.connectionTestMessage = `HTTP ${response.status}: ${response.statusText}`;
            }
        }
        catch (error) {
            const endTime = performance.now();
            this.connectionTestLatency = Math.round(endTime - startTime);
            if (error.name === 'TimeoutError' || error.name === 'AbortError') {
                this.connectionTestResult = 'error';
                this.connectionTestMessage = this.msg.testConnectionErrorTimeout;
            }
            else {
                this.connectionTestResult = 'warning';
                this.connectionTestMessage = this.msg.testConnectionWarningReason;
            }
        }
        finally {
            this.isTestingConnection = false;
        }
    }
    async checkDomainExists(baseUrl) {
        try {
            await fetch(baseUrl, {
                method: 'HEAD',
                mode: 'no-cors',
                signal: AbortSignal.timeout(10000),
            });
            return true;
        }
        catch (error) {
            return false;
        }
    }
    // ========== DELETE CONFIRMATION HANDLERS ==========
    handleToggleDeleteConfirmation() {
        this.showDeleteConfirmation = !this.showDeleteConfirmation;
        this.deleteConfirmationInput = '';
    }
    handleDeleteConfirmationInput(e) {
        const input = e.target;
        this.deleteConfirmationInput = input.value;
    }
    handleCancelDelete() {
        this.showDeleteConfirmation = false;
        this.deleteConfirmationInput = '';
    }
    async handleConfirmDelete(connectorId) {
        if (!this.editingConnector)
            return;
        const connectorName = this.editingConnector.name || `Connector #${connectorId.slice(0, 8)}`;
        if (this.deleteConfirmationInput.trim() !== connectorName)
            return;
        this.isSavingConnector = true;
        const updatedConnectors = this.connectors.filter(c => c.connectorId !== connectorId);
        try {
            const result = await msgRemoveOpenClawConnector({
                connectorId,
                userId: this.userId
            });
            if (!result.success || !result.response) {
                throw new Error(result.error || 'Failed to remove connector. Please try again.');
            }
            ;
            await this.removeIntegration(this.editingConnector);
            this.connectors = updatedConnectors;
            this.labelOkConnector = this.msg.successRemoveConnector;
            this.showDeleteConfirmation = false;
            this.deleteConfirmationInput = '';
            this.handleBackToMain();
        }
        catch (err) {
            this.labelErrorConnector = err.message;
        }
        finally {
            this.isSavingConnector = false;
        }
    }
    // ========== AGENT HANDLERS ==========
    handleOpenAddAgent() {
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.newAgentWorkspace = '';
        this.newAgentEmoji = '';
        this.newAgentSoulMd = '';
        this.newAgentIdentityMd = '';
        this.editingAgent = null;
        this.isNewAgent = true;
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.navigateTo('editAgent', true);
    }
    handleOpenEditAgent(agent) {
        this.editingAgent = agent;
        this.newAgentName = agent.name;
        this.newAgentAvatarUrl = agent.avatarUrl;
        this.isNewAgent = false;
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.navigateTo('editAgent', true);
    }
    handleBackToConnectorDetails() {
        this.editingAgent = null;
        this.newAgentName = '';
        this.newAgentAvatarUrl = '';
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        this.navigateTo('connectorDetails');
    }
    handleNewAgentNameInput(e) {
        const input = e.target;
        let value = input.value;
        value = value.replace(/[^a-zA-Z0-9]/g, '');
        value = value.replace(/^[0-9]+/, '');
        this.newAgentName = value;
        input.value = value;
    }
    handleNewAgentAvatarInput(e) {
        const input = e.target;
        this.newAgentAvatarUrl = input.value;
    }
    handleNewAgentWorkspaceInput(e) {
        const input = e.target;
        this.newAgentWorkspace = input.value.toLowerCase().replace(/\s+/g, '-');
    }
    handleNewAgentEmojiInput(e) {
        const input = e.target;
        this.newAgentEmoji = input.value;
    }
    handleNewAgentSoulMdInput(e) {
        const textarea = e.target;
        this.newAgentSoulMd = textarea.value;
    }
    handleNewAgentIdentityMdInput(e) {
        const textarea = e.target;
        this.newAgentIdentityMd = textarea.value;
    }
    handleGenerateAgentAvatar() {
        if (this.newAgentName) {
            this.newAgentAvatarUrl = generateAgentAvatar(this.newAgentName);
        }
    }
    async handleSaveAgent() {
        if (!this.editingConnector)
            return;
        this.labelOkAgent = '';
        this.labelErrorAgent = '';
        const agentName = this.newAgentName.trim();
        if (!agentName) {
            this.labelErrorAgent = this.msg.errorAgentName;
            return;
        }
        const validNameRegex = /^[a-zA-Z][a-zA-Z0-9]*$/;
        if (!validNameRegex.test(agentName)) {
            this.labelErrorAgent = this.msg.errorAgentNameInvalid;
            return;
        }
        if (!this.newAgentWorkspace.trim()) {
            this.labelErrorAgent = this.msg.errorAgentWorkspace;
            return;
        }
        this.isSavingAgent = true;
        try {
            const result = await msgCreateOpenClawAgent({
                userId: this.userId,
                connectorId: this.editingConnector.connectorId,
                name: this.newAgentName.trim(),
                workspace: this.newAgentWorkspace.trim(),
                emoji: this.newAgentEmoji || undefined,
                avatar: this.newAgentAvatarUrl || undefined,
                soulMd: this.newAgentSoulMd || undefined,
                identityMd: this.newAgentIdentityMd || undefined,
            });
            if (!result.success || !result.response) {
                throw new Error(result.error || 'Failed to create agent');
            }
            const newAgent = {
                id: result.response.agent.id,
                name: this.newAgentName.trim(),
                avatarUrl: this.newAgentAvatarUrl || this.newAgentEmoji || '',
                createdAt: Date.now().toString(),
                collabUserId: result.response.collabUserId,
            };
            if (this.actualIntegration) {
                this.actualIntegration = {
                    ...this.actualIntegration,
                    agents: [...this.actualIntegration.agents, newAgent]
                };
                const index = this.integrations.findIndex(i => i.connectorId === this.editingConnector.connectorId);
                if (index !== -1) {
                    this.integrations = [
                        ...this.integrations.slice(0, index),
                        this.actualIntegration,
                        ...this.integrations.slice(index + 1)
                    ];
                }
                await saveOpenClawIntegrations(this.integrations);
            }
            this.labelOkAgent = this.msg.successAddingAgent;
            setTimeout(() => {
                this.handleBackToConnectorDetails();
            }, 1500);
        }
        catch (err) {
            this.labelErrorAgent = err.message || 'Error creating agent';
        }
        finally {
            this.isSavingAgent = false;
        }
    }
    // ========== DELETE AGENT HANDLERS ==========
    handleOpenDeleteAgentConfirmation(agent) {
        this.agentToDelete = agent;
        this.deleteAgentFiles = false;
        this.showDeleteAgentConfirmation = true;
    }
    handleCloseDeleteAgentConfirmation() {
        this.showDeleteAgentConfirmation = false;
        this.agentToDelete = null;
        this.deleteAgentFiles = false;
    }
    handleDeleteAgentFilesChange(e) {
        const input = e.target;
        this.deleteAgentFiles = input.checked;
    }
    async handleConfirmDeleteAgent() {
        if (!this.agentToDelete || !this.editingConnector)
            return;
        this.isDeletingAgent = true;
        try {
            const result = await msgDeleteOpenClawAgent({
                userId: this.userId,
                connectorId: this.editingConnector.connectorId,
                agentId: this.agentToDelete.id,
                deleteFiles: this.deleteAgentFiles
            });
            console.info(result);
            if (!result.success || !result.response) {
                throw new Error(result.error || this.msg.errorRemoveAgent);
            }
            // Remove agent from local integration
            if (this.actualIntegration) {
                const updatedAgents = this.actualIntegration.agents.filter(a => a.id !== this.agentToDelete.id);
                this.actualIntegration = {
                    ...this.actualIntegration,
                    agents: updatedAgents
                };
                // Update integrations array
                const index = this.integrations.findIndex(i => i.connectorId === this.editingConnector.connectorId);
                if (index !== -1) {
                    this.integrations = [
                        ...this.integrations.slice(0, index),
                        this.actualIntegration,
                        ...this.integrations.slice(index + 1)
                    ];
                }
                await saveOpenClawIntegrations(this.integrations);
            }
            this.handleCloseDeleteAgentConfirmation();
            this.labelOkAgent = this.msg.successRemoveAgent;
            // Clear success message after a few seconds
            setTimeout(() => {
                this.labelOkAgent = '';
            }, 3000);
        }
        catch (err) {
            this.labelErrorAgent = err.message || this.msg.errorRemoveAgent;
        }
        finally {
            this.isDeletingAgent = false;
        }
    }
    async handleDisableAgent(agentId) {
        // Find the agent and open delete confirmation
        const agent = this.actualIntegration?.agents.find(a => a.id === agentId);
        if (agent) {
            this.handleOpenDeleteAgentConfirmation(agent);
        }
    }
    handleToggleTokenVisibility(type) {
        if (type === 'gateway') {
            this.showGatewayToken = !this.showGatewayToken;
        }
        else {
            this.showInboundToken = !this.showInboundToken;
        }
    }
    async handleCopyToken(type) {
        if (!this.editingConnector)
            return;
        const token = type === 'gateway'
            ? this.editingConnector.gatewayToken
            : this.editingConnector.inboundToken;
        try {
            await navigator.clipboard.writeText(token);
            this.copiedToken = type;
            setTimeout(() => {
                this.copiedToken = null;
            }, 2000);
        }
        catch (err) {
            console.error('Failed to copy token:', err);
        }
    }
};
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "userId", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "actualIntegration", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "integrations", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "connectors", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "viewMode", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "currentConnectorId", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "editingConnector", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "isTestingConnection", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "connectionTestResult", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "connectionTestMessage", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "connectionTestLatency", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "showGatewayToken", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "showInboundToken", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "copiedToken", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "showDeleteConfirmation", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "deleteConfirmationInput", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "newAgentName", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "newAgentAvatarUrl", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "editingAgent", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "isNewAgent", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "newAgentWorkspace", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "newAgentEmoji", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "newAgentSoulMd", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "newAgentIdentityMd", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "showDeleteAgentConfirmation", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "agentToDelete", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "deleteAgentFiles", void 0);
__decorate([
    state()
], CollabMessagesSettingsOpenClaw.prototype, "isDeletingAgent", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "labelOkConnector", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "labelErrorConnector", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "labelOkAgent", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "labelErrorAgent", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "isSavingConnector", void 0);
__decorate([
    property()
], CollabMessagesSettingsOpenClaw.prototype, "isSavingAgent", void 0);
CollabMessagesSettingsOpenClaw = __decorate([
    customElement('collab-messages-settings-open-claw-102025')
], CollabMessagesSettingsOpenClaw);
export { CollabMessagesSettingsOpenClaw };
