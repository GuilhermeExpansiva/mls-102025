/// <mls fileReference="_102025_/l2/serviceCollabMessages.test.ts" enhancement="_blank" />

 import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];