/// <mls fileReference="_102025_/l2/project.ts" enhancement="_100554_enhancementLit" />

export const projectConfig = {
    masterFrontEnd: {
        build: '',
        start: '',
        liveView: '',
    },
    masterBackEnd: {
        build: '',
        start: '',
        serverView: ''
    },
    modules: []
}