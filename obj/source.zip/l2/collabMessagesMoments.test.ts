/// <mls fileReference="_102025_/l2/collabMessagesMoments.test.ts" enhancement="_blank" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];